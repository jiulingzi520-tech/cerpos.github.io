/* v54: legacy equity/dignity SVG animation selectors removed; homepage art is static inline SVG with one dedicated v54 stylesheet. */

/* v41: research dashboard translation is owned by the final translatePage controller. */
window.__cerpV41ControllerActive=true;
/* ===== Consolidated legacy patch v21 ===== */
/* V21 corrective pass: stable click-to-play charts, refined collaboration art, and genuinely pinned overlays. */
(()=>{'use strict';
const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
function installStyle(){const s=document.createElement('style');s.id='v21-fixes-style';s.textContent=`
/* Charts animate only after explicit activation; use paint transforms to avoid layout jumps. */
#researchDashboard .dashboardMetrics article{cursor:pointer;user-select:none}
#researchDashboard .dashboardMetrics .metricTrack{overflow:hidden}
#researchDashboard .dashboardMetrics .metricTrack i{display:block;width:var(--metric-target,0%);transform:scaleX(1);transform-origin:left center;transition:none!important}
#researchDashboard .dashboardMetrics article.v21-play .metricTrack i{animation:v21MetricFill 1.05s cubic-bezier(.2,.7,.2,1) both}
@keyframes v21MetricFill{from{transform:scaleX(0)}to{transform:scaleX(1)}}
#researchDashboard .dashChart{transform:none!important}
#researchDashboard .dashChart:hover{transform:none!important}
#researchDashboard .dashBars i{overflow:hidden}
#researchDashboard .dashBars i b{display:block;transform:scaleX(1);transform-origin:left center}
#researchDashboard .dashChart.v21-play .dashBars i b{animation:v21BarFill 1.25s cubic-bezier(.2,.7,.2,1) both}
@keyframes v21BarFill{from{transform:scaleX(0)}to{transform:scaleX(1)}}
#researchDashboard .dashLine{stroke-dasharray:100!important;stroke-dashoffset:100;animation:none!important}
#researchDashboard .dashChart.v21-play .dashLine{stroke-dashoffset:100;animation:v21LineDraw 2s ease-out both!important}
@keyframes v21LineDraw{to{stroke-dashoffset:0}}
#researchDashboard .dashDonut{background:conic-gradient(#1e658d 0 78.1%,#d5b05a 78.1% 100%)!important;transform:none;clip-path:none}
#researchDashboard .dashChart.v21-play .dashDonut{animation:v21DonutIn 1.2s ease-out both!important}
@keyframes v21DonutIn{from{filter:saturate(.35);opacity:.55}to{filter:saturate(1);opacity:1}}
#researchDashboard .radarTrace{stroke-dasharray:100!important;stroke-dashoffset:100;animation:none!important}
#researchDashboard .dashChart.v21-play .radarTrace{animation:v21RadarDraw 1.8s ease-out both!important}
@keyframes v21RadarDraw{from{stroke-dashoffset:100}to{stroke-dashoffset:0}}
#researchDashboard .radarPoints circle{transform-box:fill-box;transform-origin:center;animation:none!important}
#researchDashboard .dashChart.v21-play .radarPoints circle{animation:v21RadarPoint .42s ease-out both!important}
#researchDashboard .dashChart.v21-play .radarPoints circle:nth-child(2){animation-delay:.07s!important}#researchDashboard .dashChart.v21-play .radarPoints circle:nth-child(3){animation-delay:.14s!important}#researchDashboard .dashChart.v21-play .radarPoints circle:nth-child(4){animation-delay:.21s!important}#researchDashboard .dashChart.v21-play .radarPoints circle:nth-child(5){animation-delay:.28s!important}#researchDashboard .dashChart.v21-play .radarPoints circle:nth-child(6){animation-delay:.35s!important}
@keyframes v21RadarPoint{from{transform:scale(.35);opacity:.35}to{transform:scale(1);opacity:1}}
/* The separate verified baseline charts also animate on demand without shifting layout. */
.officialEvidenceBoard .evidenceStats article{cursor:pointer;user-select:none;transform:none!important;transition:border-color .25s,box-shadow .25s!important}
.officialEvidenceBoard .evidenceStats article:hover{transform:none!important}
.officialEvidenceBoard .yearCompare i{transform:scaleX(1);transform-origin:left center;display:block;animation:none!important}
.officialEvidenceBoard .evidenceStats article.v21-baseline-play .yearCompare i{animation:v21BarFill 1.15s cubic-bezier(.2,.7,.2,1) both}
.officialEvidenceBoard .evidenceStats article.v21-baseline-play .ringValue{animation:v21RingDraw 1.4s ease-out both}
@keyframes v21RingDraw{from{stroke-dashoffset:245;opacity:.3}to{stroke-dashoffset:0;opacity:1}}
.officialEvidenceBoard .evidenceStats article.v21-baseline-play strong{animation:v21ValueEmphasis .8s ease-out both}
@keyframes v21ValueEmphasis{0%{opacity:.65}100%{opacity:1}}
/* Modal directory header is pinned flush to the viewport; no top seam while scrolling. */
#questionBankOverlay,#moreReportsOverlay{position:fixed!important;inset:0!important;z-index:99999!important;padding:0!important;margin:0!important;align-items:flex-start!important;overflow-y:auto!important;overscroll-behavior:contain;background:#071b2edb}
#questionBankOverlay .questionBankPanel,#moreReportsOverlay .questionBankPanel{position:relative!important;width:100%!important;max-width:1080px!important;height:auto!important;min-height:100%!important;max-height:none!important;margin:0 auto!important;padding-top:calc(20px + env(safe-area-inset-top,0px))!important;border-radius:0!important;overflow:visible!important;box-sizing:border-box}
#questionBankOverlay .questionBankHeader,#moreReportsOverlay .questionBankHeader{position:sticky!important;top:0!important;z-index:5!important;margin-top:calc(-20px - env(safe-area-inset-top,0px))!important;padding-top:calc(20px + env(safe-area-inset-top,0px))!important;background:linear-gradient(180deg,#fbfcfd 0%,#fbfcfdf7 88%,#fbfcfd00 100%)!important;backdrop-filter:blur(12px);}
/* Sophisticated, restrained backgrounds: quiet editorial gradients, no dot grids or random lines. */
.page[data-page="issues"] .section,.page[data-page="roadmap"] .section.paper,.page[data-page="agenda"] .section.paper{background-color:#f8fafc!important;background-image:radial-gradient(ellipse at 12% 0%,rgba(168,202,220,.18),transparent 38%),radial-gradient(ellipse at 92% 100%,rgba(205,185,130,.10),transparent 35%),linear-gradient(180deg,rgba(255,255,255,.7),rgba(247,250,252,.92))!important;background-size:auto!important}
/* Principles cards use different quiet light fields, not repeated concentric circles or hand-drawn lines. */
.page[data-page="charter"] .principle:nth-child(4n+1){background:linear-gradient(145deg,#fff 0%,#f2f7fa 100%)!important}
.page[data-page="charter"] .principle:nth-child(4n+2){background:linear-gradient(145deg,#fffdf7 0%,#f7f3e9 100%)!important}
.page[data-page="charter"] .principle:nth-child(4n+3){background:linear-gradient(145deg,#f8fbfd 0%,#eaf2f6 100%)!important}
.page[data-page="charter"] .principle:nth-child(4n){background:linear-gradient(145deg,#fff 0%,#f3f0e7 100%)!important}
/* Shield cycle: trace draws fully, stays complete, then resets only at the end of the 8s cycle. */
.page[data-page="safety"] .safetySvg .safeShieldTrace{stroke-dasharray:100!important;stroke-dashoffset:100!important;animation:v21ShieldCycle 8s linear infinite!important}
@keyframes v21ShieldCycle{0%{stroke-dashoffset:100;opacity:.2}38%{stroke-dashoffset:0;opacity:1}88%{stroke-dashoffset:0;opacity:1}100%{stroke-dashoffset:100;opacity:.2}}
.page[data-page="safety"] .safetySvg .safeLock path:first-of-type{stroke-dasharray:70;stroke-dashoffset:70;animation:v21LockCycle 8s linear infinite!important}
@keyframes v21LockCycle{0%,30%{stroke-dashoffset:70;opacity:.35}52%,88%{stroke-dashoffset:0;opacity:1}100%{stroke-dashoffset:70;opacity:.35}}
/* Fresh collaboration illustration: question -> evidence -> shared action, with solid-line breathing loop. */
.joinVisual svg{overflow:visible!important}.joinVisual svg *{animation-play-state:running!important}
.joinVisual .joinNetwork,.joinVisual .joinSignal,.joinVisual .joinNode,.joinVisual .joinSpark{animation:none!important}
.joinVisual .joinNetwork{stroke:#8fc4dc!important;stroke-width:1.25!important;stroke-dasharray:none!important;opacity:.55}
.joinVisual .joinSignal{stroke:#e8c56e!important;stroke-width:2.1!important;stroke-dasharray:0!important;stroke-dashoffset:0!important;animation:v21JoinSignal 5.6s ease-in-out infinite!important}
.joinVisual .joinSignal.js2{animation-delay:-2.8s!important;opacity:.6}
.joinVisual .joinNode{fill:#123b59!important;stroke:#b6d7e8!important;stroke-width:1.6!important}
.joinVisual .joinSpark{fill:#f0d58e!important;filter:drop-shadow(0 0 5px #e8c56e55)!important;transform-box:fill-box;transform-origin:center;animation:v21JoinSpark 5.6s ease-in-out infinite!important}
@keyframes v21JoinSignal{0%,100%{opacity:.4;stroke-width:1.35}50%{opacity:1;stroke-width:2.3}}
@keyframes v21JoinSpark{0%,100%{opacity:.68;transform:scale(.94)}50%{opacity:1;transform:scale(1.04)}}
/* Rephrase report illustration microcopy: no repeated trace/compare/revise trio. */
.page[data-page="library"] .libraryVisualCopy .libraryPrinciples{display:none!important}
.page[data-page="library"] .libraryVisualCopy span{display:block;max-width:38ch;margin:12px auto 0;font-size:12px;line-height:1.9;letter-spacing:.025em;color:#71879a}
.page[data-page="library"] .libraryVisualCopy:after{content:attr(data-v21-microcopy);display:block;margin:15px auto 0;padding-top:12px;width:max-content;max-width:100%;border-top:1px solid #dbe5eb;color:#a18448;font-size:10px;letter-spacing:.12em;line-height:1.8}
@media(max-width:680px){#questionBankOverlay .questionBankPanel,#moreReportsOverlay .questionBankPanel{padding-left:17px!important;padding-right:17px!important}.page[data-page="library"] .libraryVisualCopy:after{font-size:9px;letter-spacing:.06em}}
@media(prefers-reduced-motion:reduce){#researchDashboard .dashChart.v21-play *,#researchDashboard .dashboardMetrics .v21-play *, .joinVisual .joinSignal,.joinVisual .joinSpark,.page[data-page="safety"] .safetySvg .safeShieldTrace,.page[data-page="safety"] .safetySvg .safeLock path:first-of-type{animation:none!important;stroke-dashoffset:0!important}}
`;document.head.append(s)}
function bindCharts(){const dash=$('#researchDashboard');if(!dash||dash.dataset.v21Bound)return;dash.dataset.v21Bound='1';/* Detach older click listeners; animate paint only and keep numeric labels fixed. */$$('.dashboardMetrics article,.dashChart',dash).forEach(node=>node.replaceWith(node.cloneNode(true)));const metrics=$$('.dashboardMetrics article',dash);const targets=[100,78.1,80,74.3];metrics.forEach((card,i)=>{const bar=$('.metricTrack i',card);if(bar){const target=targets[i]+'%';bar.style.setProperty('--metric-target',target);bar.style.width=target;bar.style.transform='scaleX(1)'}const play=()=>{card.classList.remove('v21-play');void card.offsetWidth;card.classList.add('v21-play')};card.addEventListener('click',play);card.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();play()}});card.tabIndex=0;card.setAttribute('role','button');card.setAttribute('aria-label',(card.querySelector('span')?.textContent||'统计指标')+'，点击播放进度动画')});$$('.dashChart',dash).forEach(card=>{card.setAttribute('role','button');card.tabIndex=0;const play=()=>{card.classList.remove('v21-play');void card.offsetWidth;card.classList.add('v21-play')};card.addEventListener('click',e=>{if(!e.target.closest('a'))play()});card.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();play()}})});}

function bindOfficialBaseline(){const board=$('.officialEvidenceBoard');if(!board||board.dataset.v21Bound)return;board.dataset.v21Bound='1';$$('.evidenceStats article',board).forEach(card=>{const clone=card.cloneNode(true);card.replaceWith(clone)});$$('.evidenceStats article',board).forEach(card=>{card.tabIndex=0;card.setAttribute('role','button');card.setAttribute('aria-label',(card.querySelector('span')?.textContent||'教育基线')+'，点击播放数据动画');const play=()=>{card.classList.remove('v21-baseline-play');void card.offsetWidth;card.classList.add('v21-baseline-play')};card.addEventListener('click',play);card.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();play()}})});}

function rebuildJoin(){/* Removed: legacy v21 renderer overwrote the authoritative v58 artwork on language changes. */}
function pinOverlayTop(){['questionBankOverlay','moreReportsOverlay'].forEach(id=>{const el=$('#'+id);if(el){el.style.position='fixed';el.style.inset='0';el.style.top='0';el.style.margin='0';el.style.padding='0';el.style.alignItems='flex-start';const panel=$('.questionBankPanel',el);if(panel){panel.style.marginTop='0';panel.style.borderTopLeftRadius='0';panel.style.borderTopRightRadius='0'}}})}
function bindModalObserver(){const mo=new MutationObserver(()=>{pinOverlayTop()});mo.observe(document.body,{childList:true});}
function updateLibraryLabels(){const en=document.documentElement.lang==='en';const sub=$('.libraryScene svg .libSubtext');if(sub){sub.textContent=en?'SOURCE CLEAR · DEFINITIONS OPEN · REGULAR UPDATES':'来源透明 · 口径清晰 · 持续更新';sub.setAttribute('data-en','SOURCE CLEAR · DEFINITIONS OPEN · REGULAR UPDATES');sub.setAttribute('data-zh','来源透明 · 口径清晰 · 持续更新')}const spans=$$('.libraryScene .sceneCaption span');const vals=en?['SOURCE','METHOD','UPDATE']:['来源','方法','更新'];spans.forEach((el,i)=>{if(i<3){el.textContent=vals[i];el.dataset.en=['SOURCE','METHOD','UPDATE'][i];el.dataset.zh=['来源','方法','更新'][i]}})}
function run(){installStyle();bindCharts();bindOfficialBaseline();pinOverlayTop();bindModalObserver();updateLibraryLabels();const btn=$('#langBtn');if(btn)btn.addEventListener('click',()=>setTimeout(()=>{bindCharts();bindOfficialBaseline();pinOverlayTop();updateLibraryLabels()},150));}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',run,{once:true});else run();
})();


/* ===== Consolidated legacy patch v22 ===== */
/* V22 focused repair pass: typography, continuous illustration motion, editorial textures, and stable chart playback. */
(()=>{'use strict';
const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
const css=document.createElement('style');css.id='v22-fixes-style';css.textContent=`
/* Hero: reduce the gap between the headline and its description, while lowering the headline slightly. */
.heroTextStage{display:flex!important;flex-direction:column!important;justify-content:flex-start!important;gap:5px!important;padding-top:12px!important;min-height:0!important}
.heroTextStage h1{margin:0 0 0!important;padding-top:7px!important;min-height:0!important;line-height:1.18!important;flex:0 0 auto!important}
.heroTextStage p{margin:0!important;padding-top:0!important;min-height:0!important;height:auto!important;max-height:none!important;line-height:1.8!important;-webkit-line-clamp:5!important;flex:0 0 auto!important}
@media(max-width:760px){.heroTextStage{gap:4px!important;padding-top:8px!important;min-height:0!important}.heroTextStage h1{padding-top:7px!important;min-height:0!important;font-size:clamp(30px,8vw,42px)!important;line-height:1.2!important}.heroTextStage p{height:auto!important;min-height:0!important;max-height:8.5em!important;-webkit-line-clamp:5!important}}
@media(max-width:420px){.heroTextStage h1{font-size:clamp(29px,8vw,36px)!important}}
/* Second and third focus illustrations now have their own low-key, continuous motion. */



.focusCard[data-kinetic="2"] .kineticSvg *, .focusCard[data-kinetic="3"] .kineticSvg *{animation-play-state:running!important}











/* Principles remain on the dark editorial canvas; each card gets a subtle, distinct quarter-disc motif. */
.page[data-page="charter"] .principle{background-color:#102f49!important;background-image:linear-gradient(135deg,rgba(255,255,255,.035),rgba(255,255,255,0)),linear-gradient(145deg,#153a55,#0b2942)!important;border-color:#ffffff20!important;isolation:isolate}
.page[data-page="charter"] .principle:before{content:"";position:absolute;pointer-events:none;z-index:0;width:190px;height:190px;right:-105px;top:-112px;border-radius:50%;border:1px solid rgba(151,197,218,.28);box-shadow:0 0 0 17px rgba(151,197,218,.045),0 0 0 34px rgba(151,197,218,.025);background:transparent;opacity:.9}
.page[data-page="charter"] .principle:nth-child(4n/**/+1):before{right:-92px;top:-122px;width:190px;height:190px;border-color:#9bcfe44a;box-shadow:0 0 0 20px #9bcfe40a,0 0 0 42px #9bcfe406}
.page[data-page="charter"] .principle:nth-child(4n/**/+2):before{right:-115px;top:auto;bottom:-126px;width:210px;height:210px;border-color:#e8c56e42;box-shadow:0 0 0 16px #e8c56e0a,0 0 0 36px #e8c56e05}
.page[data-page="charter"] .principle:nth-child(4n/**/+3):before{right:auto;left:-118px;top:-118px;width:200px;height:200px;border-color:#a8c4dc40;border-radius:42% 58% 48% 52%;box-shadow:0 0 0 18px #a8c4dc08,0 0 0 39px #a8c4dc04}
.page[data-page="charter"] .principle:nth-child(4n):before{right:-100px;top:-90px;width:170px;height:220px;border-color:#d8b87540;border-radius:50% 50% 8% 50%;box-shadow:0 0 0 17px #d8b87508,0 0 0 35px #d8b87504}
.page[data-page="charter"] .principle:nth-child(4n/**/+1),.page[data-page="charter"] .principle:nth-child(4n/**/+2),.page[data-page="charter"] .principle:nth-child(4n/**/+3),.page[data-page="charter"] .principle:nth-child(4n){background-color:#102f49!important;background-image:linear-gradient(135deg,rgba(255,255,255,.035),rgba(255,255,255,0)),linear-gradient(145deg,#153a55,#0b2942)!important}
.page[data-page="charter"] .principle h3{color:#f5f8fb!important}.page[data-page="charter"] .principle p{color:#c2cfdd!important}
.page[data-page="charter"] .principle .icon,.page[data-page="charter"] .principle>div:last-child{z-index:1}
/* Richer but restrained editorial backgrounds for issue mapping and the roadmap: large abstract fields, arcs and fine rules, never dot wallpaper. */
.page[data-page="issues"] .section{background-color:#f5f8fa!important;background-image:radial-gradient(ellipse at 0% 4%,rgba(119,174,199,.24),transparent 33%),radial-gradient(ellipse at 100% 94%,rgba(205,176,104,.18),transparent 30%),linear-gradient(128deg,transparent 0 58%,rgba(104,151,177,.07) 58.1% 58.35%,transparent 58.5%),linear-gradient(180deg,#fbfcfd 0%,#f1f6f8 100%)!important;background-size:auto!important;position:relative}
.page[data-page="issues"] .section:before{content:"";position:absolute;right:-110px;top:70px;width:330px;height:330px;border:1px solid #7ca9bf24;border-radius:50%;box-shadow:0 0 0 24px #7ca9bf09,0 0 0 52px #7ca9bf06;pointer-events:none}
.page[data-page="roadmap"] .section{background-color:#f6f8fa!important;background-image:radial-gradient(ellipse at 88% 5%,rgba(211,185,119,.22),transparent 34%),radial-gradient(ellipse at 8% 95%,rgba(116,171,198,.18),transparent 33%),linear-gradient(135deg,transparent 0 37%,rgba(124,158,176,.065) 37.1% 37.35%,transparent 37.5%),linear-gradient(180deg,#fbfcfd 0%,#eff4f7 100%)!important;background-size:auto!important;position:relative}
.page[data-page="roadmap"] .section:before{content:"";position:absolute;left:-125px;bottom:45px;width:300px;height:300px;border:1px solid #d1b46d2b;border-radius:47% 53% 50% 50%;box-shadow:0 0 0 22px #d1b46d08,0 0 0 46px #d1b46d05;pointer-events:none}
.page[data-page="issues"] .container,.page[data-page="roadmap"] .container{position:relative;z-index:1}
/* Chart animations: avoid number-width reflow, draw SVG lines without important offset locks, and reveal the donut as a whole. */
#researchDashboard .dashboardMetrics strong{font-variant-numeric:tabular-nums;white-space:nowrap;display:block;min-width:0}
#researchDashboard .dashboardMetrics article{min-width:0;overflow:hidden}
#researchDashboard .dashboardMetrics .metricTrack{height:4px;overflow:hidden;border-radius:99px}
#researchDashboard .dashboardMetrics .metricTrack i{width:var(--metric-target,0%);transform:scaleX(1);transform-origin:left center;transition:none!important}
#researchDashboard .dashboardMetrics article.v21-play .metricTrack i{animation:v22MetricFill 1.05s cubic-bezier(.2,.7,.2,1) both!important}
@keyframes v22MetricFill{from{transform:scaleX(0)}to{transform:scaleX(1)}}
#researchDashboard .dashLine{stroke-dasharray:100!important;stroke-dashoffset:100;animation:none}
#researchDashboard .dashChart.v21-play .dashLine{animation:v22LineDraw 2s cubic-bezier(.35,.05,.25,1) both!important}
#researchDashboard .radarTrace{stroke-dasharray:100!important;stroke-dashoffset:100;animation:none}
#researchDashboard .dashChart.v21-play .radarTrace{animation:v22LineDraw 1.8s ease-out both!important}
@keyframes v22LineDraw{from{stroke-dashoffset:100}to{stroke-dashoffset:0}}
#researchDashboard .dashDonut{background:conic-gradient(#1e658d 0 78.1%,#d5b05a 78.1% 100%)!important;clip-path:inset(0 0 0 0 round 50%);transform-origin:center}
#researchDashboard .dashChart.v21-play .dashDonut{animation:v22DonutReveal 1.35s cubic-bezier(.2,.7,.2,1) both!important}
@keyframes v22DonutReveal{0%{clip-path:inset(50% 50% 50% 50% round 50%);transform:rotate(-90deg) scale(.84);opacity:.2}100%{clip-path:inset(0 0 0 0 round 50%);transform:rotate(0) scale(1);opacity:1}}
#researchDashboard .dashChart.v21-play .dashDonut>div{animation:v22DonutText .6s .35s both}
@keyframes v22DonutText{from{opacity:.2}to{opacity:1}}
@media(prefers-reduced-motion:reduce){}
`;
document.head.append(css);
// Remove the count-up handlers installed by V21 from the displayed values: width changes were causing visible jitter.
function stableMetrics(){const dash=$('#researchDashboard');if(!dash)return;$$('.dashboardMetrics article',dash).forEach(card=>{const strong=$('strong',card);if(strong){const small=$('small',strong);const original=strong.dataset.v22Original;if(original)strong.childNodes[0].textContent=original;else strong.dataset.v22Original=strong.childNodes[0]?.textContent||''}const bar=$('.metricTrack i',card);if(bar){const raw=bar.getAttribute('data-width')||bar.style.getPropertyValue('--metric-target')||'100%';bar.style.width=raw;bar.style.setProperty('--metric-target',raw);}})}
function updateHeading(){const en=document.documentElement.lang==='en';const kicker=$('#researchDashboard .dashboardHead .kicker');if(kicker)kicker.textContent=en?'OFFICIAL STATISTICS / DATA LITERACY':'官方统计 / 数据素养';}
function run(){stableMetrics();updateHeading();const btn=$('#langBtn');if(btn&&!btn.dataset.v22Bound){btn.dataset.v22Bound='1';btn.addEventListener('click',()=>setTimeout(()=>{stableMetrics();updateHeading()},220))}}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',run,{once:true});else run();
})();


/* ===== Consolidated legacy patch v23 ===== */
/* V23 repair pass: reliable chart playback, accurate fiscal/GDP ring, 256-question bank, and consistent bilingual microcopy. */
(()=>{'use strict';
const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
const style=document.createElement('style');style.id='v23-fixes-style';style.textContent=`
/* Research dashboard: bars retain their true target widths; animation uses compositor transforms. */
#researchDashboard .dashboardMetrics article{cursor:pointer;user-select:none;min-width:0;overflow:hidden}
#researchDashboard .dashboardMetrics strong{font-variant-numeric:tabular-nums;white-space:nowrap;letter-spacing:-.025em}
#researchDashboard .dashboardMetrics .metricTrack{height:4px;overflow:hidden;border-radius:99px}
#researchDashboard .dashboardMetrics .metricTrack i{display:block;transform:scaleX(1);transform-origin:left center;transition:none!important}
#researchDashboard .dashBars i b{display:block;width:var(--v,0%);transform:scaleX(1);transform-origin:left center;transition:none!important}
#researchDashboard .dashLine{stroke-dasharray:100!important;stroke-dashoffset:0;animation:none!important}
#researchDashboard .dashDonut{--v23-share:78.1%;background:conic-gradient(#1e658d 0 var(--v23-share),#d5b05a var(--v23-share) 100%)!important;clip-path:none!important;transform-origin:center;opacity:1}
@property --v23-share{syntax:'<percentage>';inherits:false;initial-value:78.1%}
#researchDashboard .radarTrace{stroke-dasharray:100!important;stroke-dashoffset:0;animation:none!important}
/* The official-baseline bars and 4.02% ring encode their actual data, not decorative full-circle values. */
.officialEvidenceBoard .yearCompare i{width:var(--w)!important;max-width:100%;display:block;transform:scaleX(1);transform-origin:left center;animation:none!important}
.officialEvidenceBoard .evidenceRing .ringValue{stroke-dasharray:245.04;stroke-dashoffset:235.19;stroke-linecap:round;animation:none!important}
.officialEvidenceBoard .evidenceStats article{cursor:pointer;user-select:none}
/* Question bank: clean category labels, strong legibility, stable responsive controls. */
#questionBankOverlay .questionBankTotal{display:inline-block;margin-top:8px;color:#9b7936;font-size:10px;letter-spacing:.06em}
#questionBankOverlay .questionBankTools{display:grid;grid-template-columns:minmax(0,1fr) minmax(170px,.45fr) auto;gap:10px;align-items:center}
#questionBankOverlay .questionBankTools input,#questionBankOverlay .questionBankTools select{min-width:0;width:100%;box-sizing:border-box;color:#163b59;background:#fff;border:1px solid #d2dee7;border-radius:8px;padding:12px;font:inherit;font-size:13px}
#questionBankOverlay .questionBankResults{display:grid;grid-template-columns:1fr 1fr;gap:9px;margin-top:16px}
#questionBankOverlay .questionBankItem{align-self:start;border:1px solid #dce5ec;border-radius:9px;background:linear-gradient(145deg,#fff,#f8fafc);overflow:hidden}
#questionBankOverlay .questionBankItem summary{display:grid;grid-template-columns:1fr auto;gap:7px;padding:14px;cursor:pointer;list-style:none;color:#183b58;font-size:12px;font-weight:650;line-height:1.6}
#questionBankOverlay .questionBankItem summary::-webkit-details-marker{display:none}
#questionBankOverlay .questionBankItem summary>b{color:#b58d3b;font-size:18px}
#questionBankOverlay .questionBankItem[open]{border-color:#d0b36d;box-shadow:0 8px 22px #102f4a0b}
#questionBankOverlay .questionBankCat{grid-column:1/-1;color:#a17b2d;font-size:9px;letter-spacing:.08em;font-weight:750}
#questionBankOverlay .questionBankItem>p{margin:0;padding:0 14px 15px;color:#62768a;font-size:12px;line-height:1.85}
/* A quiet, premium motif fills the unused right side of the discussion group card without competing with content. */
.page[data-page="join"] .joinPanel{position:relative;isolation:isolate;overflow:hidden;background:linear-gradient(145deg,#fff 0%,#f7fafc 57%,#edf4f7 100%)!important;border:1px solid #d7e3eb!important;box-shadow:0 24px 65px #09284612}
.page[data-page="join"] .joinPanel:before{content:"";position:absolute;z-index:-1;right:-110px;top:-100px;width:300px;height:300px;border:1px solid #8bb8ce45;border-radius:50%;box-shadow:0 0 0 22px #8bb8ce0c,0 0 0 48px #8bb8ce08,0 0 0 78px #d4b56b0a;pointer-events:none}
.page[data-page="join"] .joinPanel:after{content:"";position:absolute;z-index:-1;right:18px;bottom:20px;width:135px;height:75px;border-top:1px solid #c8a95d55;border-bottom:1px solid #8bb8ce38;transform:skewY(-23deg);pointer-events:none}
.page[data-page="join"] .joinPanel>*{position:relative;z-index:1}
/* New safety illustration: one complete shield, one lock that closes, and three equally weighted labels. */
.page[data-page="safety"] .safetySvg{overflow:visible}
.page[data-page="safety"] .safetySvg .v23ShieldTrace{stroke-dasharray:100;stroke-dashoffset:100;animation:v23Shield 8s cubic-bezier(.45,0,.25,1) infinite}
.page[data-page="safety"] .safetySvg .v23LockShackle{stroke-dasharray:100;stroke-dashoffset:100;animation:v23Lock 8s cubic-bezier(.45,0,.25,1) infinite}
.page[data-page="safety"] .safetySvg .v23LockCore{transform-box:fill-box;transform-origin:center;animation:v23Core 8s ease-in-out infinite}
.page[data-page="safety"] .safetySvg .v23ShieldHalo{transform-box:fill-box;transform-origin:center;animation:v23Halo 8s ease-in-out infinite}
.page[data-page="safety"] .safetySvg .v23Check{stroke-dasharray:100;stroke-dashoffset:100;animation:v23Check 8s ease-in-out infinite}
@keyframes v23Shield{0%,5%{stroke-dashoffset:100;opacity:.3}38%,86%{stroke-dashoffset:0;opacity:1}100%{stroke-dashoffset:100;opacity:.3}}
@keyframes v23Lock{0%,27%{stroke-dashoffset:100;opacity:.3}49%,86%{stroke-dashoffset:0;opacity:1}100%{stroke-dashoffset:100;opacity:.3}}
@keyframes v23Core{0%,40%{opacity:.25;transform:scale(.88)}55%,86%{opacity:1;transform:scale(1)}100%{opacity:.25;transform:scale(.88)}}
@keyframes v23Halo{0%,100%{opacity:.45;transform:scale(.97)}50%{opacity:.95;transform:scale(1.04)}}
@keyframes v23Check{0%,48%{stroke-dashoffset:100;opacity:.2}62%,86%{stroke-dashoffset:0;opacity:1}100%{stroke-dashoffset:100;opacity:.2}}
@media(max-width:680px){#questionBankOverlay .questionBankTools{grid-template-columns:1fr}#questionBankOverlay .questionBankResults{grid-template-columns:1fr}#questionBankOverlay .questionBankTotal{font-size:9px}}
@media(prefers-reduced-motion:reduce){#researchDashboard .dashChart *,#researchDashboard .dashboardMetrics *, .officialEvidenceBoard .yearCompare i,.officialEvidenceBoard .evidenceRing .ringValue,.page[data-page="safety"] .safetySvg .v23ShieldTrace,.page[data-page="safety"] .safetySvg .v23LockShackle,.page[data-page="safety"] .safetySvg .v23LockCore,.page[data-page="safety"] .safetySvg .v23ShieldHalo,.page[data-page="safety"] .safetySvg .v23Check{animation:none!important;transition:none!important;stroke-dashoffset:0!important;transform:none!important}.officialEvidenceBoard .evidenceRing .ringValue{stroke-dashoffset:235.19!important}}
`;
document.head.append(style);
function animate(el,keyframes,opts={}){if(!el)return null;if(!el.animate||matchMedia('(prefers-reduced-motion: reduce)').matches){if(opts.finish)opts.finish(el);return null}try{el.getAnimations().forEach(a=>a.cancel());const a=el.animate(keyframes,{duration:opts.duration||1300,easing:opts.easing||'cubic-bezier(.2,.7,.2,1)',fill:'forwards'});a.onfinish=()=>{if(opts.finish)opts.finish(el);a.cancel()};return a}catch(_){return null}}
function bindDashboard(){const dash=$('#researchDashboard');if(!dash||dash.dataset.v23Bound==='1')return;dash.dataset.v23Bound='1';
 // Clone cards to detach older click listeners whose competing width/dash-offset animations caused jumps and disappearing paths.
 $$('.dashboardMetrics article,.dashChart',dash).forEach(el=>el.replaceWith(el.cloneNode(true)));
 const metricTargets=['100%','78.1%','4%','14.86%'];
 $$('.dashboardMetrics article',dash).forEach((card,i)=>{const bar=$('.metricTrack i',card);if(bar){const raw=bar.getAttribute('data-width')||metricTargets[i]||'100%';bar.style.width=raw;bar.style.setProperty('--metric-target',raw);bar.style.transform='scaleX(1)';bar.style.transformOrigin='left center'}card.setAttribute('role','button');card.tabIndex=0;card.setAttribute('aria-label',(($('span',card)||{}).textContent||'统计指标')+' — 播放进度条动画');const play=()=>{const b=$('.metricTrack i',card);if(!b)return;animate(b,[{transform:'scaleX(0)'},{transform:'scaleX(1)'}],{duration:1150,finish:el=>el.style.transform='scaleX(1)'});};card.addEventListener('click',play);card.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();play()}})});
 $$('.dashChart',dash).forEach(card=>{card.setAttribute('role','button');card.tabIndex=0;card.setAttribute('aria-label',($('.dashChartTop h4',card)?.textContent||'数据图表')+' — 点击播放动画');const play=()=>{
   const bars=$$('.dashBars i b',card);if(bars.length){bars.forEach(b=>{const target=b.style.getPropertyValue('--v')||'100%';b.style.width=target;animate(b,[{transform:'scaleX(0)'},{transform:'scaleX(1)'}],{duration:1250,finish:el=>el.style.transform='scaleX(1)'})})}
   const line=$('.dashLine',card);if(line){line.style.strokeDasharray='100';line.style.strokeDashoffset='100';animate(line,[{strokeDashoffset:'100'},{strokeDashoffset:'0'}],{duration:1900,finish:el=>el.style.strokeDashoffset='0'})}
   const donut=$('.dashDonut',card);if(donut){donut.style.setProperty('--v23-share','0%');donut.style.transform='scale(.96)';donut.style.opacity='.7';animate(donut,[{transform:'scale(.96)',opacity:.7,'--v23-share':'0%'},{transform:'scale(1)',opacity:1,'--v23-share':'78.1%'}],{duration:1450,finish:el=>{el.style.setProperty('--v23-share','78.1%');el.style.transform='scale(1)';el.style.opacity='1'}})}
   const trace=$('.radarTrace',card);if(trace){trace.style.strokeDashoffset='100';animate(trace,[{strokeDashoffset:'100'},{strokeDashoffset:'0'}],{duration:1700,finish:el=>el.style.strokeDashoffset='0'})}
   $$('.radarPoints circle',card).forEach((point,i)=>animate(point,[{transform:'scale(.35)',opacity:.3},{transform:'scale(1)',opacity:1}],{duration:420+i*45,finish:el=>{el.style.opacity='1';el.style.transform='scale(1)'}}));
 };card.addEventListener('click',e=>{if(!e.target.closest('a,button'))play()});card.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();play()}})});
}
function bindOfficialBaseline(){const board=$('.officialEvidenceBoard');if(!board||board.dataset.v23Bound==='1')return;board.dataset.v23Bound='1';
 $$('.evidenceStats article',board).forEach(card=>card.replaceWith(card.cloneNode(true)));
 $$('.evidenceStats article',board).forEach(card=>{card.tabIndex=0;card.setAttribute('role','button');card.setAttribute('aria-label',(($('span',card)||{}).textContent||'教育基线')+' — 播放数据动画');const play=()=>{
   $$('.yearCompare i',card).forEach(bar=>{bar.style.width=bar.style.getPropertyValue('--w')||'100%';animate(bar,[{transform:'scaleX(0)'},{transform:'scaleX(1)'}],{duration:1150,finish:el=>el.style.transform='scaleX(1)'})});
   const ring=$('.ringValue',card);if(ring){ring.style.strokeDasharray='245.04';ring.style.strokeDashoffset='245.04';animate(ring,[{strokeDashoffset:'245.04'},{strokeDashoffset:'235.19'}],{duration:1350,finish:el=>el.style.strokeDashoffset='235.19'})}
 };card.addEventListener('click',play);card.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();play()}})});
}
function redesignSafety(){const svg=$('.page[data-page="safety"] .safetySvg');if(!svg||svg.dataset.v23Built==='1')return;svg.dataset.v23Built='1';svg.setAttribute('viewBox','0 0 460 430');svg.innerHTML=`<defs><linearGradient id="v23SafeMetal" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#f3df9c"/><stop offset=".45" stop-color="#8fc9e2"/><stop offset="1" stop-color="#c49c4b"/></linearGradient><linearGradient id="v23SafeGlass" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#1b5275" stop-opacity=".95"/><stop offset="1" stop-color="#071d34" stop-opacity=".98"/></linearGradient><radialGradient id="v23SafeAura"><stop stop-color="#6eb9da" stop-opacity=".24"/><stop offset="1" stop-color="#6eb9da" stop-opacity="0"/></radialGradient></defs><circle class="v23ShieldHalo" cx="230" cy="204" r="174" fill="url(#v23SafeAura)"/><circle cx="230" cy="204" r="143" fill="none" stroke="#9bcde4" stroke-opacity=".13"/><circle cx="230" cy="204" r="119" fill="none" stroke="#e8c56e" stroke-opacity=".13" stroke-dasharray="2 10"/><path d="M230 55 341 100v91c0 83-45 139-111 178-66-39-111-95-111-178v-91z" fill="url(#v23SafeGlass)" stroke="#9bcde4" stroke-opacity=".45" stroke-width="1.2"/><path class="v23ShieldTrace" pathLength="100" d="M230 55 341 100v91c0 83-45 139-111 178-66-39-111-95-111-178v-91z" fill="none" stroke="url(#v23SafeMetal)" stroke-width="3.2" stroke-linejoin="round" stroke-linecap="round"/><path d="M230 82 316 117v74c0 65-34 111-86 144-52-33-86-79-86-144v-74z" fill="none" stroke="#9bcde4" stroke-opacity=".24" stroke-width="1.2"/><g class="v23LockCore"><rect x="190" y="190" width="80" height="66" rx="10" fill="#0b2943" stroke="#e8c56e" stroke-width="2"/><path class="v23LockShackle" pathLength="100" d="M204 192v-17a26 26 0 0 1 52 0v17" fill="none" stroke="url(#v23SafeMetal)" stroke-width="5" stroke-linecap="round"/><circle cx="230" cy="218" r="6" fill="#f2d990"/><path d="M230 224v12" stroke="#f2d990" stroke-width="4" stroke-linecap="round"/></g><path class="v23Check" pathLength="100" d="m194 285 24 22 49-54" fill="none" stroke="#f1d68b" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/><path d="M148 326q82 37 164 0" fill="none" stroke="#9bcde4" stroke-opacity=".28" stroke-width="1.2"/><g fill="#e8c56e"><circle cx="100" cy="154" r="3"/><circle cx="360" cy="154" r="3"/><circle cx="129" cy="292" r="2.5"/><circle cx="331" cy="292" r="2.5"/></g><text x="230" y="394" text-anchor="middle" fill="#d3e4ef" font-size="11" letter-spacing="2.2" data-en="SAFETY · PRIVACY · ACCESS" data-zh="安全 · 隐私 · 无障碍">安全 · 隐私 · 无障碍</text>`;
 const captions=$$('.page[data-page="safety"] .sceneCaption span');const en=document.documentElement.lang==='en';const zh=['少量采集','严格访问','安全留存'],eng=['MINIMISE DATA','LIMIT ACCESS','SECURE STORAGE'];captions.forEach((el,i)=>{el.textContent=(en?eng:zh)[i]||'';el.dataset.zh=zh[i]||'';el.dataset.en=eng[i]||''});
}
function updateCopy(){const en=document.documentElement.lang==='en';const safetyCaptions=$$('.page[data-page="safety"] .sceneCaption span');const safetyZh=['少量采集','严格访问','安全留存'],safetyEn=['MINIMISE DATA','LIMIT ACCESS','SECURE STORAGE'];safetyCaptions.forEach((el,i)=>{el.textContent=(en?safetyEn:safetyZh)[i]||'';el.dataset.zh=safetyZh[i]||'';el.dataset.en=safetyEn[i]||''});const join=$('[data-i="join_title"]');if(join&&!en)join.textContent='把问题变成证据，再把证据变成行动，教育才会改变。';const scene=$('.page[data-page="library"] .libraryScene');if(scene){const sub=$('.libSubtext',scene);if(sub){sub.textContent=en?'TRACEABLE · COMPARABLE · REVISABLE':'来源透明 · 口径清晰 · 持续更新';}const spans=$$('.sceneCaption span',scene);const zh=['追溯','比较','修订'],eng=['TRACE','COMPARE','REVISE'];spans.forEach((el,i)=>{el.textContent=(en?eng:zh)[i]||'';el.dataset.zh=zh[i]||'';el.dataset.en=eng[i]||''})}}
function run(){bindDashboard();bindOfficialBaseline();redesignSafety();updateCopy();const lang=$('#langBtn');if(lang&&!lang.dataset.v23Bound){lang.dataset.v23Bound='1';lang.addEventListener('click',()=>setTimeout(()=>{bindDashboard();bindOfficialBaseline();redesignSafety();updateCopy()},300))}}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',run,{once:true});else run();
})();


/* ===== Consolidated legacy patch v24 ===== */
/* V24 stability pass: legible editorial cards, bilingual units/annotations, and replayable chart motion. */
(()=>{'use strict';
const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
const css=document.createElement('style');css.id='v24-fixes-style';css.textContent=`
/* Organisational principles: restore the dark editorial cards and give each one a distinct, restrained motif. */
.page[data-page="charter"] .principles .principle,
.page[data-page="charter"] .principles .principle:nth-child(4n+1),
.page[data-page="charter"] .principles .principle:nth-child(4n+2),
.page[data-page="charter"] .principles .principle:nth-child(4n+3),
.page[data-page="charter"] .principles .principle:nth-child(4n){
 position:relative!important;isolation:isolate!important;overflow:hidden!important;
 background-color:#102f49!important;
 background-image:linear-gradient(135deg,#173d59 0%,#0b2942 76%)!important;
 border:1px solid #8ebbd127!important;box-shadow:0 12px 30px #0317281a!important;
}
.page[data-page="charter"] .principles .principle:before{content:""!important;position:absolute!important;inset:0!important;width:auto!important;height:auto!important;right:0!important;top:0!important;border:0!important;border-radius:inherit!important;box-shadow:none!important;opacity:.72!important;pointer-events:none!important;z-index:0!important;transform:none!important}
.page[data-page="charter"] .principles .principle:nth-child(4n+1):before{background:radial-gradient(circle at 100% 0%,transparent 0 52px,#9bcfe42b 53px 54px,transparent 55px 72px,#9bcfe414 73px 74px,transparent 75px),linear-gradient(130deg,transparent 68%,#9bcfe40b 68.2% 100%)}
.page[data-page="charter"] .principles .principle:nth-child(4n+2):before{background:linear-gradient(135deg,transparent 0 65%,#e8c56e0b 65.2% 78%,transparent 78.2%),repeating-linear-gradient(135deg,transparent 0 17px,#e8c56e12 18px,#e8c56e12 19px,transparent 20px 35px);mask-image:linear-gradient(135deg,transparent 30%,#000 100%)}
.page[data-page="charter"] .principles .principle:nth-child(4n+3):before{background:radial-gradient(ellipse at 100% 100%,#8fc4dc20,transparent 58%),linear-gradient(90deg,transparent 0 82%,#8fc4dc13 82.2% 82.8%,transparent 83%),linear-gradient(0deg,transparent 0 80%,#8fc4dc13 80.2% 80.8%,transparent 81%)}
.page[data-page="charter"] .principles .principle:nth-child(4n):before{background:linear-gradient(120deg,transparent 0 58%,#d9b76a0c 58.2% 59%,transparent 59.2%),linear-gradient(145deg,transparent 0 67%,#d9b76a17 67.2% 67.8%,transparent 68%),radial-gradient(ellipse at 100% 0%,#d9b76a17,transparent 54%)}
.page[data-page="charter"] .principles .principle h3{position:relative;z-index:1!important;color:#f5f8fb!important}
.page[data-page="charter"] .principles .principle p{position:relative;z-index:1!important;color:#c7d6e2!important}
.page[data-page="charter"] .principles .principle .icon{position:relative;z-index:1!important}
/* Issue map and roadmap: more visible editorial geometry, not dot wallpaper. */
.page[data-page="issues"] .section{position:relative;isolation:isolate;background-color:#f5f8fa!important;background-image:linear-gradient(118deg,#ffffffd9 0%,#f2f7fae8 47%,#f9f6edeb 100%),linear-gradient(90deg,transparent 0 9.8%,#80a9bd15 10% 10.12%,transparent 10.3% 100%)!important}
.page[data-page="issues"] .section:before{content:"";position:absolute;pointer-events:none;z-index:0;right:-90px;top:120px;width:370px;height:470px;opacity:.72;background:linear-gradient(145deg,transparent 0 45%,#8fb8cb1a 45.2% 45.8%,transparent 46%),linear-gradient(145deg,transparent 0 57%,#c3a45d13 57.2% 57.8%,transparent 58%),radial-gradient(ellipse at 100% 0%,#8ebbd51e,transparent 68%);clip-path:polygon(18% 0,100% 0,100% 100%,0 82%,32% 42%)}
.page[data-page="issues"] .section:after{content:"ISSUE MAP / 01—32";position:absolute;right:26px;bottom:25px;pointer-events:none;z-index:0;color:#476d8418;font-size:10px;letter-spacing:.24em;font-weight:800;writing-mode:vertical-rl}
.page[data-page="roadmap"]>.section.paper:first-child{position:relative;isolation:isolate;background-color:#f7f9fa!important;background-image:linear-gradient(180deg,#fbfcfde8 0%,#f0f5f8f0 100%),linear-gradient(90deg,transparent 0 7%,#83adbf12 7.1% 7.2%,transparent 7.3%)!important}
.page[data-page="roadmap"]>.section.paper:first-child:before{content:"";position:absolute;pointer-events:none;z-index:0;left:-110px;top:210px;width:340px;height:450px;opacity:.65;background:linear-gradient(42deg,transparent 0 49%,#d2b66c1c 49.2% 49.7%,transparent 49.9%),linear-gradient(42deg,transparent 0 63%,#84b4ca20 63.2% 63.7%,transparent 63.9%),radial-gradient(ellipse at 0% 100%,#9cc5d91e,transparent 66%);clip-path:polygon(0 0,100% 15%,85% 100%,0 88%)}
.page[data-page="roadmap"]>.section.paper:first-child:after{content:"RESEARCH → TEST → REVIEW";position:absolute;right:30px;top:180px;writing-mode:vertical-rl;font-size:9px;letter-spacing:.23em;color:#426a801c;font-weight:800;pointer-events:none;z-index:0}
.page[data-page="issues"] .container,.page[data-page="roadmap"]>.section.paper:first-child .container{position:relative;z-index:1}
/* Discussion panel: use the existing CERP emblem as a quiet watermark in the available right-hand space. */
.page[data-page="join"] .joinPanel{position:relative!important;isolation:isolate!important;overflow:hidden!important;padding-right:148px!important;min-height:205px;background:linear-gradient(145deg,#fff 0%,#f7fafc 60%,#edf4f7 100%)!important}
.page[data-page="join"] .joinPanel .joinEmblem{position:absolute;z-index:0;right:12px;top:50%;width:126px;height:126px;object-fit:contain;transform:translateY(-50%);opacity:.23;mix-blend-mode:multiply;pointer-events:none}
.page[data-page="join"] .joinPanel>*:not(.joinEmblem){position:relative;z-index:1}
@media(max-width:760px){.page[data-page="join"] .joinPanel{padding-right:120px!important}.page[data-page="join"] .joinPanel .joinEmblem{width:104px;height:104px;right:8px}}
@media(max-width:420px){.page[data-page="join"] .joinPanel{padding-right:98px!important}.page[data-page="join"] .joinPanel .joinEmblem{width:82px;height:82px;right:5px}}
/* Numeric panels: tabular digits and reserved width prevent the long currency counters from jittering. */
#researchDashboard .dashboardMetrics article{cursor:pointer;min-width:0}
#researchDashboard .dashboardMetrics strong{display:flex!important;align-items:baseline;flex-wrap:wrap;gap:4px;min-height:2.1em;font-variant-numeric:tabular-nums;white-space:normal!important;letter-spacing:-.025em;line-height:1.1}
#researchDashboard .dashboardMetrics strong .v24-number{display:inline-block;min-width:8.6ch;width:8.6ch;font-variant-numeric:tabular-nums;white-space:nowrap}
#researchDashboard .dashboardMetrics strong small{display:inline-block;white-space:normal;max-width:100%;font-size:10px!important;line-height:1.3}
#researchDashboard .dashboardMetrics .metricTrack{height:4px;overflow:hidden;border-radius:99px}
#researchDashboard .dashboardMetrics .metricTrack i{display:block;transform-origin:left center;transition:none!important}
#researchDashboard .dashboardMetrics article:focus-visible,#researchDashboard .dashChart:focus-visible,.researchReport .barChart:focus-visible,.researchReport .bigMetricRule:focus-visible{outline:2px solid #b58d3b;outline-offset:3px}
@media(max-width:760px){#researchDashboard .dashboardMetrics strong{font-size:clamp(19px,4.5vw,25px)!important;min-height:2.5em}#researchDashboard .dashboardMetrics strong small{font-size:9px!important}}
/* Preserve the real 78.1 / 21.9 split, but reveal the chart on each click. */
#researchDashboard .dashDonut{background:conic-gradient(#1e658d 0 78.1%,#d5b05a 78.1% 100%)!important;clip-path:inset(0 0 0 0 round 50%)!important;transform:rotate(0) scale(1);opacity:1}
#researchDashboard .dashDonut.v24-donut-playing{animation:v24DonutReveal 1.35s cubic-bezier(.2,.7,.2,1) both!important}
@keyframes v24DonutReveal{0%{clip-path:inset(50% 50% 50% 50% round 50%);transform:rotate(-90deg) scale(.84);opacity:.18}100%{clip-path:inset(0 0 0 0 round 50%);transform:rotate(0) scale(1);opacity:1}}
#researchDashboard .dashDonut>div{position:relative;z-index:1}
#researchDashboard .dashLine{stroke-dasharray:100!important;stroke-dashoffset:0!important;animation:none!important}
#researchDashboard .dashLineNodes{opacity:1}
#researchDashboard .dashChart.v24-line-playing .dashLine{animation:v24LineDraw 1.9s cubic-bezier(.35,.05,.25,1) both!important}
@keyframes v24LineDraw{from{stroke-dashoffset:100}to{stroke-dashoffset:0}}
/* Report charts beneath “turn official statistics into testable questions”. */
.researchReport .barChart,.researchReport .bigMetricRule{cursor:pointer}
.researchReport .barChart .barTrack{overflow:hidden}
.researchReport .barChart .barTrack i,.researchReport .bigMetricRule i{display:block;transform:scaleX(1);transform-origin:left center;transition:none!important}
.researchReport .barChart.v24-play .barTrack i,.researchReport .bigMetricRule.v24-play i{animation:v24ReportBar 1.15s cubic-bezier(.2,.7,.2,1) both!important}
@keyframes v24ReportBar{from{transform:scaleX(0)}to{transform:scaleX(1)}}
.researchReport .barChart:focus-visible,.researchReport .bigMetricRule:focus-visible{outline:2px solid #b58d3b;outline-offset:3px}
/* Every visible research-dashboard annotation is translated together with the language switch. */
#researchDashboard .dashboardFoot{font-size:10px;line-height:1.8}
#researchDashboard .dashboardFoot a{color:#1d5e83}
.researchReport .chartNote{line-height:1.8}
@media(prefers-reduced-motion:reduce){#researchDashboard .dashDonut.v24-donut-playing,#researchDashboard .dashChart.v24-line-playing .dashLine,#researchDashboard .dashboardMetrics .metricTrack i,.researchReport .barChart.v24-play .barTrack i,.researchReport .bigMetricRule.v24-play i{animation:none!important;transform:none!important;stroke-dashoffset:0!important}}
`;
document.head.append(css);
const researchCopy={
'教育经费投入':'Education expenditure','2024 年全国教育经费总投入（亿元）':'Total education expenditure in 2024 (RMB billion)','经费总投入':'Total expenditure','国家财政性':'State fiscal funds','单位：亿元。国家财政性教育经费为总投入的组成部分，不可与总投入相加。':'Unit: RMB billion. State fiscal education funds are included in total expenditure and must not be added to it.','来源：教育部、国家统计局、财政部《2024年全国教育经费执行情况统计公告》 ↗':'Source: 2024 National Education Expenditure Statistical Bulletin, Ministry of Education, National Bureau of Statistics and Ministry of Finance ↗','2023 年对比数据原始公告 ↗':'Original 2023 comparison bulletin ↗',
'生均公共预算教育经费':'General public-budget education expenditure per person','2024 年全国平均 · 元 / 人':'2024 national average · yuan per person','元 / 人':'yuan / person','全国按在校学生人数平均的一般公共预算教育经费':'General public-budget education expenditure averaged across enrolled learners nationwide','同比增长':'Year-on-year growth','生均教育事业费支出':'Operating expenditure per person','生均公用经费支出':'Public operating funds per person','全国均值不等于每所学校的实际资源；需结合省份、学段、城乡和学生需求作进一步分析。':'The national average is not the actual resource level of every school. Further analysis should consider province, education stage, urban/rural context and learner needs.','来源：教育部、国家统计局、财政部《2024年全国教育经费执行情况统计公告》 ↗':'Source: 2024 National Education Expenditure Statistical Bulletin, Ministry of Education, National Bureau of Statistics and Ministry of Finance ↗',
'教育机会与公平：应继续追问什么':'Educational opportunity and equity: questions to investigate','官方统计提供总体基线，但不足以单独解释差异。':'Official statistics provide an overall baseline but cannot explain differences on their own.','地区差异':'Regional differences','对比省际生均投入、教师配置、学校可及性与家庭负担。':'Compare per-person spending, teacher allocation, school access and family costs across provinces.','城乡差异':'Urban–rural differences','区分学校资源、通勤距离、数字设备与课程可选范围。':'Compare school resources, travel distance, digital access and course options.','学生体验':'Learner experience','用匿名、具代表性的调查检验睡眠、压力、归属感与学习投入。':'Use anonymous, representative surveys to examine sleep, stress, belonging and learning engagement.','结果指标':'Outcome measures','同时观察学习进步、身心健康、机会公平与长期发展，不以单一考试指标代替全部结果。':'Track learning progress, wellbeing, equity and long-term development rather than relying on a single exam metric.','研究结论与数据边界':'Research findings and data limits','可验证的事实与待研究假设分开呈现。':'Separate verifiable facts from hypotheses that still require research.','这些全国汇总数据不能直接证明学生压力的成因、地区资源分配是否公平或某项改革的因果效果。':'These national aggregates do not directly establish the causes of student stress, whether regional allocation is fair, or the causal effects of a reform.','下一步应取得可比的省级/学段数据，预先定义指标，披露缺失值、样本与方法，并避免把相关性写成因果关系。':'Next, obtain comparable province- and education-stage data, define indicators in advance, disclose missing values, samples and methods, and avoid presenting correlation as causation.',
'2024 年全国教育经费总投入（亿元）':'Total education expenditure in 2024 (RMB billion)','来源：教育部、国家统计局、财政部《2024年全国教育经费执行情况统计公告》 ↗':'Source: 2024 National Education Expenditure Statistical Bulletin ↗','2023 年对比数据原始公告 ↗':'Original 2023 comparison bulletin ↗','生均公共预算教育经费':'General public-budget education expenditure per person','+1.23%':' +1.23%','教育经费总投入':'Total education expenditure','教育经费投入':'Education expenditure','2025 年全国统计':'2025 national statistics','2024 年 · 最新已发布经费数据':'2024 · latest published expenditure data','单位：亿元。国家财政性教育经费为总投入的组成部分，不可与总投入相加。':'Unit: RMB billion. State fiscal education funds are included in total expenditure and must not be added to it.','2024 年全国平均 · 元 / 人':'2024 national average · yuan per person','16,282.98 元 / 人':'16,282.98 yuan / person','15,442.67 元':'15,442.67 yuan','4,250.77 元':'4,250.77 yuan','生均教育事业费支出':'Operating expenditure per person','生均公用经费支出':'Public operating funds per person','全国均值不等于每所学校的实际资源；需结合省份、学段、城乡和学生需求作进一步分析。':'The national average is not the actual resource level of every school. Consider province, education stage, urban/rural context and learner needs.','这些全国汇总数据不能直接证明学生压力的成因、地区资源分配是否公平或某项改革的因果效果。':'These national aggregates do not directly establish the causes of student stress, whether regional allocation is fair, or the causal effects of a reform.','2024年教育经费总投入68899.24亿元，国家财政性教育经费54161.05亿元':'Total education expenditure in 2024 was RMB 6.889924 trillion, including RMB 5.416105 trillion in state fiscal education funds.',
'2025 年全国有各级各类学校 44.07 万所、学历教育在校生 28040.43 万人、专任教师 1870.10 万人。':'In 2025, China had 440,700 schools, 280.4 million enrolled learners and 18.7 million full-time teachers.',
'2024 年全国教育经费总投入 68,899.24 亿元，同比增长 6.66%；国家财政性教育经费占 GDP 的比例为 4.02%。该年度经费公告是本页面采用的最新已发布全国经费口径。':'In 2024, total national education expenditure was RMB 6.889924 trillion, up 6.66% year on year; state fiscal education funds were 4.02% of GDP. This is the latest published national expenditure series used here.',
'这些全国汇总数据不能直接证明学生压力的成因、地区资源分配是否公平或某项改革的因果效果。':'These national aggregates do not directly establish the causes of student stress, whether regional allocation is fair, or the causal effects of a reform.',
'下一步应取得可比的省级/学段数据，预先定义指标，披露缺失值、样本与方法，并避免把相关性写成因果关系。':'Next, obtain comparable province- and education-stage data, define indicators in advance, disclose missing values, samples and methods, and avoid presenting correlation as causation.'
};
function translatePlainNodes(root,dict,en){if(!root)return;const tags='h3,h4,p,span,small,em,b,li,a,th,td,strong';$$(tags,root).forEach(el=>{if(el.children.length||el.hasAttribute('data-en')||el.hasAttribute('data-i'))return;const t=el.textContent.trim();if(!t)return;if(!el.dataset.v24Zh)el.dataset.v24Zh=t;const zh=el.dataset.v24Zh;if(dict[zh])el.textContent=en?dict[zh]:zh;});}
function translateBaseline(){const board=$('.officialEvidenceBoard');if(!board)return;const en=document.documentElement.lang==='en';const map={
'可以直接核验的教育基线':'Verifiable education baseline','以下均为官方发布的全国统计值，用于描述教育系统的投入与规模。':'These nationally published official statistics describe the scale of education spending.','全国教育经费总投入':'Total national education expenditure','国家财政性教育经费':'State fiscal education funds','国家财政性教育经费 / GDP':'State fiscal education funds / GDP','生均一般公共预算教育经费':'General public-budget education expenditure per person','2024 年 · 同比 +6.66%':'2024 · +6.66% year-on-year','2024 年 · 同比 +7.38%':'2024 · +7.38% year-on-year','2024 年 · 全国口径':'2024 · national measure','2024 年 · 同比 +1.23%':'2024 · +1.23% year-on-year','这些数值描述投入规模与变化，不直接代表课堂质量、机会公平或学生身心健康。评估改革时，应与学习成果、群体差异和学生体验等数据交叉分析。':'These figures describe spending scale and change; they do not directly measure classroom quality, equity or learner wellbeing. Reform assessment should also examine learning outcomes, group differences and learner experience.','查看教育部、国家统计局、财政部原始公告 ↗':'Read the original announcement from the Ministry of Education, National Bureau of Statistics and Ministry of Finance ↗'};
 $$('.evidenceBoardHead h3,.evidenceBoardHead p,.evidenceStats article>span,.evidenceStats article>small,.evidenceBottom p,.evidenceBottom a',board).forEach(el=>{if(el.dataset.v24Zh==null)el.dataset.v24Zh=el.textContent.trim();const zh=el.dataset.v24Zh;if(map[zh])el.textContent=en?map[zh]:zh});
 $$('.evidenceStats article strong small',board).forEach((el,i)=>el.textContent=en?(i<2?'RMB billion':i===2?'%':'yuan / person'):(i<2?'亿元':i===2?'%':'元'));
 const fourth=$('.evidenceStats article:nth-child(4) .singleCompare b',board);if(fourth){if(fourth.dataset.v24Zh==null)fourth.dataset.v24Zh=fourth.textContent.trim();fourth.textContent=en?'16,282.98 yuan / person':'16,282.98 元 / 人'}
 const ring=$('.evidenceRing svg',board);if(ring)ring.setAttribute('aria-label',en?'State fiscal education funds as a share of GDP: 4.02%':'国家财政性教育经费占国内生产总值4.02%');
 const compare=$$('.yearCompare[aria-label]',board);compare.forEach(el=>{if(el.dataset.v24Zh==null)el.dataset.v24Zh=el.getAttribute('aria-label');const zh=el.dataset.v24Zh;if(en){el.setAttribute('aria-label',zh.replace('年',' ').replace('亿元',' RMB billion').replace('，','; '))}else el.setAttribute('aria-label',zh)});
}
function translateReportStats(){const en=document.documentElement.lang==='en';const units=en?['k schools','m people','m teachers','RMB trillion']:['万所','亿人','万人','万亿元'];const values=en?['440.7','280.4','18.7','6.8899']:['44.07','2.8040','1870.10','6.8899'];$$('.researchReport .reportStats article strong').forEach((strong,i)=>{if(i>=units.length)return;const small=$('small',strong);if(small)small.textContent=units[i];const text=[...strong.childNodes].find(n=>n.nodeType===Node.TEXT_NODE);if(text){if(!strong.dataset.v26Zh)strong.dataset.v26Zh=text.textContent.trim();text.textContent=values[i]+' ';}})}
function translateResearchReport(){const en=document.documentElement.lang==='en';translatePlainNodes($('.researchReport'),researchCopy,en);const report=$('.researchReport');if(!report)return;const bar=$('.reportGrid .barChart',report);if(bar)bar.setAttribute('aria-label',en?'2024 total education expenditure: RMB 6,889,924 million; state fiscal education funds: RMB 5,416,105 million':'2024年教育经费总投入68899.24亿元，国家财政性教育经费54161.05亿元');
 // Make the main report's metric and source notes explicit in English without losing Chinese source text.
 const heading=$('.researchReport .reportGrid .reportCard:nth-child(1) .reportHead h3');if(heading){heading.dataset.zh='教育经费投入';heading.dataset.en='Education expenditure';heading.textContent=en?heading.dataset.en:heading.dataset.zh}
 const unit=$('.researchReport .reportGrid .reportCard:nth-child(2) .reportHead p');if(unit){unit.dataset.zh='2024 年全国平均 · 元 / 人';unit.dataset.en='2024 national average · yuan per person';unit.textContent=en?unit.dataset.en:unit.dataset.zh}
 const note=$('.researchReport .reportGrid .reportCard:nth-child(2) .bigMetric>span');if(note){note.dataset.zh='全国按在校学生人数平均的一般公共预算教育经费';note.dataset.en='General public-budget education expenditure averaged across enrolled learners nationwide';note.textContent=en?note.dataset.en:note.dataset.zh}
 // The two “per person” figures retain a consistent unit in all chart labels.
 $$('.researchReport .reportGrid .reportCard:nth-child(2) .bigMetric small,.researchReport .reportGrid .reportCard:nth-child(2) .miniFacts span',report).forEach(el=>{if(el.textContent.includes('元 / 人'))el.textContent=en?'yuan / person':'元 / 人';else if(el.textContent.includes('元'))el.textContent=el.textContent.replace('元',en?'yuan':'元')});
}
function translateDashboard(){if(window.__cerpV41ControllerActive)return;const dash=$('#researchDashboard');if(!dash)return;const en=document.documentElement.lang==='en';
 const metrics=$$('.dashboardMetrics article',dash);const labels=en?['Total education spending','State fiscal education funds','Fiscal education funds / GDP','General-budget education spending / public-budget expenditure']:['全国教育经费总投入','国家财政性教育经费','财政性教育经费占GDP','一般公共预算教育经费占比'];
 const values=en?[6.4595,5.0439,4,14.86]:[64595.04,50439.47,4,14.86],decimals=en?[4,4,2,2]:[2,2,2,2],units=en?['RMB trillion','RMB trillion','%','%']:['亿元','亿元','%','%'];
 metrics.forEach((card,i)=>{const label=$('span',card);if(label)label.textContent=labels[i];const strong=$('strong',card);if(strong){let num=$('.v24-number',strong);if(!num){num=document.createElement('span');num.className='v24-number';const small=$('small',strong);const textNode=[...strong.childNodes].find(n=>n.nodeType===Node.TEXT_NODE);const initial=textNode?textNode.textContent.trim():String(values[i]);if(textNode)textNode.remove();num.textContent=initial;strong.insertBefore(num,small||null)}num.dataset.target=String(values[i]);num.dataset.decimal=String(decimals[i]);let small=$('small',strong);if(!small){small=document.createElement('small');strong.append(small)}small.textContent=units[i];small.dataset.zh=i<2?'亿元':'%';small.dataset.en=units[i];}const bar=$('.metricTrack i',card);if(bar){const target=[100,78.1,40,74.3][i]+'%';bar.style.width=target;bar.dataset.v24Target=target;bar.style.transform='scaleX(1)';}});
 const copy={
 'Education spending by level (RMB billion)':'各级教育经费投入（亿元）','Total education spending, 2021–2023 (RMB billion)':'全国教育经费总投入（2021—2023，亿元）','Fiscal education funds as a share of total spending':'财政性教育经费占教育经费总投入','Evidence coverage':'证据维度','Compulsory':'义务教育','Higher ed.':'高等教育','Upper sec.':'高中阶段','Pre-school':'学前教育','Total education spending, 2021–2023 (RMB billion)':'全国教育经费总投入（2021—2023，亿元）'
 };
 const setTitle=(index,zh,enText)=>{const el=$$('.dashChartTop h4',dash)[index];if(el)el.textContent=en?enText:zh};
 setTitle(0,'各级教育经费投入（亿元）','Education expenditure by level (RMB bn)');setTitle(1,'全国教育经费总投入（2021—2023，亿元）','Total education expenditure, 2021–2023 (RMB trillion)');setTitle(2,'财政性教育经费占教育经费总投入','Fiscal education funds as a share of total expenditure');setTitle(3,'证据维度','Evidence dimensions');
 // Translate the bars and chart legend, including small labels that are not data-i nodes.
 const barLabels=$$('.dashBars>div>span',dash);const enBar=['Compulsory','Higher education','Upper secondary','Pre-school'];const zhBar=['义务教育','高等教育','高中阶段','学前教育'];barLabels.forEach((el,i)=>el.textContent=en?enBar[i]:zhBar[i]);
 if(en){const barValues=$$('.dashBars>div>em',dash);['2,842.7','1,764.0','1,015.4','538.2'].forEach((v,i)=>{if(barValues[i])barValues[i].textContent=v});}else{const barValues=$$('.dashBars>div>em',dash);['28427','17640','10154','5382'].forEach((v,i)=>{if(barValues[i])barValues[i].textContent=v});}
 const donutLabels=$$('.donutRow li',dash);if(donutLabels.length>=2){donutLabels[0].childNodes[1].textContent=en?'Fiscal funds ':'财政性经费 ';donutLabels[1].childNodes[1].textContent=en?'Other sources ':'其他来源 ';}
 const donutSmall=$('.dashDonut small',dash);if(donutSmall)donutSmall.textContent=en?'Fiscal funds':'财政性经费';
 const radarNote=$('.radarNote',dash);if(radarNote)radarNote.textContent=en?'These six dimensions organise evidence; they are not subjective scores or rankings.':'六个维度用于组织证据，不代表主观评分或排名。';
 const lineNote=$('.dataChartNote',dash);if(lineNote)lineNote.textContent=en?'Total national education expenditure (RMB trillion): 2021 5.787; 2022 6.133; 2023 6.460. Values follow the cited official bulletin.':'2021：57873.67亿元；2022：61329.14亿元；2023：64595.04亿元。';
 const foot=$('.dashboardFoot',dash);if(foot){const sourceLink=$('a',foot);const href=sourceLink?.href||'https://www.moe.gov.cn/srcsite/A05/s3040/202412/t20241219_1167656.html';foot.innerHTML=en?'Source: <a href="'+href+'" target="_blank" rel="noopener">2023 National Education Expenditure Statistical Bulletin, Ministry of Education, National Bureau of Statistics and Ministry of Finance</a>. Total national education expenditure: RMB 6.460 trillion; state fiscal education funds: RMB 5.044 trillion; 4.00% of GDP; general-budget education spending was 14.86% of general public-budget expenditure. Trend values use the same cited official series.':'来源：<a href="'+href+'" target="_blank" rel="noopener">教育部、国家统计局、财政部《2023年全国教育经费执行情况统计公告》</a>。2023年全国教育经费总投入64595.04亿元；国家财政性教育经费50439.47亿元；占GDP 4.00%；一般公共预算教育经费占一般公共预算支出14.86%。趋势图使用同一公告的可核验年份数据。';}
}
function animateNumber(num,target,dec){if(!num)return;const start=0,duration=1050;num.textContent=(0).toFixed(dec);if(matchMedia('(prefers-reduced-motion: reduce)').matches){num.textContent=target.toFixed(dec);return}let t0;const step=t=>{if(!t0)t0=t;const q=Math.min(1,(t-t0)/duration),e=1-Math.pow(1-q,3);num.textContent=(target*e).toFixed(dec);if(q<1)requestAnimationFrame(step)};requestAnimationFrame(step)}
function bindDashboard(){const dash=$('#researchDashboard');if(!dash||dash.dataset.v24Bound==='1')return;
 // Detach all handlers from earlier repair layers so one click has exactly one animation controller.
 $$('.dashboardMetrics article,.dashChart',dash).forEach(el=>el.replaceWith(el.cloneNode(true)));dash.dataset.v24Bound='1';
 $$('.dashboardMetrics article',dash).forEach(card=>{const play=()=>{const strong=$('strong',card),num=$('.v24-number',strong),bar=$('.metricTrack i',card);if(num)animateNumber(num,Number(num.dataset.target||0),Number(num.dataset.decimal||2));if(bar){const target=bar.dataset.v24Target||bar.style.width||'100%';bar.style.width=target;bar.style.transform='scaleX(1)';bar.animate?.([{transform:'scaleX(0)'},{transform:'scaleX(1)'}],{duration:1150,easing:'cubic-bezier(.2,.7,.2,1)'});}card.classList.remove('v24-metric-playing');void card.offsetWidth;card.classList.add('v24-metric-playing')};card.setAttribute('role','button');card.tabIndex=0;card.addEventListener('click',play);card.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();play()}})});
 $$('.dashChart',dash).forEach(card=>{const play=()=>{const bars=$$('.dashBars i b',card);bars.forEach(b=>{const target=b.style.getPropertyValue('--v')||'100%';b.style.width=target;b.animate?.([{transform:'scaleX(0)'},{transform:'scaleX(1)'}],{duration:1200,easing:'cubic-bezier(.2,.7,.2,1)'});});const line=$('.dashLine',card);if(line){card.classList.remove('v24-line-playing');line.style.setProperty('stroke-dashoffset','0');void line.getBoundingClientRect();card.classList.add('v24-line-playing');line.style.setProperty('stroke-dashoffset','100');requestAnimationFrame(()=>{line.style.setProperty('stroke-dashoffset','0');});}const donut=$('.dashDonut',card);if(donut){donut.classList.remove('v24-donut-playing');void donut.offsetWidth;donut.classList.add('v24-donut-playing');const strong=$('strong',donut);if(strong)strong.animate?.([{opacity:.25,transform:'scale(.9)'},{opacity:1,transform:'scale(1)'}],{duration:700,easing:'ease-out'})}const trace=$('.radarTrace',card);if(trace){trace.style.strokeDashoffset='100';trace.animate?.([{strokeDashoffset:'100'},{strokeDashoffset:'0'}],{duration:1650,easing:'ease-out'});trace.style.strokeDashoffset='0'}$$('.radarPoints circle',card).forEach((point,i)=>{point.animate?.([{transform:'scale(.4)',opacity:.35},{transform:'scale(1)',opacity:1}],{duration:440+i*45,easing:'ease-out'})});};card.addEventListener('click',e=>{if(!e.target.closest('a,button'))play()});card.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();play()}})});
}
function bindReportCharts(){const report=$('.researchReport');if(!report)return;$$('.barChart,.bigMetricRule',report).forEach(chart=>{if(chart.dataset.v24Bound)return;chart.dataset.v24Bound='1';chart.tabIndex=0;chart.setAttribute('role','button');chart.setAttribute('aria-label',document.documentElement.lang==='en'?'Click to animate this chart':'点击播放图表动画');const play=()=>{chart.classList.remove('v24-play');void chart.offsetWidth;chart.classList.add('v24-play')};chart.addEventListener('click',play);chart.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();play()}})});}
function joinEmblem(){const panel=$('.page[data-page="join"] .joinPanel');if(panel&&!$('.joinEmblem',panel)){const img=document.createElement('img');img.className='joinEmblem';img.src='assets/cerp-emblem.png';img.alt='';img.setAttribute('aria-hidden','true');panel.append(img)}}
function translateFormOptions(){const opts=$$('#group option');const zh=['学生','教师','家长与家庭','学校管理者','职业教育与大学生','社会公众'];const en=['Students','Teachers','Parents and families','School administrators','Vocational and university learners','General public'];opts.forEach((o,i)=>{if(i<zh.length){o.dataset.zh=zh[i];o.dataset.en=en[i];o.textContent=document.documentElement.lang==='en'?en[i]:zh[i]}})}
function correctUnits(){const en=document.documentElement.lang==='en';$$('.researchReport .reportGrid .reportCard:nth-child(2) .bigMetric small').forEach(el=>{if(el.textContent.includes('元'))el.textContent=en?'yuan / person':'元 / 人'});$$('.researchReport .reportGrid .reportCard:nth-child(2) .miniFacts div:nth-child(2) b,.researchReport .reportGrid .reportCard:nth-child(2) .miniFacts div:nth-child(3) b').forEach(el=>{if(el.dataset.v24Orig==null)el.dataset.v24Orig=el.textContent;const original=el.dataset.v24Orig;const number=original.replace(/\s*(元|yuan)(\s*\/\s*(人|person))?/,'');el.textContent=en?number+' yuan / person':number+' 元 / 人'});}
function run(){translateFormOptions();joinEmblem();translateResearchReport();translateBaseline();translateReportStats();translateDashboard();bindDashboard();bindReportCharts();correctUnits();const lang=$('#langBtn');if(lang&&!lang.dataset.v24Bound){lang.dataset.v24Bound='1';lang.addEventListener('click',()=>setTimeout(()=>{const currentDash=$('#researchDashboard');if(currentDash)delete currentDash.dataset.v24Bound;translateFormOptions();joinEmblem();translateResearchReport();translateBaseline();translateReportStats();translateDashboard();bindDashboard();bindReportCharts();correctUnits()},380));}/* Removed recursive subtree observer: text updates retriggered it indefinitely. */}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',run,{once:true});else run();
})();


/* ===== Consolidated legacy patch v25 ===== */
/* V25: consolidated QA artifacts, reliable replayable charts, looping dignity SVG, and concise unit localization. */
(()=>{'use strict';
const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
const style=document.createElement('style');style.id='v25-fixes-style';style.textContent=`
/* Second and third principle illustrations: continuously looping, visible SVG linework. */
.heroArtSvg3 .careArch,.heroArtSvg3 .careFloor,.heroArtSvg3 .careLink,.heroArtSvg3 .careStar{fill:none!important;stroke:#9dcfe4!important;stroke-width:2.1!important;stroke-linecap:round!important;stroke-linejoin:round!important}
.heroArtSvg3 .careArch{stroke-dasharray:520;stroke-dashoffset:0;animation:v25CareArch 8s ease-in-out infinite!important}
.heroArtSvg3 .careArch.archInner{animation-delay:-4s!important;stroke:#e4c779!important}
.heroArtSvg3 .careLink{stroke-dasharray:180;stroke-dashoffset:0;animation:v25CareLink 5s ease-in-out infinite!important}
.heroArtSvg3 .careLink.linkRight{animation-delay:-1.6s!important}.heroArtSvg3 .careLink.linkBase{animation-delay:-3.2s!important}
.heroArtSvg3 .careFloor{stroke-dasharray:430;animation:v25CareFloor 7s ease-in-out infinite!important}
.heroArtSvg3 .careHuman{transform-box:fill-box;transform-origin:center;animation:v25CareHuman 5s ease-in-out infinite!important}
.heroArtSvg3 .carePeers{transform-box:fill-box;transform-origin:center;animation:v25CarePeers 5s ease-in-out infinite!important}
.heroArtSvg3 .peerRight{animation-delay:-2.5s!important}.heroArtSvg3 .careStar{stroke:#e9cc7e!important;animation:v25CareStar 4s ease-in-out infinite!important}
@keyframes v25CareArch{0%,100%{stroke-dashoffset:0;opacity:.7}50%{stroke-dashoffset:-180;opacity:1}}
@keyframes v25CareLink{0%,100%{stroke-dashoffset:100;opacity:.5}50%{stroke-dashoffset:0;opacity:1}}
@keyframes v25CareFloor{0%,100%{opacity:.45;stroke-width:1.5}50%{opacity:.9;stroke-width:2.5}}
@keyframes v25CareHuman{0%,100%{transform:translateY(0)}50%{transform:translateY(-3px)}}
@keyframes v25CarePeers{0%,100%{transform:translateY(0);opacity:.78}50%{transform:translateY(-3px);opacity:1}}
@keyframes v25CareStar{0%,100%{opacity:.45;transform:scale(1)}50%{opacity:1;transform:scale(1.08)}}
/* Keep the discussion emblem in the upper-right corner, never bottom-right. */
.page[data-page="join"] .joinPanel .joinEmblem{top:14px!important;right:14px!important;transform:none!important;width:118px!important;height:118px!important;object-fit:contain!important}
@media(max-width:760px){.page[data-page="join"] .joinPanel .joinEmblem{top:10px!important;right:10px!important;width:88px!important;height:88px!important}}
/* Dashboard bars: animate the visual fill using transform, never layout width. */
#researchDashboard .dashboardMetrics .metricTrack{position:relative!important;background:#e8eef2!important;overflow:hidden!important}
#researchDashboard .dashboardMetrics .metricTrack i{display:block!important;height:100%!important;width:100%!important;transform:scaleX(var(--v25-target,1))!important;transform-origin:left center!important;transition:none!important}
#researchDashboard .dashboardMetrics article.v25-metric-playing .metricTrack i{animation:v25MetricFill 1.2s cubic-bezier(.2,.7,.2,1) both!important}
@keyframes v25MetricFill{from{transform:scaleX(0)}to{transform:scaleX(var(--v25-target,1))}}
/* Line is visible on first render; clicking redraws it from left to right. */
#researchDashboard .dashLine{stroke-dasharray:520!important;stroke-dashoffset:0!important;animation:none!important}
#researchDashboard .dashChart.v25-line-playing .dashLine{animation:v25LineDraw 1.8s cubic-bezier(.35,.05,.25,1) both!important}
@keyframes v25LineDraw{from{stroke-dashoffset:520}to{stroke-dashoffset:0}}
/* The 78.1% visualization is a true ring, with a click-to-replay progress sweep. */
#researchDashboard .dashDonut{background:conic-gradient(#1e658d 0 78.1%,#d5b05a 78.1% 100%)!important;isolation:isolate!important;overflow:hidden!important}
#researchDashboard .dashDonut:before{inset:15px!important;border-radius:50%!important;background:#fff!important;z-index:0!important}
@property --v25-ring-stop{syntax:'<percentage>';inherits:false;initial-value:78.1%}
#researchDashboard .dashDonut:after{content:"";position:absolute;inset:0;border-radius:50%;z-index:0;pointer-events:none;background:conic-gradient(from -90deg,#1e658d 0 var(--v25-ring-stop),#d5b05a var(--v25-ring-stop) 100%);mask:radial-gradient(circle,transparent 0 58%,#000 59%);--v25-ring-stop:78.1%}
#researchDashboard .dashDonut.v25-donut-playing:after{animation:v25RingSweep 1.5s cubic-bezier(.2,.7,.2,1) both!important}
@keyframes v25RingSweep{from{--v25-ring-stop:0%;opacity:.7}to{--v25-ring-stop:78.1%;opacity:1}}
#researchDashboard .dashDonut>div{z-index:2!important;position:relative!important}
/* Per-person public-budget expenditure progress bar: click replays the actual fill. */
.researchReport .reportGrid .reportCard:nth-child(2) .bigMetricRule{position:relative;overflow:hidden;cursor:pointer;min-height:5px}
.researchReport .reportGrid .reportCard:nth-child(2) .bigMetricRule i{display:block!important;width:100%!important;transform:scaleX(1);transform-origin:left center;transition:none!important}
.researchReport .reportGrid .reportCard:nth-child(2) .bigMetricRule.v25-play i{animation:v25PerPersonFill 1.25s cubic-bezier(.2,.7,.2,1) both!important}
@keyframes v25PerPersonFill{from{transform:scaleX(0)}to{transform:scaleX(1)}}
@media(prefers-reduced-motion:reduce){.heroArtSvg3 .careArch,.heroArtSvg3 .careFloor,.heroArtSvg3 .careLink,.heroArtSvg3 .careStar,.heroArtSvg3 .careHuman,.heroArtSvg3 .carePeers,#researchDashboard .dashChart.v25-line-playing .dashLine,#researchDashboard .dashDonut.v25-donut-playing:after,#researchDashboard .dashboardMetrics article.v25-metric-playing .metricTrack i,.researchReport .reportGrid .reportCard:nth-child(2) .bigMetricRule.v25-play i{animation:none!important;transform:none!important;stroke-dashoffset:0!important}}
`;
document.head.append(style);
function bindMetrics(){const dash=$('#researchDashboard');if(!dash||dash.dataset.v25Bound==='1')return;dash.dataset.v25Bound='1';
 $$('.dashboardMetrics article,.dashChart',dash).forEach(el=>{const clone=el.cloneNode(true);el.replaceWith(clone)});
 $$('.dashboardMetrics article',dash).forEach((card,i)=>{const bar=$('.metricTrack i',card);if(bar){const targets=[1,.781,.04,.1486];bar.style.setProperty('--v25-target',targets[i]||1);bar.style.transform=`scaleX(${targets[i]||1})`;}const strong=$('strong',card),num=$('.v24-number',strong);const play=()=>{if(num){const target=Number(num.dataset.target||parseFloat(num.textContent.replace(/,/g,''))||0),dec=Number(num.dataset.decimal||2);if(num._v25Frame)cancelAnimationFrame(num._v25Frame);const start=performance.now(),duration=950;const step=now=>{const t=Math.min(1,(now-start)/duration),e=1-Math.pow(1-t,3);num.textContent=(target*e).toLocaleString('en-US',{minimumFractionDigits:dec,maximumFractionDigits:dec});if(t<1)num._v25Frame=requestAnimationFrame(step)};num._v25Frame=requestAnimationFrame(step)}card.classList.remove('v25-metric-playing');void card.offsetWidth;card.classList.add('v25-metric-playing')};card.tabIndex=0;card.setAttribute('role','button');card.addEventListener('click',play);card.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();play()}})});
 $$('.dashChart',dash).forEach(chart=>{const play=()=>{const line=$('.dashLine',chart);if(line){chart.classList.remove('v25-line-playing');line.style.strokeDashoffset='0';void chart.offsetWidth;chart.classList.add('v25-line-playing')};const donut=$('.dashDonut',chart);if(donut){donut.classList.remove('v25-donut-playing');void donut.offsetWidth;donut.classList.add('v25-donut-playing')};$$('.dashBars i b',chart).forEach(b=>{const width=b.style.getPropertyValue('--v')||'100%';b.animate?.([{transform:'scaleX(0)',transformOrigin:'left'},{transform:'scaleX(1)',transformOrigin:'left'}],{duration:1150,easing:'cubic-bezier(.2,.7,.2,1)'})});const radar=$('.radarTrace',chart);if(radar)radar.animate?.([{strokeDashoffset:100},{strokeDashoffset:0}],{duration:1300,easing:'ease-out'})};chart.tabIndex=0;chart.setAttribute('role','button');chart.addEventListener('click',play);chart.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();play()}})});
}
function bindPerPerson(){const el=$('.researchReport .reportGrid .reportCard:nth-child(2) .bigMetricRule');if(!el||el.dataset.v25Bound)return;el.dataset.v25Bound='1';el.tabIndex=0;el.setAttribute('role','button');const play=()=>{el.classList.remove('v25-play');void el.offsetWidth;el.classList.add('v25-play')};el.addEventListener('click',play);el.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();play()}})}
function run(){bindMetrics();bindPerPerson();const lang=$('#langBtn');if(lang&&!lang.dataset.v25Hook){lang.dataset.v25Hook='1';lang.addEventListener('click',()=>{const current=$('#researchDashboard');if(current)delete current.dataset.v25Bound;setTimeout(()=>{const refreshed=$('#researchDashboard');if(refreshed)delete refreshed.dataset.v25Bound;bindMetrics();bindPerPerson()},500)})}/* Removed recursive subtree observer: chart text updates could cause an endless mutation loop. */}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',run,{once:true});else run();
})();


/* ===== Consolidated legacy patch v26 ===== */
/* V26: deterministic chart triggers, accessible whole-card replay, and robust SVG ring. */
(()=>{'use strict';
const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
const style=document.createElement('style');style.id='v26-fixes-style';style.textContent=`
/* Percentage bars use a meaningful scale rather than rendering 4% and 14.86% as tiny slivers. */
#researchDashboard .dashboardMetrics article:nth-child(3) .metricTrack i{--v26-fill:.4!important;transform:scaleX(.4)!important}
#researchDashboard .dashboardMetrics article:nth-child(4) .metricTrack i{--v26-fill:.743!important;transform:scaleX(.743)!important}
#researchDashboard .dashboardMetrics article:nth-child(1) .metricTrack i{transform:scaleX(1)!important}
#researchDashboard .dashboardMetrics article:nth-child(2) .metricTrack i{transform:scaleX(.781)!important}
#researchDashboard .dashboardMetrics .metricTrack{height:5px!important;border-radius:99px!important;background:#e6edf1!important}
#researchDashboard .dashboardMetrics .metricTrack i{height:100%!important;display:block!important;transform-origin:left center!important}
/* Do not animate the trend line on page load. It remains readable, and only replays on deliberate card activation. */
#researchDashboard .dashLine{stroke-dasharray:100!important;stroke-dashoffset:0!important;animation:none!important}
#researchDashboard .dashChart.v26-line-running .dashLine{stroke-dashoffset:0!important}
/* Replace conflicting conic-gradient pseudo-rings with one SVG ring; no layered pseudo-element overlap. */
#researchDashboard .dashDonut{position:relative!important;isolation:isolate!important;overflow:visible!important;background:none!important;clip-path:none!important;transform:none!important;opacity:1!important}
#researchDashboard .dashDonut:before,#researchDashboard .dashDonut:after{content:none!important;display:none!important}
#researchDashboard .dashDonut .v26-ring{position:absolute;inset:0;width:100%;height:100%;overflow:visible;z-index:0;pointer-events:none;transform:rotate(-90deg)}
#researchDashboard .dashDonut .v26-ring .ringTrack{fill:none;stroke:#e6edf1;stroke-width:13}
#researchDashboard .dashDonut .v26-ring .ringValue{fill:none;stroke:#1e658d;stroke-width:13;stroke-linecap:butt;stroke-dasharray:215.86 60.60;stroke-dashoffset:0}
#researchDashboard .dashDonut .v26-ring .ringRemainder{fill:none;stroke:#d5b05a;stroke-width:13;stroke-dasharray:60.60 215.86;stroke-dashoffset:-215.86}
#researchDashboard .dashDonut>div{position:relative!important;z-index:2!important}
#researchDashboard .dashDonut.v26-donut-running .v26-ring .ringValue{stroke-dashoffset:0}
/* Report charts animate from anywhere inside their card, not only when the tiny bar itself is hit. */
.researchReport .reportGrid .reportCard.v26-card-play .bigMetricRule i{animation:v26ReportFill 1.15s cubic-bezier(.2,.7,.2,1) both!important}
.researchReport .reportGrid .reportCard.v26-card-play .barChart .barTrack i{animation:v26ReportFill 1.15s cubic-bezier(.2,.7,.2,1) both!important}
@keyframes v26ReportFill{from{transform:scaleX(0)}to{transform:scaleX(1)}}
#researchDashboard .dashboardMetrics article,#researchDashboard .dashChart,.researchReport .reportGrid .reportCard:nth-child(1),.researchReport .reportGrid .reportCard:nth-child(2){cursor:pointer}
@media(prefers-reduced-motion:reduce){#researchDashboard .dashChart.v26-line-running .dashLine,#researchDashboard .dashDonut .v26-ring .ringValue,.researchReport .reportGrid .reportCard.v26-card-play .bigMetricRule i,.researchReport .reportGrid .reportCard.v26-card-play .barChart .barTrack i{animation:none!important;stroke-dashoffset:0!important;transform:none!important}}
`;
document.head.append(style);
function animatePath(path){if(!path)return;const len=100;path.style.setProperty('stroke-dasharray',String(len),'important');path.style.setProperty('stroke-dashoffset',String(len),'important');path.style.setProperty('transition','none','important');path.getBoundingClientRect();if(matchMedia('(prefers-reduced-motion: reduce)').matches){path.style.setProperty('stroke-dashoffset','0','important');return}path.style.setProperty('transition','stroke-dashoffset 1.45s cubic-bezier(.35,.05,.25,1)','important');requestAnimationFrame(()=>path.style.setProperty('stroke-dashoffset','0','important'));}
function setupDonut(donut){if(!donut||$('.v26-ring',donut))return;const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('class','v26-ring');svg.setAttribute('viewBox','0 0 100 100');svg.setAttribute('aria-hidden','true');svg.innerHTML='<circle class="ringTrack" cx="50" cy="50" r="44"/><circle class="ringRemainder" cx="50" cy="50" r="44"/><circle class="ringValue" cx="50" cy="50" r="44"/>';donut.prepend(svg);const val=$('.ringValue',svg);const c=2*Math.PI*44,portion=c*.781;val.style.strokeDasharray=`${portion} ${c-portion}`;val.style.strokeDashoffset='0';const remainder=$('.ringRemainder',svg);remainder.style.strokeDasharray=`${c-portion} ${portion}`;remainder.style.strokeDashoffset=`-${portion}`;}
function replayDashboardCard(card){if(!card)return;const line=$('.dashLine',card);if(line)animatePath(line);const donut=$('.dashDonut',card);if(donut){setupDonut(donut);const val=$('.ringValue',donut);if(val){const c=2*Math.PI*44,portion=c*.781;val.style.strokeDashoffset=String(portion);val.getBoundingClientRect();if(matchMedia('(prefers-reduced-motion: reduce)').matches)val.style.strokeDashoffset='0';else val.animate([{strokeDashoffset:String(portion)},{strokeDashoffset:'0'}],{duration:1500,easing:'cubic-bezier(.2,.7,.2,1)',fill:'forwards'});}const center=$('.dashDonut>div',donut);if(center&&!matchMedia('(prefers-reduced-motion: reduce)').matches)center.animate([{opacity:.45,transform:'scale(.94)'},{opacity:1,transform:'scale(1)'}],{duration:650,easing:'ease-out'});}
 $$('.dashBars>div i b',card).forEach(b=>{const target=b.style.getPropertyValue('--v')||'100%';b.animate?.([{transform:'scaleX(0)'},{transform:'scaleX(1)'}],{duration:1100,easing:'cubic-bezier(.2,.7,.2,1)'})});const trace=$('.radarTrace',card);if(trace)animatePath(trace);
}
function replayMetric(card){const num=$('.v24-number',card),strong=$('strong',card),bar=$('.metricTrack i',card);if(num){const target=Number(num.dataset.target||parseFloat(num.textContent.replace(/,/g,''))||0),dec=Number(num.dataset.decimal||2);if(num._v26Frame)cancelAnimationFrame(num._v26Frame);const start=performance.now(),duration=900;const step=now=>{const t=Math.min(1,(now-start)/duration),ease=1-Math.pow(1-t,3);num.textContent=(target*ease).toLocaleString('en-US',{minimumFractionDigits:dec,maximumFractionDigits:dec});if(t<1)num._v26Frame=requestAnimationFrame(step)};if(matchMedia('(prefers-reduced-motion: reduce)').matches)num.textContent=target.toLocaleString('en-US',{minimumFractionDigits:dec,maximumFractionDigits:dec});else num._v26Frame=requestAnimationFrame(step)}if(bar){let target=1;if(card.matches(':nth-child(3)'))target=.4;else if(card.matches(':nth-child(4)'))target=.743;else if(card.matches(':nth-child(2)'))target=.781;bar.style.setProperty('transform','scaleX(0)','important');bar.style.setProperty('transition','none','important');bar.getBoundingClientRect();if(matchMedia('(prefers-reduced-motion: reduce)').matches){bar.style.setProperty('transform',`scaleX(${target})`,'important')}else{bar.style.setProperty('transition','transform 1.05s cubic-bezier(.2,.7,.2,1)','important');requestAnimationFrame(()=>bar.style.setProperty('transform',`scaleX(${target})`,'important'));}}card.classList.remove('v26-metric-play');void card.offsetWidth;card.classList.add('v26-metric-play');}
function setup(){const dash=$('#researchDashboard');if(dash){$$('.dashDonut',dash).forEach(setupDonut);$$('.dashboardMetrics article',dash).forEach(card=>{card.tabIndex=0;card.setAttribute('role','button');card.setAttribute('aria-label',(document.documentElement.lang==='en'?'Replay metric animation: ':'重新播放数据动画：')+($('.dashboardMetrics article span',card)?.textContent||''));card.addEventListener('click',e=>{e.stopImmediatePropagation();replayMetric(card)},true);card.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();e.stopImmediatePropagation();replayMetric(card)}},true)});$$('.dashChart',dash).forEach(card=>{card.tabIndex=0;card.addEventListener('click',e=>{if(e.target.closest('a,button'))return;e.stopImmediatePropagation();replayDashboardCard(card)},true);card.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();e.stopImmediatePropagation();replayDashboardCard(card)}},true)});}
 const report=$('.researchReport');if(report){const cards=$$('.reportGrid .reportCard',report);cards.forEach((card,i)=>{if(i>1)return;card.addEventListener('click',e=>{if(e.target.closest('a,button,summary,input,select,textarea'))return;e.stopImmediatePropagation();card.classList.remove('v26-card-play');void card.offsetWidth;card.classList.add('v26-card-play');$$('.barChart,.bigMetricRule',card).forEach(el=>{el.classList.remove('v24-play','v25-play');void el.offsetWidth});},true);card.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){if(e.target!==card)return;e.preventDefault();card.click()}},true);});}
 applyEnglishUnits();const lang=$('#langBtn');if(lang&&!lang.dataset.v26Hook){lang.dataset.v26Hook='1';lang.addEventListener('click',()=>setTimeout(applyEnglishUnits,450));}const obs=new MutationObserver(()=>applyEnglishUnits());obs.observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
}
function applyEnglishUnits(){const en=document.documentElement.lang==='en';const stats=$$('.researchReport .reportStats article');const english=[{n:'440.7',u:'k schools'},{n:'280.4',u:'m people'},{n:'18.7',u:'m teachers'},{n:'6.8899',u:'RMB trillion'}];stats.forEach((article,i)=>{const strong=$('strong',article),small=$('small',strong);if(!strong||!small)return;const text=[...strong.childNodes].find(n=>n.nodeType===Node.TEXT_NODE);if(!strong.dataset.v26Original)strong.dataset.v26Original=text?.textContent.trim()||'';if(en){if(text)text.textContent=english[i].n+' ';small.textContent=english[i].u;}else{if(text)text.textContent=strong.dataset.v26Original+' ';small.textContent=['万所','亿人','万人','万亿元'][i]||small.textContent;}});
 // Correct unit conversions in explanatory English text. 2.8040 亿 = 280.4 million, not 2,804.0 million.
 const result=$$('.researchReport [data-en]');result.forEach(el=>{if(el.dataset.en){el.textContent=el.dataset.en.replace(/280\.4043 million learners/g,'280.4 million learners').replace(/18\.701 million full-time teachers/g,'18.7 million full-time teachers')}});
 const dash=$('#researchDashboard');if(dash&&en){const title=$$('.dashChartTop h4',dash);if(title[0])title[0].textContent='Education expenditure by level (RMB bn)';if(title[1])title[1].textContent='Total education expenditure, 2021–2023 (RMB trillion)';const note=$('.dataChartNote',dash);if(note)note.textContent='Total national education expenditure (RMB trillion): 2021 5.787; 2022 6.133; 2023 6.460. Values follow the cited official bulletin.';const bars=$$('.dashBars>div>em',dash);['2,842.7','1,764.0','1,015.4','538.2'].forEach((v,i)=>{if(bars[i])bars[i].textContent=v});const foot=$('.dashboardFoot',dash);if(foot){const a=$('a',foot);const href=a?.href||'https://www.moe.gov.cn/srcsite/A05/s3040/202412/t20241219_1167656.html';foot.innerHTML='Source: <a href="'+href+'" target="_blank" rel="noopener">2023 National Education Expenditure Statistical Bulletin, Ministry of Education, National Bureau of Statistics and Ministry of Finance</a>. Total national education expenditure: RMB 6.460 trillion; state fiscal education funds: RMB 5.044 trillion; 4.00% of GDP; general-budget education spending was 14.86% of general public-budget expenditure.'}}else if(dash&&!en){const bars=$$('.dashBars>div>em',dash);['28427','17640','10154','5382'].forEach((v,i)=>{if(bars[i])bars[i].textContent=v});}}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',setup,{once:true});else setup();
})();


/* ===== Consolidated legacy patch v27 ===== */
/* V27 — bespoke, continuously looping SVG motion for participation, equity and dignity visuals. */
(()=>{
 'use strict';
 const css = `
 /* Participation: question → verification → change */
 .joinVisual .jpOrbit{stroke:#83b9d6;stroke-width:1.1;stroke-dasharray:2 7;opacity:.45;animation:jpOrbitDrift 18s linear infinite}
 .joinVisual .jpOrbitB{stroke:#e8c56e;stroke-dasharray:1 8;animation-direction:reverse;animation-duration:24s;opacity:.35}
 .joinVisual .jpSpine{stroke:#8dbbd5;stroke-width:1.4;opacity:.35}
 .joinVisual .jpSignal{stroke:url(#jpLine);stroke-width:2.2;stroke-dasharray:12 180;stroke-dashoffset:0;filter:drop-shadow(0 0 4px #9ed4e8);animation:jpSignalFlow 4.8s linear infinite!important}
 .joinVisual .jpSignalB{stroke:#f0d58e;stroke-width:1.4;stroke-dasharray:2 18;animation-duration:6s!important;animation-direction:reverse}
 .joinVisual .jpNode circle{fill:#0d3557;stroke:#e8c56e;stroke-width:1.5;transform-box:fill-box;transform-origin:center}
 .joinVisual .jpNode>circle:first-child{fill:url(#jpGlow);stroke:none;animation:jpHalo 3.8s ease-in-out infinite}
 .joinVisual .jpNodeRing{fill:none!important;stroke:#8fc8e4!important;stroke-dasharray:3 5;animation:jpRing 12s linear infinite}
 .joinVisual .jpEvidence .jpNodeRing{stroke:#f0d58e!important;animation-duration:9s}
 .joinVisual .jpGlyph{stroke:#f4dfa4!important;stroke-width:1.8!important}
 .joinVisual .jpMinor circle{fill:#e8c56e;filter:drop-shadow(0 0 4px #e8c56e);animation:jpMinorPulse 3.6s ease-in-out infinite;transform-box:fill-box;transform-origin:center}
 .joinVisual .jpMinor circle:nth-child(2){animation-delay:-1.2s}.joinVisual .jpMinor circle:nth-child(3){animation-delay:-2.4s}
 .joinVisual .jpLabel{fill:#b7cedd;font-size:8px;letter-spacing:1.4px;font-weight:600}
 .joinVisual .jpTick{stroke:#7396ad;stroke-width:1;opacity:.55}.joinVisual .jpCaption{fill:#91aabd;font-size:6.8px;letter-spacing:1.1px}
 /* Equity: make access a connected, illuminated route rather than a static ramp */
 /* Dignity: open protective architecture, people and visible listening/voice */
 @keyframes jpSignalFlow{to{stroke-dashoffset:-192}}
 @keyframes jpOrbitDrift{to{stroke-dashoffset:-72}}
 @keyframes jpHalo{0%,100%{opacity:.35;transform:scale(.88)}50%{opacity:.8;transform:scale(1.12)}}
 @keyframes jpRing{to{stroke-dashoffset:-96;transform:rotate(360deg)}}
 @keyframes jpMinorPulse{0%,100%{opacity:.4;transform:scale(.8)}50%{opacity:1;transform:scale(1.5)}}
 
 
 
 
 
 
 
 
 
 
 
 
 `;
 const style=document.createElement('style');style.id='v27-svg-design-motion';style.textContent=css;document.head.appendChild(style);
 // Ensure the discussion visual animates continuously, not only on hover/focus.
 const joinVisual=document.querySelector('.joinVisual'); if(joinVisual) joinVisual.classList.add('is-active');
})();


/* ===== Consolidated legacy patch v28 ===== */
/* V28 — stabilize first paint, repair research translations/charts, and ensure principle visuals loop. */
(()=>{'use strict';
const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>Array.from(r.querySelectorAll(s));
const style=document.createElement('style');style.id='v28-regression-fixes';style.textContent=`
/* Prevent refresh flash caused by hidden reveal states and page entrance transforms. */
.reveal{opacity:1!important;transform:none!important;will-change:auto!important}
.page.active{animation:none!important}
/* The two principle SVGs should run continuously, including on touch devices without hover. */
.focusCard[data-focus="equity"],.focusCard[data-focus="dignity"]{--v28-motion:running}
.focusCard[data-focus="equity"].is-active .kineticSvg *, .focusCard[data-focus="dignity"].is-active .kineticSvg *,
.focusCard[data-focus="equity"] .kineticSvg *, .focusCard[data-focus="dignity"] .kineticSvg *{animation-play-state:running!important}
@keyframes v28Orbit{to{stroke-dashoffset:-240;transform:rotate(360deg)}}
@keyframes v28Flow{to{stroke-dashoffset:-90}}

@keyframes v28Float{0%,100%{transform:translateY(0)}50%{transform:translateY(-2px)}}
/* Ring chart: clean SVG ring, no overlapping pie pseudo-elements. */
#researchDashboard .dashDonut{position:relative!important;isolation:isolate;background:transparent!important;border-radius:50%;overflow:visible!important}
#researchDashboard .dashDonut:before,#researchDashboard .dashDonut:after{content:none!important;display:none!important}
#researchDashboard .dashDonut .v26-ring{position:absolute!important;inset:0!important;width:100%!important;height:100%!important;transform:rotate(-90deg);z-index:1;overflow:visible}
#researchDashboard .dashDonut .v26-ring .ringTrack{fill:none;stroke:#e7edf2;stroke-width:12}
#researchDashboard .dashDonut .v26-ring .ringRemainder{fill:none;stroke:#d8b35b;stroke-width:12;stroke-linecap:round}
#researchDashboard .dashDonut .v26-ring .ringValue{fill:none;stroke:#23688d;stroke-width:12;stroke-linecap:round;stroke-dashoffset:0}
#researchDashboard .dashDonut>div{position:absolute!important;inset:0!important;display:flex!important;flex-direction:column!important;align-items:center!important;justify-content:center!important;text-align:center!important;z-index:2!important;border-radius:50%;background:#fff!important;transform:none}
#researchDashboard .dashDonut>div strong{font-size:clamp(20px,2.2vw,29px)!important;line-height:1.1!important;white-space:nowrap}
#researchDashboard .dashDonut>div small{display:block!important;margin-top:8px!important;font-size:11px!important}
#researchDashboard .dashChart .dashLine{stroke-dasharray:100!important;stroke-dashoffset:0!important;animation:none!important}
#researchDashboard .dashChart .dashLineNodes{opacity:1}
#researchDashboard .dashChart.v28-line-run .dashLine{stroke-dashoffset:100!important;animation:v28LineDraw 1.5s cubic-bezier(.2,.7,.2,1) forwards!important}
@keyframes v28LineDraw{to{stroke-dashoffset:0}}
#researchDashboard .dashChart .v28-year-label{font-size:9px;fill:#718195}
@media(prefers-reduced-motion:reduce){.focusCard[data-focus="equity"] .kineticSvg *, .focusCard[data-focus="dignity"] .kineticSvg *,#researchDashboard .dashChart .dashLine{animation:none!important;transition:none!important;stroke-dashoffset:0!important}}
`;document.head.append(style);

// Fix the research dashboard language on initial load and every language toggle.
function translateResearch(){
 const en=document.documentElement.lang.toLowerCase().startsWith('en');
 const report=$('.researchReport'); if(!report)return;
 const head=$('.sectionHead',report);
 if(head){const k=$('.kicker',head),h=$('h2',head),p=$('p',head);if(k)k.textContent=en?'CHINA EDUCATION / DATA BRIEF':'中国教育：规模、投入与公平的证据起点';if(h)h.textContent=en?'China education: turn official statistics into testable questions':'中国教育：把官方统计转化为可检验的问题';if(p)p.textContent=en?'Use official statistics as a baseline, not as a proxy for educational quality. Read definitions, years and coverage alongside the original bulletin.':'用官方统计建立研究基线，而不把宏观指标直接等同于教育质量。阅读时应同时核对原始公报中的定义、年份和覆盖范围。';}
 const labels=$$('.reportStats article',report), pairs=[['Schools of all types','各级各类学校'],['Enrolled learners','学历教育在校生'],['Full-time teachers','专任教师'],['Total education expenditure','教育经费总投入']];
 labels.forEach((a,i)=>{const s=$('span',a),em=$('em',a);if(s)s.textContent=en?pairs[i][0]:pairs[i][1];if(em)em.textContent=en?(i===3?'2024 · latest published expenditure data':'2025 national statistics'):(i===3?'2024 年 · 最新已发布经费数据':'2025 年全国统计');});
 const cards=$$('.reportGrid .reportCard',report);
 if(cards[0]){const c=cards[0],v=en?['Education expenditure','Total national education expenditure in 2024 (RMB billion)','Total expenditure','State fiscal funds','Unit: RMB billion. State fiscal education funds are part of total expenditure and must not be added to it.']:['教育经费投入','2024 年全国教育经费总投入（亿元）','经费总投入','国家财政性','单位：亿元。国家财政性教育经费为总投入的组成部分，不可与总投入相加。'];const h=$('h3',c),p=$('.reportHead p',c),rows=$$('.barRow span',c),n=$('.chartNote',c);if(h)h.textContent=v[0];if(p)p.textContent=v[1];rows.forEach((x,i)=>{if(v[i+2])x.textContent=v[i+2]});if(n)n.textContent=v[4];}
 if(cards[1]){const c=cards[1],v=en?{h:'Public-budget education expenditure per student',p:'2024 national average · RMB / person',label:'General public-budget education expenditure averaged across enrolled learners',growth:'Year-on-year change',facts:'Expenditure per student',public:'Public operating expenditure per student',note:'A national average is not the actual resource level at every school; compare provinces, education stages, urban/rural settings and student needs.'}:{h:'生均公共预算教育经费',p:'2024 年全国平均 · 元 / 人',label:'全国按在校学生人数平均的一般公共预算教育经费',growth:'同比增长',facts:'生均教育事业费支出',public:'生均公用经费支出',note:'全国均值不等于每所学校的实际资源；需结合省份、学段、城乡和学生需求作进一步分析。'};const h=$('h3',c),p=$('.reportHead p',c),big=$('.bigMetric>span',c),facts=$$('.miniFacts>div span',c),n=$('.chartNote',c);if(h)h.textContent=v.h;if(p)p.textContent=v.p;if(big)big.textContent=v.label;if(facts[0])facts[0].textContent=v.growth;if(facts[1])facts[1].textContent=v.facts;if(facts[2])facts[2].textContent=v.public;if(n)n.textContent=v.note;}
 if(cards[2]){const c=cards[2],v=en?{h:'Educational opportunity and equity: questions to pursue',p:'Official statistics provide an overall baseline, but cannot explain disparities on their own.',rows:[['Regional differences','Compare per-student spending, teacher allocation, school access and household burden across provinces.'],['Urban–rural differences','Distinguish school resources, commute distance, digital access and course choice.'],['Learner experience','Use anonymous, representative surveys to examine sleep, stress, belonging and engagement.'],['Outcome measures','Track learning progress, wellbeing, equal opportunity and long-term development; do not reduce outcomes to one exam metric.']]}:{h:'教育机会与公平：应继续追问什么',p:'官方统计提供总体基线，但不足以单独解释差异。',rows:[['地区差异','对比省际生均投入、教师配置、学校可及性与家庭负担。'],['城乡差异','区分学校资源、通勤距离、数字设备与课程可选范围。'],['学生体验','用匿名、具代表性的调查检验睡眠、压力、归属感与学习投入。'],['结果指标','同时观察学习进步、身心健康、机会公平与长期发展，不以单一考试指标代替全部结果。']]};const h=$('h3',c),p=$('.reportHead p',c),rows=$$('.questionRows>div',c);if(h)h.textContent=v.h;if(p)p.textContent=v.p;rows.forEach((row,i)=>{const b=$('b',row),sp=$('span',row);if(b)b.textContent=v.rows[i][0];if(sp)sp.textContent=v.rows[i][1]});}
 if(cards[3]){const c=cards[3],v=en?{h:'Research findings and data boundaries',p:'Separate verifiable facts from hypotheses requiring further study.',list:['In 2025, China had 440,700 schools, 280.4 million learners in formal education and 18.7 million full-time teachers.','In 2024, total education expenditure was RMB 6.889924 trillion, up 6.66% year on year; state fiscal education funds equalled 4.02% of GDP.','National aggregates cannot directly establish the causes of student stress, regional equity or the causal effects of a reform.','Next, obtain comparable provincial and education-stage data, predefine indicators, disclose missingness and methods, and do not treat correlation as causation.']}:{h:'研究结论与数据边界',p:'可验证的事实与待研究假设分开呈现。',list:['2025 年全国有各级各类学校 44.07 万所、学历教育在校生 28040.43 万人、专任教师 1870.10 万人。','2024 年全国教育经费总投入 68,899.24 亿元，同比增长 6.66%；国家财政性教育经费占 GDP 的比例为 4.02%。该年度经费公告是本页面采用的最新已发布全国经费口径。','这些全国汇总数据不能直接证明学生压力的成因、地区资源分配是否公平或某项改革的因果效果。','下一步应取得可比的省级/学段数据，预先定义指标，披露缺失值、样本与方法，并避免把相关性写成因果关系。']};const h=$('h3',c),p=$('.reportHead p',c),lis=$$('.reportList li',c);if(h)h.textContent=v.h;if(p)p.textContent=v.p;lis.forEach((li,i)=>{if(v.list[i])li.textContent=v.list[i]});const a=$('a[data-en][data-zh]',c);if(a)a.textContent=en?'Source: Ministry of Education, 2025 National Education Development Statistical Bulletin ↗':'来源：教育部《2025年全国教育事业发展统计公报》 ↗';}
}
// Research dashboard is dynamically generated and can be rebuilt by the existing language handler.
const dashboard=$('#researchDashboard');
if(dashboard){const chart=$$('.dashChart',dashboard)[1];if(chart){const svg=$('.dashLineSvg',chart);if(svg){svg.setAttribute('viewBox','0 0 520 190');svg.innerHTML=`<path class="dashGridLine" d="M34 28H500M34 68H500M34 108H500M34 148H500"/><path class="dashLine" pathLength="100" d="M42 145 L87 137 L132 128 L177 117 L222 104 L267 91 L312 78 L357 66 L402 48 L447 36 L492 24"/><g class="dashLineNodes">${[[42,145],[87,137],[132,128],[177,117],[222,104],[267,91],[312,78],[357,66],[402,48],[447,36],[492,24]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="3.5"/>`).join('')}</g><g class="v28-year-labels">${[2013,2014,2015,2016,2017,2018,2019,2020,2021,2022,2023].map((y,i)=>`<text class="v28-year-label" x="${42+i*45}" y="174" text-anchor="middle">${y}</text>`).join('')}</g>`;}}}
if(dashboard){const en=document.documentElement.lang.toLowerCase().startsWith('en');const title=$('.dashboardHead h3',dashboard),desc=$('.dashboardHead p',dashboard);if(title)title.textContent=en?'China education: scale, investment and equity':'中国教育：规模、投入与公平的证据起点';if(desc)desc.textContent=en?'Official statistics provide a starting point for asking testable questions about scale, investment and equity.':'以官方统计为起点，提出有关教育规模、投入与公平的可检验问题。';const charts=$$('.dashChart',dashboard);if(charts[1]){const h=$('h4',charts[1]);if(h)h.textContent=en?'Total education expenditure (2013–2023, RMB billion)':'全国教育经费总投入（2013—2023，亿元）';}}
function patchDashboard(){const d=$('#researchDashboard');if(!d)return;const en=document.documentElement.lang.toLowerCase().startsWith('en');const title=$('.dashboardHead h3',d),desc=$('.dashboardHead p',d);if(title)title.textContent=en?'China education: scale, investment and equity':'中国教育：规模、投入与公平的证据起点';if(desc)desc.textContent=en?'Official statistics provide a starting point for asking testable questions about scale, investment and equity.':'以官方统计为起点，提出有关教育规模、投入与公平的可检验问题。';const cards=$$('.dashChart',d);if(cards[1]){const h=$('h4',cards[1]);if(h)h.textContent=en?'Total education expenditure (2013–2023, RMB billion)':'全国教育经费总投入（2013—2023，亿元）';const svg=$('.dashLineSvg',cards[1]);if(svg&&!svg.dataset.v28Years){svg.dataset.v28Years='1';svg.setAttribute('viewBox','0 0 520 190');svg.innerHTML=`<path class="dashGridLine" d="M34 28H500M34 68H500M34 108H500M34 148H500"/><path class="dashLine" pathLength="100" d="M42 145 L87 137 L132 128 L177 117 L222 104 L267 91 L312 78 L357 66 L402 48 L447 36 L492 24"/><g class="dashLineNodes">${[[42,145],[87,137],[132,128],[177,117],[222,104],[267,91],[312,78],[357,66],[402,48],[447,36],[492,24]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="3.5"/>`).join('')}</g><g class="v28-year-labels">${[2013,2014,2015,2016,2017,2018,2019,2020,2021,2022,2023].map((y,i)=>`<text class="v28-year-label" x="${42+i*45}" y="174" text-anchor="middle">${y}</text>`).join('')}</g>`;}}
 cards.forEach(card=>{if(card.dataset.v28Click)return;card.dataset.v28Click='1';card.addEventListener('click',e=>{if(e.target.closest('a,button'))return;const line=$('.dashLine',card);if(line){card.classList.remove('v28-line-run');void card.offsetWidth;card.classList.add('v28-line-run');}const donut=$('.dashDonut',card);if(donut){const val=$('.ringValue',donut);if(val){const c=2*Math.PI*44,portion=c*.781;val.style.strokeDashoffset=String(portion);val.getBoundingClientRect();if(!matchMedia('(prefers-reduced-motion: reduce)').matches)val.animate([{strokeDashoffset:String(portion)},{strokeDashoffset:'0'}],{duration:1500,easing:'cubic-bezier(.2,.7,.2,1)',fill:'forwards'});else val.style.strokeDashoffset='0';}}});});}
patchDashboard();/* Do not observe researchPage subtree: patchDashboard changes text nodes and would retrigger itself forever. Initial patch and explicit language-change handler are sufficient. */
translateResearch();const btn=$('#langBtn');if(btn&&!btn.dataset.v28Language){btn.dataset.v28Language='1';btn.addEventListener('click',()=>setTimeout(()=>{translateResearch();patchDashboard()},500));}
// Replay chart animation on click anywhere in the chart card; line is static until explicitly triggered.
const dash=$('#researchDashboard');if(dash){$$('.dashChart',dash).forEach(card=>{if(card.dataset.v28Click)return;card.dataset.v28Click='1';card.addEventListener('click',e=>{if(e.target.closest('a,button'))return;const line=$('.dashLine',card);if(line){card.classList.remove('v28-line-run');void card.offsetWidth;card.classList.add('v28-line-run');}const donut=$('.dashDonut',card);if(donut){const val=$('.ringValue',donut);if(val){const c=2*Math.PI*44,portion=c*.781;val.style.strokeDashoffset=String(portion);val.getBoundingClientRect();if(!matchMedia('(prefers-reduced-motion: reduce)').matches)val.animate([{strokeDashoffset:String(portion)},{strokeDashoffset:'0'}],{duration:1500,easing:'cubic-bezier(.2,.7,.2,1)',fill:'forwards'});else val.style.strokeDashoffset='0';}const strong=$('.dashDonut strong',donut);if(strong&&!matchMedia('(prefers-reduced-motion: reduce)').matches){strong.animate([{opacity:.2,transform:'scale(.9)'},{opacity:1,transform:'scale(1)'}],{duration:700});}}});});}
})();


/* ===== Consolidated legacy patch v29 ===== */
/* V29: readable numeric y-axis, stable click-to-play donut, complete bilingual research dashboard. */
(()=>{'use strict';
const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>Array.from(r.querySelectorAll(s));
const vals=[30364.72,32806.46,36129.19,38888.39,42562.01,46135,50178.12,53014,57873.67,61329.14,64595.04];
const years=Array.from({length:11},(_,i)=>2013+i);
const css=document.createElement('style');css.textContent=`
#researchDashboard .dashChart .v29-y-label{font-size:10px!important;fill:#657b8e!important;font-variant-numeric:tabular-nums}
#researchDashboard .dashChart .v29-y-title{font-size:9px!important;fill:#71879a!important}
#researchDashboard .dashChart .dashLineSvg{overflow:visible!important}
#researchDashboard .dashDonut{background:conic-gradient(#1e658d 0deg 281.16deg,#d5b05a 281.16deg 360deg)!important;display:grid!important;place-items:center!important;overflow:visible!important;transform-origin:center}
#researchDashboard .dashDonut .v26-ring{display:none!important}
#researchDashboard .dashDonut:before{content:''!important;display:block!important;position:absolute!important;inset:14%!important;border-radius:50%!important;background:#fff!important;z-index:1!important}
#researchDashboard .dashDonut:after{content:''!important;display:block!important;position:absolute!important;inset:0!important;border-radius:50%!important;background:transparent!important;z-index:0!important}
#researchDashboard .dashDonut>div{position:relative!important;inset:auto!important;width:70%!important;height:70%!important;display:flex!important;flex-direction:column!important;align-items:center!important;justify-content:center!important;text-align:center!important;z-index:2!important;border-radius:50%!important;background:transparent!important;transform:none!important}
#researchDashboard .dashDonut.v29-donut-playing{animation:v29DonutSpin 1.15s cubic-bezier(.2,.7,.2,1) both!important}
#researchDashboard .dashDonut.v29-donut-playing>div{animation:v29DonutCounter 1.15s cubic-bezier(.2,.7,.2,1) both!important}
@keyframes v29DonutSpin{from{transform:rotate(-24deg)}to{transform:rotate(0deg)}}
@keyframes v29DonutCounter{from{transform:rotate(24deg)}to{transform:rotate(0deg)}}
@media(prefers-reduced-motion:reduce){#researchDashboard .dashDonut.v29-donut-playing,#researchDashboard .dashDonut.v29-donut-playing>div{animation:none!important}}
`;document.head.append(css);
function drawLine(chart,en){const svg=$('.dashLineSvg',chart);if(!svg)return;const min=28000,max=67000,left=68,right=535,top=22,bottom=155;const pts=vals.map((v,i)=>[left+i*(right-left)/10,bottom-(v-min)/(max-min)*(bottom-top)]);const path=pts.map((p,i)=>(i?'L':'M')+p[0].toFixed(1)+' '+p[1].toFixed(1)).join(' ');const ticks=[30000,40000,50000,60000,70000];svg.setAttribute('viewBox','0 0 550 190');svg.innerHTML=`<g class="v29-y-axis">${ticks.map(v=>{const y=bottom-(v-min)/(max-min)*(bottom-top);return `<path class="dashGridLine" d="M${left} ${y.toFixed(1)}H${right}"/><text class="v29-y-label" x="${left-8}" y="${(y+3.5).toFixed(1)}" text-anchor="end">${v.toLocaleString('en-US')}</text>`}).join('')}<text class="v29-y-title" x="7" y="10">${en?'RMB':'亿元'}</text>${en?'<text class="v29-y-title" x="7" y="21">billion</text>':''}</g><path class="dashLine" pathLength="100" d="${path}"/><g class="dashLineNodes">${pts.map(([x,y])=>`<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="3.1"/>`).join('')}</g><g class="v28-year-labels">${years.map((y,i)=>i%2===0||i===10?`<text class="v28-year-label" x="${pts[i][0].toFixed(1)}" y="177" text-anchor="middle">${y}</text>`:'').join('')}</g>`;}
function setText(el,text){if(el&&el.textContent!==text)el.textContent=text}
function translate(){const d=$('#researchDashboard');if(!d)return;const en=document.documentElement.lang.toLowerCase().startsWith('en');
setText($('.dashboardHead .kicker',d),en?'OFFICIAL STATISTICS / DATA LITERACY':'官方统计 / 数据素养');
setText($('.dashboardHead h3',d),en?'China education: turn official statistics into testable questions':'中国教育：规模、投入与公平的证据起点');
setText($('.dashboardHead p',d),en?'Use official statistics as a starting point for testable questions about educational scale, investment and equity. Figures retain the source definitions and units.':'以官方统计为起点，提出有关教育规模、经费投入与机会公平的可检验问题。数据保留原始统计口径与单位。点击图表可播放动画。');
const metrics=$$('.dashboardMetrics article',d);const m=en?['Total education expenditure','State fiscal education funds','Fiscal education funds / GDP','General-budget education / public-budget expenditure']:['全国教育经费总投入','国家财政性教育经费','财政性教育经费占 GDP','一般公共预算教育经费占比'];metrics.forEach((c,i)=>{setText($('span',c),m[i]||'');const unit=$('strong small',c);if(unit&&i<2)setText(unit,en?'RMB billion':'亿元');});
const cards=$$('.dashChart',d);const titles=en?['Education expenditure by level (RMB billion)','Total education expenditure (2013–2023, RMB billion)','Fiscal education funds as a share of total expenditure','Evidence dimensions']:['各级教育经费投入（亿元）','全国教育经费总投入（2013—2023，亿元）','财政性教育经费占教育经费总投入','证据维度'];const caps=en?['01 / BAR CHART','02 / TREND','03 / SHARE','04 / MULTI-METRIC']:['01 / 柱状图','02 / 趋势','03 / 构成','04 / 多维指标'];cards.forEach((c,i)=>{setText($('.dashChartTop h4',c),titles[i]||'');setText($('.dashChartTop span',c),caps[i]||'')});
const bars=$$('.dashBars>div',d);const barNames=en?['Compulsory education','Higher education','Upper secondary','Pre-primary']:['义务教育','高等教育','高中阶段','学前教育'];bars.forEach((b,i)=>setText($('span',b),barNames[i]||''));
const donut=$('.dashDonut',d);if(donut){const center=$('div',donut);if(center){setText($('small',center),en?'Fiscal funds':'财政性经费')}const li=$$('.donutRow li',d);if(li.length>1){li[0].innerHTML='<i></i>'+(en?'Fiscal funds':'财政性经费')+' <b>78.1%</b>';li[1].innerHTML='<i></i>'+(en?'Other sources':'其他来源')+' <b>21.9%</b>';}}
const radar=$('.dashRadar',d);if(radar){const labels=en?['SCALE','FUNDING','GROWTH','SCOPE','SOURCE','ACCESS']:['规模','投入','增长','口径','来源','可及'];$$('text',radar).forEach((el,i)=>{if(labels[i])setText(el,labels[i])});}
const note=$('.dataChartNote',d);if(note)setText(note,en?'Total education expenditure (RMB billion): '+years.map((y,i)=>`${y} ${(vals[i]/10).toLocaleString('en-US',{minimumFractionDigits:1,maximumFractionDigits:1})}`).join('; ')+'. Source: official national education expenditure bulletins.':'全国教育经费总投入（亿元）：'+years.map((y,i)=>`${y} ${vals[i].toLocaleString('zh-CN',{maximumFractionDigits:2})}`).join('；')+'。来源：全国教育经费执行情况统计公告。');
const radarNote=$('.radarNote',d);setText(radarNote,en?'Six dimensions organise evidence; they are not subjective scores or rankings.':'六个维度用于组织证据，不代表主观评分或排名。');
const foot=$('.dashboardFoot',d);if(foot){const a=$('a',foot);if(en){foot.innerHTML='Source: <a href="https://www.moe.gov.cn/srcsite/A05/s3040/202412/t20241219_1167656.html" target="_blank" rel="noopener">2023 National Education Expenditure Statistical Bulletin</a>, Ministry of Education, National Bureau of Statistics and Ministry of Finance. Total expenditure: RMB 6.459504 trillion; state fiscal education funds: RMB 5.043947 trillion; 4.00% of GDP; general-budget education spending: 14.86% of general public-budget expenditure.';}else{foot.innerHTML='来源：<a href="https://www.moe.gov.cn/srcsite/A05/s3040/202412/t20241219_1167656.html" target="_blank" rel="noopener">教育部、国家统计局、财政部《2023年全国教育经费执行情况统计公告》</a>。2023年全国教育经费总投入64595.04亿元；国家财政性教育经费50439.47亿元；占GDP 4.00%；一般公共预算教育经费占一般公共预算支出14.86%。';}}
if(cards[1])drawLine(cards[1],en);
}
function bind(){}
function run(){translate();bind()}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',run,{once:true});else run();
const lang=$('#langBtn');if(lang&&!lang.dataset.v29Hook){lang.dataset.v29Hook='1';lang.addEventListener('click',()=>{[20,100,350,700].forEach(ms=>setTimeout(run,ms))});}
// enhancements.js rebuilds the dashboard on language changes; retry briefly without observing DOM mutations.
[80,300,900].forEach(ms=>setTimeout(run,ms));
})();


/* ===== Consolidated legacy patch v30 ===== */
/* V30: stable first paint, refined bespoke SVGs, v16-style scroll-triggered chart animation, robust Chinese-first translations. */
(()=>{'use strict';
const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>Array.from(r.querySelectorAll(s));
const css=document.createElement('style');css.id='v30-stability-design';css.textContent=`
/* Avoid a refresh flash caused by re-animating the active page on every load. */
.page.active{animation:none!important}
/* Cards have no preselected/highlighted state on initial load. */
.focusCard.is-active{border-color:transparent;box-shadow:none}
.focusCard:hover,.focusCard:focus-visible,.focusCard:focus-within{border-color:#e8c56e88;box-shadow:0 18px 42px #0003}
.focusCard.is-active:hover,.focusCard.is-active:focus-visible{border-color:#e8c56e;box-shadow:0 20px 48px #0004}
#researchDashboard .dashChart.v30-enter-run .dashBars i b{animation:cerpBarIn 1.25s cubic-bezier(.2,.7,.2,1) both!important}
#researchDashboard .dashChart.v30-enter-run .dashLine{stroke-dasharray:100!important;stroke-dashoffset:100;animation:v30LineDraw 1.8s cubic-bezier(.2,.7,.2,1) forwards!important}
#researchDashboard .dashChart.v30-enter-run .radarTrace{stroke-dasharray:100!important;stroke-dashoffset:100;animation:v30LineDraw 1.8s cubic-bezier(.2,.7,.2,1) forwards!important}
#researchDashboard .dashChart.v30-enter-run .radarArea{animation:v30RadarFill 1.4s ease-out both}
#researchDashboard .dashDonut{background:conic-gradient(#1e658d 0deg 281.16deg,#d5b05a 281.16deg 360deg)!important;transform:none!important}
#researchDashboard .dashDonut.v30-pie-drawing{animation:none!important;transform:none!important}
#researchDashboard .dashDonut.v30-pie-drawing>div{animation:v30PieCenter 1.3s ease-out both!important}
@keyframes v30LineDraw{to{stroke-dashoffset:0}}
@keyframes v30RadarFill{from{opacity:.05}to{opacity:1}}
@keyframes v30PieCenter{0%{opacity:.45;transform:scale(.92)}100%{opacity:1;transform:scale(1)}}







`;document.head.append(css);
function redesignJoin(){}
function translateDashboard(){if(window.__cerpV41ControllerActive)return;const d=$('#researchDashboard');if(!d)return;const en=(document.documentElement.lang||'zh-CN').toLowerCase().startsWith('en');const set=(s,zh,enText)=>{const e=$(s,d);if(e)e.textContent=en?enText:zh};set('.dashboardHead .kicker','官方统计 / 数据素养','OFFICIAL STATISTICS / DATA LITERACY');set('.dashboardHead h3','中国教育：规模、投入与公平的证据起点','China education: turn official statistics into testable questions');set('.dashboardHead p','以官方统计为起点，提出有关教育规模、经费投入与机会公平的可检验问题。数据保留原始统计口径与单位。','Use official statistics as a starting point for testable questions about educational scale, investment and equity. Figures retain source definitions and units.');const metrics=$$('.dashboardMetrics article',d),mzh=['全国教育经费总投入','国家财政性教育经费','财政性教育经费占 GDP','一般公共预算教育经费占比'],men=['Total education expenditure','State fiscal education funds','Fiscal education funds / GDP','General-budget education / public-budget expenditure'];metrics.forEach((c,i)=>{const s=$('span',c),sm=$('strong small',c);if(s)s.textContent=(en?men:mzh)[i];if(sm&&i<2)sm.textContent=en?'RMB billion':'亿元'});const charts=$$('.dashChart',d),tzh=['各级教育经费投入（亿元）','全国教育经费总投入（2013—2023，亿元）','财政性教育经费占教育经费总投入','证据维度'],ten=['Education expenditure by level (RMB billion)','Total education expenditure (2013–2023, RMB billion)','Fiscal education funds as a share of total expenditure','Evidence dimensions'],czh=['01 / 柱状图','02 / 趋势','03 / 构成','04 / 多维指标'],cen=['01 / BAR CHART','02 / TREND','03 / SHARE','04 / MULTI-METRIC'];charts.forEach((c,i)=>{const h=$('.dashChartTop h4',c),cap=$('.dashChartTop span',c);if(h)h.textContent=(en?ten:tzh)[i];if(cap)cap.textContent=(en?cen:czh)[i]});const barNames=en?['Compulsory education','Higher education','Upper secondary','Pre-primary']:['义务教育','高等教育','高中阶段','学前教育'];$$('.dashBars>div',d).forEach((b,i)=>{const s=$('span',b);if(s)s.textContent=barNames[i]});const donut=$('.dashDonut',d);if(donut){const sm=$('small',donut);if(sm)sm.textContent=en?'Fiscal funds':'财政性经费';const ul=$$('.donutRow li',d);if(ul[0])ul[0].innerHTML='<i></i>'+(en?'Fiscal funds':'财政性经费')+' <b>78.1%</b>';if(ul[1])ul[1].innerHTML='<i></i>'+(en?'Other sources':'其他来源')+' <b>21.9%</b>';donut.setAttribute('aria-label',en?'Fiscal education funds are 78.1% of total expenditure':'财政性教育经费占总投入约78.1%')}const radar=$('.dashRadar',d);if(radar){const labels=en?['SCALE','FUNDING','GROWTH','SCOPE','SOURCE','ACCESS']:['规模','投入','增长','口径','来源','可及'];$$('text',radar).forEach((e,i)=>{if(labels[i])e.textContent=labels[i]});radar.setAttribute('aria-label',en?'Six dimensions of evidence coverage':'数据规模、投入、增长、分配、口径、可追溯性六维结构图')}const note=$('.dataChartNote',d);if(note)note.textContent=en?'National education expenditure, RMB billion: '+[30364.72,32806.46,36129.19,38888.39,42562.01,46135,50178.12,53014,57873.67,61329.14,64595.04].map((v,i)=>(2013+i)+' '+v.toLocaleString('en-US')).join('; ')+'. Source: official national education expenditure bulletins.':'全国教育经费总投入（亿元）：'+[30364.72,32806.46,36129.19,38888.39,42562.01,46135,50178.12,53014,57873.67,61329.14,64595.04].map((v,i)=>(2013+i)+' '+v.toLocaleString('zh-CN')).join('；')+'。来源：全国教育经费执行情况统计公告。';const rn=$('.radarNote',d);if(rn)rn.textContent=en?'Six dimensions organise evidence; they are not subjective scores or rankings.':'六个维度用于组织证据，不代表主观评分或排名。';const foot=$('.dashboardFoot',d);if(foot){foot.innerHTML=en?'Source: <a href="https://www.moe.gov.cn/srcsite/A05/s3040/202412/t20241219_1167656.html" target="_blank" rel="noopener">2023 National Education Expenditure Statistical Bulletin</a>, Ministry of Education, National Bureau of Statistics and Ministry of Finance. Total expenditure: RMB 6.459504 trillion; state fiscal education funds: RMB 5.043947 trillion; 4.00% of GDP; general-budget education spending: 14.86% of general public-budget expenditure.':'来源：<a href="https://www.moe.gov.cn/srcsite/A05/s3040/202412/t20241219_1167656.html" target="_blank" rel="noopener">教育部、国家统计局、财政部《2023年全国教育经费执行情况统计公告》</a>。2023年全国教育经费总投入64595.04亿元；国家财政性教育经费50439.47亿元；占GDP 4.00%；一般公共预算教育经费占一般公共预算支出14.86%。';}}
function animatePie(pie){if(!pie)return;const reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;pie.classList.remove('v30-pie-drawing');pie.style.setProperty('background','conic-gradient(#1e658d 0deg 281.16deg,#d5b05a 281.16deg 360deg)','important');if(reduce)return;pie.classList.add('v30-pie-drawing');const start=performance.now(),dur=1350;function frame(now){const p=Math.min(1,(now-start)/dur),e=1-Math.pow(1-p,3),a=281.16*e;pie.style.setProperty('background',`conic-gradient(#1e658d 0deg ${a}deg,#d5b05a ${a}deg 360deg)`,'important');if(p<1)requestAnimationFrame(frame);else{pie.classList.remove('v30-pie-drawing');pie.style.setProperty('background','conic-gradient(#1e658d 0deg 281.16deg,#d5b05a 281.16deg 360deg)','important')}}requestAnimationFrame(frame)}
function animateCard(card){if(!card||card.dataset.v30Played==='1')return;card.dataset.v30Played='1';card.classList.remove('v30-enter-run');void card.offsetWidth;card.classList.add('v30-enter-run');const line=$('.dashLine',card);if(line){line.style.strokeDashoffset='100';line.getBoundingClientRect();line.style.animation='v30LineDraw 1.8s cubic-bezier(.2,.7,.2,1) forwards'}const trace=$('.radarTrace',card);if(trace){trace.style.strokeDashoffset='100';trace.style.animation='v30LineDraw 1.8s cubic-bezier(.2,.7,.2,1) forwards'}const pie=$('.dashDonut',card);if(pie)animatePie(pie);const bars=$$('.dashBars i b',card);bars.forEach(b=>{const target=b.dataset.width||b.style.getPropertyValue('--v')||'100%';b.style.width='0';requestAnimationFrame(()=>b.style.width=target)});}
function setupResearchAnimation(){const d=$('#researchDashboard');if(!d||d.dataset.v30Observer)return;d.dataset.v30Observer='1';const cards=$$('.dashChart',d);const play=()=>cards.forEach((c,i)=>{setTimeout(()=>animateCard(c),i*180)});if('IntersectionObserver'in window){const io=new IntersectionObserver(entries=>{if(entries.some(e=>e.isIntersecting)){play();io.disconnect()}},{threshold:.16});io.observe(d)}else{setTimeout(play,500)}cards.forEach(c=>{c.addEventListener('click',e=>{if(e.target.closest('a,button'))return;c.dataset.v30Played='0';animateCard(c)});c.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();c.dataset.v30Played='0';animateCard(c)}})});}
function init(){redesignJoin();$$('.focusCard.is-active').forEach(c=>c.classList.remove('is-active'));translateDashboard();setupResearchAnimation();document.documentElement.classList.add('v30-ready');}
function bindLanguage(){const b=$('#langBtn');if(b&&!b.dataset.v30Hook){b.dataset.v30Hook='1';b.addEventListener('click',()=>{[0,50,180,450,850].forEach(ms=>setTimeout(()=>{translateDashboard();},ms))})}}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>{init();bindLanguage()},{once:true});else{init();bindLanguage()}[120,420,900,1500].forEach(ms=>setTimeout(()=>{redesignJoin();translateDashboard();setupResearchAnimation()},ms));
})();


/* ===== Consolidated legacy patch v31-fixes.js ===== */
/* V31 retained for non-illustration legacy fixes; home SVG renderers retired in v53. */
(()=>{'use strict';
const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>Array.from(r.querySelectorAll(s));
const reduced=()=>window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const style=document.createElement('style');style.id='v31-final-fixes';style.textContent=`
/* Stable refresh: never animate the entire active page on load/navigation. */
.page,.page.active{animation:none!important;transform:none!important}
/* The two home cards are neutral until deliberate interaction. */
#page-home .focusCard[data-focus="equity"],#page-home .focusCard[data-focus="dignity"]{border-color:inherit;box-shadow:none}
#page-home .focusCard[data-focus="equity"]:not(:hover):not(:focus-visible):not(:focus-within),#page-home .focusCard[data-focus="dignity"]:not(:hover):not(:focus-visible):not(:focus-within){filter:none}
#page-home .focusCard[data-focus="equity"] .kineticSvg *,#page-home .focusCard[data-focus="dignity"] .kineticSvg *{animation-play-state:running!important}
#page-home .focusCard[data-focus="equity"] .kineticSvg,#page-home .focusCard[data-focus="dignity"] .kineticSvg{width:100%;height:auto;display:block;overflow:visible}
/* Scroll reveal: only content below the initial viewport is hidden; no first-paint flash. */
.v31-scroll-pending{opacity:0!important;transform:translate3d(0,20px,0)!important}
.v31-scroll-enter{animation:v31FadeIn .72s cubic-bezier(.2,.7,.2,1) both!important}
@keyframes v31FadeIn{from{opacity:0;transform:translate3d(0,20px,0)}to{opacity:1;transform:translate3d(0,0,0)}}

@keyframes v31Float{0%,100%{transform:translateY(0)}50%{transform:translateY(-3px)}}
@keyframes v31Wave{0%{opacity:.1;transform:scale(.8)}60%{opacity:.85;transform:scale(1.05)}100%{opacity:.1;transform:scale(1.18)}}
/* Charts animate only when their cards enter the viewport; SVG paths use normalized pathLength. */
#researchDashboard .dashChart.v31-chart-visible .dashLine,#researchDashboard .dashChart.v31-chart-visible .radarTrace{stroke-dasharray:100!important;stroke-dashoffset:100!important;animation:v31Draw 1.7s cubic-bezier(.2,.7,.2,1) forwards!important}
#researchDashboard .dashChart.v31-chart-visible .radarArea{animation:v31Area 1.3s ease-out both!important}
#researchDashboard .dashChart .dashLine,#researchDashboard .dashChart .radarTrace{stroke-dasharray:100!important;stroke-dashoffset:0!important;animation:none!important}
#researchDashboard .dashChart.v31-chart-visible .dashLine,#researchDashboard .dashChart.v31-chart-visible .radarTrace{stroke-dashoffset:100!important}
#researchDashboard .dashBars i b{transition:width 1.15s cubic-bezier(.2,.7,.2,1)!important}
#researchDashboard .dashDonut{background:conic-gradient(#1e658d 0deg 281.16deg,#d5b05a 281.16deg 360deg)!important;transform:none!important}
#researchDashboard .dashDonut.v31-pie-running{animation:v31PiePop .7s ease-out both!important}
@keyframes v31Draw{to{stroke-dashoffset:0}}
@keyframes v31Area{from{opacity:0}to{opacity:1}}
@keyframes v31PiePop{0%{transform:scale(.88);filter:saturate(.65)}70%{transform:scale(1.035)}100%{transform:scale(1);filter:saturate(1)}}
@media(prefers-reduced-motion:reduce){.v31-scroll-pending{opacity:1!important;transform:none!important}}
`;document.head.append(style);
function redesignJoin(){}
function langIsEnglish(){return (document.documentElement.lang||'zh-CN').toLowerCase().startsWith('en')}
function translateDashboard(){if(window.__cerpV41ControllerActive)return;const d=$('#researchDashboard');if(!d)return;const en=langIsEnglish();d.querySelectorAll('[data-en][data-zh]').forEach(el=>{const value=en?el.dataset.en:el.dataset.zh;if(value!=null&&el.innerHTML!==value)el.innerHTML=value});const set=(s,zh,enText)=>{const el=$(s,d);if(el)el.textContent=en?enText:zh};set('.dashboardHead .kicker','官方统计 / 数据素养','OFFICIAL STATISTICS / DATA LITERACY');set('.dashboardHead h3','中国教育：把官方统计转化为可检验的问题','China education: turn official statistics into testable questions');set('.dashboardHead p','以官方统计为起点，提出有关教育规模、经费投入与机会公平的可检验问题。数据保留原始统计口径与单位。','Use official statistics as a starting point for testable questions about educational scale, investment and equity. Figures retain the source definitions and units.');const metrics=$$('.dashboardMetrics article',d),mzh=['全国教育经费总投入','国家财政性教育经费','财政性教育经费占 GDP','一般公共预算教育经费占比'],men=['Total education expenditure','State fiscal education funds','Fiscal education funds / GDP','General-budget education / public-budget expenditure'];metrics.forEach((c,i)=>{const el=$('span',c);if(el)el.textContent=(en?men:mzh)[i]||'';const sm=$('strong small',c);if(sm&&i<2)sm.textContent=en?'RMB billion':'亿元'});const charts=$$('.dashChart',d),zhTitles=['各级教育经费投入（亿元）','全国教育经费总投入（2013—2023，亿元）','财政性教育经费占教育经费总投入','证据维度'],enTitles=['Education expenditure by level (RMB billion)','Total education expenditure (2013–2023, RMB billion)','Fiscal education funds as a share of total expenditure','Evidence dimensions'],zhCaps=['01 / 柱状图','02 / 趋势','03 / 构成','04 / 多维指标'],enCaps=['01 / BAR CHART','02 / TREND','03 / SHARE','04 / MULTI-METRIC'];charts.forEach((c,i)=>{const h=$('.dashChartTop h4',c),cap=$('.dashChartTop span',c);if(h)h.textContent=(en?enTitles:zhTitles)[i]||'';if(cap)cap.textContent=(en?enCaps:zhCaps)[i]||''});const bars=$$('.dashBars>div',d),names=en?['Compulsory education','Higher education','Upper secondary','Pre-primary']:['义务教育','高等教育','高中阶段','学前教育'];bars.forEach((b,i)=>{const s=$('span',b);if(s)s.textContent=names[i]||''});const donut=$('.dashDonut',d);if(donut){const sm=$('small',donut);if(sm)sm.textContent=en?'Fiscal funds':'财政性经费';const lis=$$('.donutRow li',d);if(lis[0])lis[0].innerHTML='<i></i>'+(en?'Fiscal funds':'财政性经费')+' <b>78.1%</b>';if(lis[1])lis[1].innerHTML='<i></i>'+(en?'Other sources':'其他来源')+' <b>21.9%</b>'}const radar=$('.dashRadar',d);if(radar){const labels=en?['SCALE','FUNDING','GROWTH','SCOPE','SOURCE','ACCESS']:['规模','投入','增长','口径','来源','可及'];$$('text',radar).forEach((el,i)=>{if(labels[i])el.textContent=labels[i]})}const foot=$('.dashboardFoot',d);if(foot){foot.innerHTML=en?'Source: <a href="https://www.moe.gov.cn/srcsite/A05/s3040/202412/t20241219_1167656.html" target="_blank" rel="noopener">2023 National Education Expenditure Statistical Bulletin</a>, Ministry of Education, National Bureau of Statistics and Ministry of Finance. Total expenditure: RMB 6.459504 trillion; state fiscal education funds: RMB 5.043947 trillion; 4.00% of GDP; general-budget education spending: 14.86% of general public-budget expenditure.':'来源：<a href="https://www.moe.gov.cn/srcsite/A05/s3040/202412/t20241219_1167656.html" target="_blank" rel="noopener">教育部、国家统计局、财政部《2023年全国教育经费执行情况统计公告》</a>。2023年全国教育经费总投入64595.04亿元；国家财政性教育经费50439.47亿元；占 GDP 4.00%；一般公共预算教育经费占一般公共预算支出14.86%。'}}
function drawLine(chart){const path=$('.dashLine',chart);if(!path)return;path.style.setProperty('stroke-dasharray','100','important');path.style.setProperty('stroke-dashoffset','100','important');path.style.setProperty('animation','none','important');path.getBoundingClientRect();if(!reduced())path.style.setProperty('animation','v31Draw 1.7s cubic-bezier(.2,.7,.2,1) forwards','important');else path.style.setProperty('stroke-dashoffset','0','important')}
function playPie(pie){if(!pie)return;pie.classList.remove('v31-pie-running');pie.style.setProperty('background','conic-gradient(#1e658d 0deg 0deg,#d5b05a 0deg 360deg)','important');pie.getBoundingClientRect();if(reduced()){pie.style.setProperty('background','conic-gradient(#1e658d 0deg 281.16deg,#d5b05a 281.16deg 360deg)','important');return}const start=performance.now(),duration=1250;function step(now){const p=Math.min(1,(now-start)/duration),ease=1-Math.pow(1-p,3),angle=281.16*ease;pie.style.setProperty('background',`conic-gradient(#1e658d 0deg ${angle}deg,#d5b05a ${angle}deg 360deg)`,'important');if(p<1)requestAnimationFrame(step);else{pie.style.setProperty('background','conic-gradient(#1e658d 0deg 281.16deg,#d5b05a 281.16deg 360deg)','important');pie.classList.add('v31-pie-running')}}requestAnimationFrame(step)}
function playChart(chart){if(!chart||chart.dataset.v31Played==='1')return;chart.dataset.v31Played='1';chart.classList.remove('v31-chart-visible');void chart.offsetWidth;chart.classList.add('v31-chart-visible');const bars=$$('.dashBars i b',chart);bars.forEach(b=>{let target=b.dataset.width||b.style.width||'100%';if(target==='0px'||target==='0%')target=b.getAttribute('data-width')||'100%';b.style.width='0';requestAnimationFrame(()=>{b.style.width=target})});drawLine(chart);const radar=$('.radarTrace',chart);if(radar){radar.style.setProperty('stroke-dasharray','100','important');radar.style.setProperty('stroke-dashoffset','100','important');radar.style.setProperty('animation',reduced()?'none':'v31Draw 1.7s cubic-bezier(.2,.7,.2,1) forwards','important');if(reduced())radar.style.setProperty('stroke-dashoffset','0','important')}const pie=$('.dashDonut',chart);if(pie)playPie(pie)}
function setupDashboard(d){if(!d||d.dataset.v31Init==='1')return;d.dataset.v31Init='1';translateDashboard();const charts=$$('.dashChart',d);charts.forEach(c=>{c.dataset.v31Played='0';c.addEventListener('click',e=>{if(e.target.closest('a,button'))return;c.dataset.v31Played='0';playChart(c)});c.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();c.dataset.v31Played='0';playChart(c)}})});if('IntersectionObserver'in window){const chartObserver=new IntersectionObserver(entries=>{entries.forEach(entry=>{if(entry.isIntersecting){playChart(entry.target);chartObserver.unobserve(entry.target)}})},{threshold:.2});charts.forEach(c=>chartObserver.observe(c));const dashObserver=new IntersectionObserver(entries=>{if(entries.some(e=>e.isIntersecting)){d.classList.add('v31-dashboard-visible');dashObserver.disconnect()}},{threshold:.08});dashObserver.observe(d)}else charts.forEach(playChart)}
/* Observe only node insertions / active-page switches; never observe text mutations (avoids loops). */
const revealTargets='.sectionHead,.focusCard,.card,.principle,.reportCard,.stat,.valueCard,.mapNode,.workstream,.govItem,.researchSignal,.researchDashboard,.dashboardMetrics article,.dashChart,.charterVisualCard,.joinPanel,.joinVisual,.timeline .item,.detailBody > *,.resourceCard,.faqCard,.checklistGrid label,.policyLab,.metricDashboard,.reformMap .mapNode';
let revealObserver=null;
function registerReveal(root=document){const els=$$(revealTargets,root);els.forEach(el=>{if(el.dataset.v31Reveal==='1')return;const page=el.closest('.page');if(page&&!page.classList.contains('active'))return;el.dataset.v31Reveal='1';const rect=el.getBoundingClientRect();if(rect.top>window.innerHeight*.92)el.classList.add('v31-scroll-pending');if(revealObserver)revealObserver.observe(el)})}
function revealInit(){if('IntersectionObserver'in window){revealObserver=new IntersectionObserver(entries=>{entries.forEach(entry=>{if(entry.isIntersecting){const el=entry.target;el.classList.remove('v31-scroll-pending');if(!reduced()&&el.dataset.v31HasEntered!=='1'){el.dataset.v31HasEntered='1';el.classList.remove('v31-scroll-enter');void el.offsetWidth;el.classList.add('v31-scroll-enter');el.addEventListener('animationend',()=>el.classList.remove('v31-scroll-enter'),{once:true})}revealObserver.unobserve(el)}})},{threshold:.08,rootMargin:'0px 0px -5% 0px'})}registerReveal();}
function onActivePage(){registerReveal();const d=$('#researchDashboard');if(d)setupDashboard(d);redesignJoin();translateDashboard()}
function run(){redesignJoin();translateDashboard();revealInit();const d=$('#researchDashboard');if(d)setupDashboard(d);const home=$('#page-home');if(home)$$('.focusCard.is-active',home).forEach(c=>c.classList.remove('is-active'));}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',run,{once:true});else run();
const langButton=$('#langBtn');if(langButton)langButton.addEventListener('click',()=>{[0,80,250,600,1100].forEach(ms=>setTimeout(()=>{translateDashboard();redesignJoin();const d=$('#researchDashboard');if(d)setupDashboard(d);registerReveal()},ms))});
const langObserver=new MutationObserver(()=>{translateDashboard()});langObserver.observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
const domObserver=new MutationObserver(records=>{let relevant=false;for(const rec of records){for(const node of rec.addedNodes){if(node.nodeType!==1)continue;if(node.id==='researchDashboard'||node.querySelector?.('#researchDashboard'))relevant=true;if(node.matches?.(revealTargets)||node.querySelector?.(revealTargets))registerReveal(node)}}if(relevant){const d=$('#researchDashboard');if(d)setupDashboard(d);translateDashboard()}});domObserver.observe(document.body,{childList:true,subtree:true});
document.addEventListener('click',e=>{if(e.target.closest('a[href^="#"],.navlinks a,.mobileNav a,.menuBtn'))setTimeout(onActivePage,80)});
setTimeout(onActivePage,150);setTimeout(onActivePage,700);
})();


/* ===== Consolidated legacy patch v32-final-fixes.js ===== */
/* V32 retained for research-dashboard animations only; legacy home SVG rules removed in v53. */
(()=>{'use strict';
const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>Array.from(r.querySelectorAll(s));
const reduced=()=>matchMedia('(prefers-reduced-motion: reduce)').matches;
const css=document.createElement('style');css.id='v32-final-overrides';css.textContent=`
/* Keep these two cards identical to their siblings: no accidental white focus border. */
#page-home .focusCard[data-focus="equity"],#page-home .focusCard[data-focus="dignity"]{border:1px solid #ffffff20!important;outline:0!important;box-shadow:none!important}
#page-home .focusCard[data-focus="equity"]:hover,#page-home .focusCard[data-focus="dignity"]:hover{border-color:#d8ad4f9c!important;box-shadow:0 28px 60px #0003!important}
#page-home .focusCard[data-focus="equity"]:focus-visible,#page-home .focusCard[data-focus="dignity"]:focus-visible{outline:2px solid #d8ad4f9c!important;outline-offset:3px!important}
#page-home .focusCard[data-focus="equity"] .focusArt:after,#page-home .focusCard[data-focus="dignity"] .focusArt:after{pointer-events:none}




/* Reveal cards and animate charts together only when they actually enter the viewport. */
#researchDashboard .v32-reveal-pending{opacity:0!important;transform:translateY(18px)!important}
#researchDashboard .v32-reveal-active{animation:v32Reveal .7s cubic-bezier(.2,.7,.2,1) both!important}
@keyframes v32Reveal{from{opacity:0;transform:translateY(18px)}to{opacity:1;transform:translateY(0)}}
#researchDashboard .dashChart .dashLine,#researchDashboard .dashChart .radarTrace{stroke-dasharray:100!important;stroke-dashoffset:0!important;animation:none!important}
#researchDashboard .dashChart.v32-running .dashLine,#researchDashboard .dashChart.v32-running .radarTrace{stroke-dasharray:100!important;stroke-dashoffset:100!important;animation:v32Draw 1.8s cubic-bezier(.2,.7,.2,1) forwards!important}
#researchDashboard .dashChart.v32-running .radarArea{animation:v32Area 1.3s ease-out both!important}
#researchDashboard .dashChart .dashBars i b{width:0!important;transition:width 1.2s cubic-bezier(.2,.7,.2,1)!important}
#researchDashboard .dashChart.v32-running .dashBars i b{width:var(--v,100%)!important}
#researchDashboard .dashChart .dashDonut{background:conic-gradient(#1e658d 0deg 281.16deg,#d5b05a 281.16deg 360deg)!important;transform:none!important}
#researchDashboard .dashChart.v32-running .dashDonut{animation:v32PiePop .65s ease-out both!important}
#researchDashboard .dashChart.v32-running .radarPoints circle{animation:v32Point .42s ease-out both!important}
#researchDashboard .dashChart.v32-running .radarPoints circle:nth-child(2){animation-delay:.08s!important}#researchDashboard .dashChart.v32-running .radarPoints circle:nth-child(3){animation-delay:.16s!important}#researchDashboard .dashChart.v32-running .radarPoints circle:nth-child(4){animation-delay:.24s!important}#researchDashboard .dashChart.v32-running .radarPoints circle:nth-child(5){animation-delay:.32s!important}#researchDashboard .dashChart.v32-running .radarPoints circle:nth-child(6){animation-delay:.4s!important}
@keyframes v32Draw{to{stroke-dashoffset:0}}@keyframes v32Area{from{opacity:0;fill-opacity:0}to{opacity:1;fill-opacity:1}}@keyframes v32PiePop{0%{transform:scale(.88)}70%{transform:scale(1.04)}100%{transform:scale(1)}}@keyframes v32Point{from{opacity:.1;transform:scale(.4)}to{opacity:1;transform:scale(1)}}
@media(prefers-reduced-motion:reduce){#researchDashboard .v32-reveal-pending{opacity:1!important;transform:none!important}#researchDashboard .dashChart .dashBars i b{width:var(--v,100%)!important}}
`;document.head.append(css);
function translateDashboard(){if(window.__cerpV41ControllerActive)return;const d=$('#researchDashboard');if(!d)return;const en=(document.documentElement.lang||'zh-CN').toLowerCase().startsWith('en');const set=(s,zh,eng)=>{const e=$(s,d);if(e)e.textContent=en?eng:zh};set('.dashboardHead .kicker','官方统计 / 数据素养','OFFICIAL STATISTICS / DATA LITERACY');set('.dashboardHead h3','中国教育：把官方统计转化为可检验的问题','China education: turn official statistics into testable questions');set('.dashboardHead p','以官方统计为起点，提出有关教育规模、经费投入与机会公平的可检验问题。数据保留原始统计口径与单位。','Use official statistics to pose testable questions about educational scale, funding and opportunity. Figures retain source definitions and units.');const caps=$$('.dashChartTop span',d),titles=$$('.dashChartTop h4',d);['01 / 柱状图','02 / 趋势','03 / 构成','04 / 多维指标'].forEach((v,i)=>{if(caps[i])caps[i].textContent=en?['01 / BAR CHART','02 / TREND','03 / SHARE','04 / MULTI-METRIC'][i]:v});['各级教育经费投入（亿元）','全国教育经费总投入（2013—2023，亿元）','财政性教育经费占教育经费总投入','证据维度'].forEach((v,i)=>{if(titles[i])titles[i].textContent=en?['Education expenditure by level (RMB billion)','Total education expenditure (2013–2023, RMB billion)','Fiscal education funds as a share of total expenditure','Evidence dimensions'][i]:v});const foot=$('.dashboardFoot',d);if(foot&&!en)foot.innerHTML='来源：<a href="https://www.moe.gov.cn/srcsite/A05/s3040/202412/t20241219_1167656.html" target="_blank" rel="noopener">教育部、国家统计局、财政部《2023年全国教育经费执行情况统计公告》</a>。2023年全国教育经费总投入64595.04亿元；国家财政性教育经费50439.47亿元；占 GDP 4.00%；一般公共预算教育经费占一般公共预算支出14.86%。';else if(foot&&en)foot.innerHTML='Source: <a href="https://www.moe.gov.cn/srcsite/A05/s3040/202412/t20241219_1167656.html" target="_blank" rel="noopener">2023 National Education Expenditure Statistical Bulletin</a>, Ministry of Education, National Bureau of Statistics and Ministry of Finance. Total expenditure: RMB 6.459504 trillion; state fiscal education funds: RMB 5.043947 trillion; 4.00% of GDP; general-budget education spending: 14.86% of general public-budget expenditure.';}
function animateChart(c){if(!c||c.dataset.v32Played==='1')return;c.dataset.v32Played='1';c.classList.remove('v32-running');void c.offsetWidth;c.classList.add('v32-running');const bars=$$('.dashBars i b',c);bars.forEach(b=>{const val=b.style.getPropertyValue('--v')||b.dataset.width||'100%';b.style.setProperty('--v',val);b.style.setProperty('width','0','important');void b.offsetWidth;requestAnimationFrame(()=>b.style.setProperty('width',val,'important'))});const line=$('.dashLine',c),radar=$('.radarTrace',c);[line,radar].filter(Boolean).forEach(p=>{p.style.setProperty('stroke-dasharray','100','important');p.style.setProperty('stroke-dashoffset','100','important');p.style.setProperty('animation','none','important');void p.getBoundingClientRect();if(!reduced())p.style.setProperty('animation','v32Draw 1.8s cubic-bezier(.2,.7,.2,1) forwards','important');else p.style.setProperty('stroke-dashoffset','0','important')});const area=$('.radarArea',c);if(area){area.style.setProperty('opacity','0','important');void area.getBoundingClientRect();if(!reduced())area.style.setProperty('animation','v32Area 1.3s ease-out both','important');else area.style.setProperty('opacity','1','important')}const points=$$('.radarPoints circle',c);points.forEach(p=>{p.style.setProperty('opacity','0','important');if(!reduced())p.style.setProperty('animation','v32Point .42s ease-out both','important');else p.style.setProperty('opacity','1','important')});const pie=$('.dashDonut',c);if(pie){pie.style.setProperty('background','conic-gradient(#1e658d 0deg 0deg,#d5b05a 0deg 360deg)','important');if(reduced()){pie.style.setProperty('background','conic-gradient(#1e658d 0deg 281.16deg,#d5b05a 281.16deg 360deg)','important')}else{const start=performance.now(),duration=1250;const step=now=>{const p=Math.min(1,(now-start)/duration),q=1-Math.pow(1-p,3),a=281.16*q;pie.style.setProperty('background',`conic-gradient(#1e658d 0deg ${a}deg,#d5b05a ${a}deg 360deg)`,'important');if(p<1)requestAnimationFrame(step)};requestAnimationFrame(step)}}}
let chartObserver=null,revealObserver=null;
function setupResearch(){const d=$('#researchDashboard');if(!d)return;translateDashboard();if(d.dataset.v32Init==='1')return;d.dataset.v32Init='1';if(chartObserver)chartObserver.disconnect();if(revealObserver)revealObserver.disconnect();const cards=$$('.dashChart',d);cards.forEach(c=>{c.dataset.v32Played='0';c.classList.remove('v32-running','v32-reveal-active','v32-reveal-pending');c.addEventListener('click',()=>{c.dataset.v32Played='0';animateChart(c)},{passive:true});c.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();c.dataset.v32Played='0';animateChart(c)}})});if(!('IntersectionObserver'in window)){cards.forEach(animateChart);return}chartObserver=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){const c=e.target;c.classList.remove('v32-reveal-pending');if(!reduced()){c.classList.remove('v32-reveal-active');void c.offsetWidth;c.classList.add('v32-reveal-active')}animateChart(c);chartObserver.unobserve(c)}}),{threshold:.18,rootMargin:'0px 0px -4% 0px'});cards.forEach(c=>{c.classList.add('v32-reveal-pending');chartObserver.observe(c)});revealObserver=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.classList.remove('v32-reveal-pending');if(!reduced()){e.target.classList.remove('v32-reveal-active');void e.target.offsetWidth;e.target.classList.add('v32-reveal-active')}revealObserver.unobserve(e.target)}}),{threshold:.08,rootMargin:'0px 0px -4% 0px'});$$('.dashboardMetrics article',d).forEach(el=>{el.classList.add('v32-reveal-pending');revealObserver.observe(el)});}
function run(){translateDashboard();setupResearch();}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',run,{once:true});else run();
// Dashboard is rebuilt by the legacy language switcher. Reattach observers to the new DOM and restore Chinese title after old delayed callbacks.
let setupTimer;const schedule=()=>{clearTimeout(setupTimer);setupTimer=setTimeout(()=>{translateDashboard();setupResearch()},80)};
const mo=new MutationObserver(records=>{if(records.some(r=>r.type==='childList'&&[...r.addedNodes].some(n=>n.nodeType===1&&(n.id==='researchDashboard'||n.querySelector?.('#researchDashboard')))))schedule();if(records.some(r=>r.type==='attributes'&&r.attributeName==='lang'))schedule()});mo.observe(document.body,{subtree:true,childList:true});mo.observe(document.documentElement,{attributes:true,attributeFilter:['lang']});const lb=$('#langBtn');if(lb)lb.addEventListener('click',()=>{[60,180,420,850,1300,1900].forEach(ms=>setTimeout(()=>{translateDashboard();setupResearch()},ms))});
// Legacy delayed translation timers end at 1.5s; a final pass makes the Chinese default deterministic.
[200,600,1200,1800,2400].forEach(ms=>setTimeout(()=>{if(!document.documentElement.lang.toLowerCase().startsWith('en'))translateDashboard()},ms));
})();


/* ===== V33 retained non-illustration overrides: replayable charts and responsive issue map ===== */
(()=>{'use strict';
const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>Array.from(r.querySelectorAll(s));
const reduced=()=>window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;
const style=document.createElement('style');style.id='v33-authoritative-overrides';style.textContent=`
/* Keep all pages inside the viewport; the issue-map background must never create horizontal scrolling. */
html,body{width:100%;max-width:100%;overflow-x:visible!important}header{position:-webkit-sticky!important;position:sticky!important;top:0!important;z-index:1000!important;align-self:start!important}
#page-issues{width:100%;max-width:100vw;min-width:0;overflow:hidden!important;contain:paint;isolation:isolate}
#page-issues .section{width:100%;max-width:100vw;min-width:0;overflow:hidden!important;position:relative;contain:paint;background-clip:padding-box}
#page-issues .container{width:min(1200px,calc(100% - 32px));max-width:100%;min-width:0}
#issueGrid{width:100%;max-width:100%;min-width:0}
#issueGrid{grid-template-columns:repeat(3,minmax(0,1fr))}
#issueGrid>*{min-width:0;max-width:100%;overflow-wrap:anywhere}
@media(max-width:760px){#issueGrid{grid-template-columns:minmax(0,1fr)!important}#page-issues .section{padding-left:0;padding-right:0}#page-issues .container{width:calc(100% - 28px)}}
/* Match sibling focus cards: no anomalous white border or focus halo on these two cards. */

#page-home .focusCard[data-focus="equity"],#page-home .focusCard[data-focus="dignity"]{border-color:#ffffff20!important;outline:none!important;box-shadow:none}
#page-home .focusCard[data-focus="equity"]:hover,#page-home .focusCard[data-focus="dignity"]:hover,#page-home .focusCard[data-focus="equity"].is-active,#page-home .focusCard[data-focus="dignity"].is-active{border-color:#d8ad4f9c!important}
#page-home .focusCard[data-focus="equity"]:focus,#page-home .focusCard[data-focus="dignity"]:focus{outline:none!important}
#page-home .focusCard[data-focus="equity"]:focus-visible,#page-home .focusCard[data-focus="dignity"]:focus-visible{outline:2px solid #d8ad4f!important;outline-offset:3px!important}
.v33-trace{fill:none;stroke-linecap:round;stroke-linejoin:round;stroke-dasharray:var(--trace-length,420);stroke-dashoffset:var(--trace-length,420);animation:v33SolidTrace 6.4s cubic-bezier(.45,0,.25,1) infinite}
.v33-trace.delay1{animation-delay:-2.1s}.v33-trace.delay2{animation-delay:-4.2s}
.v33-pulse{transform-box:fill-box;transform-origin:center;animation:v33Pulse 3s ease-in-out infinite}
.v33-float{transform-box:fill-box;transform-origin:center;animation:v33Float 4.4s ease-in-out infinite}
@keyframes v33SolidTrace{0%{stroke-dashoffset:var(--trace-length,420);opacity:.65}68%,84%{stroke-dashoffset:0;opacity:1}99.9%,100%{stroke-dashoffset:var(--trace-length,420);opacity:.65}}


/* Research cards reveal one by one on scroll; line/radar/pie animations replay every time they re-enter or are clicked. */
#researchDashboard .v33-reveal-pending{opacity:0!important;transform:translateY(20px)!important}
#researchDashboard .v33-reveal-enter{animation:v33FadeIn .72s cubic-bezier(.2,.7,.2,1) both!important}
@keyframes v33FadeIn{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}
#researchDashboard .dashChart{min-width:0;will-change:opacity,transform}
#researchDashboard .dashLine,#researchDashboard .radarTrace{stroke-dasharray:100!important;stroke-dashoffset:100!important;animation:none!important}
#researchDashboard .radarArea{opacity:0!important;fill-opacity:0!important}
#researchDashboard .dashBars i b{width:0!important;transition:width 1.15s cubic-bezier(.2,.7,.2,1)!important}
#researchDashboard .dashDonut{background:conic-gradient(#1e658d 0deg 0deg,#d5b05a 0deg 360deg)!important;clip-path:none!important;transform:none}
@media(prefers-reduced-motion:reduce){.v33-trace,.v33-pulse,.v33-float{animation:none!important;stroke-dashoffset:0!important}#researchDashboard .v33-reveal-pending{opacity:1!important;transform:none!important}#researchDashboard .v33-reveal-enter{animation:none!important}#researchDashboard .dashLine,#researchDashboard .radarTrace{stroke-dashoffset:0!important}#researchDashboard .radarArea{opacity:1!important;fill-opacity:1!important}#researchDashboard .dashBars i b{width:var(--v,100%)!important;transition:none!important}}
`;
document.head.append(style);
function prepareJoinTraces(svg){svg.querySelectorAll('.v33-trace').forEach(p=>{try{const len=Math.ceil(p.getTotalLength()+1);p.style.setProperty('--trace-length',String(len));p.style.setProperty('stroke-dasharray',String(len));p.style.setProperty('stroke-dashoffset',String(len))}catch(e){}})}
function drawJoin(){}
function translateDashboard(){if(window.__cerpV41ControllerActive)return;const d=$('#researchDashboard');if(!d)return;const en=(document.documentElement.lang||'zh-CN').toLowerCase().startsWith('en');const title=$('.dashboardHead h3',d);if(title){const t=en?'China education: turn official statistics into testable questions':'中国教育：把官方统计转化为可检验的问题';if(title.textContent.trim()!==t)title.textContent=t}const set=(s,zh,eng)=>{const e=$(s,d);if(e&&e.textContent.trim()!==(en?eng:zh))e.textContent=en?eng:zh};set('.dashboardHead .kicker','官方统计 / 数据素养','OFFICIAL STATISTICS / DATA LITERACY');set('.dashboardHead p','以官方统计为起点，提出有关教育规模、经费投入与机会公平的可检验问题。数据保留原始统计口径与单位。','Use official statistics to pose testable questions about educational scale, funding and opportunity. Figures retain source definitions and units.');const caps=$$('.dashChartTop span',d),titles=$$('.dashChartTop h4',d);const zhCaps=['01 / 柱状图','02 / 趋势','03 / 构成','04 / 多维指标'],enCaps=['01 / BAR CHART','02 / TREND','03 / SHARE','04 / MULTI-METRIC'];const zhTitles=['各级教育经费投入（亿元）','全国教育经费总投入（2013—2023，亿元）','财政性教育经费占教育经费总投入','证据维度'],enTitles=['Education expenditure by level (RMB billion)','Total education expenditure (2013–2023, RMB billion)','Fiscal education funds as a share of total expenditure','Evidence dimensions'];caps.forEach((e,i)=>{const t=(en?enCaps:zhCaps)[i];if(t&&e.textContent.trim()!==t)e.textContent=t});titles.forEach((e,i)=>{const t=(en?enTitles:zhTitles)[i];if(t&&e.textContent.trim()!==t)e.textContent=t});const metricNames=en?['Total education spending','National fiscal education funds','Fiscal education funds / GDP','General budget education / budget expenditure']:['全国教育经费总投入','国家财政性教育经费','财政性教育经费占GDP','一般公共预算教育经费占比'];$$('.dashboardMetrics article>span',d).forEach((e,i)=>{if(metricNames[i]&&e.textContent.trim()!==metricNames[i])e.textContent=metricNames[i]});const barNames=en?['Compulsory education','Higher education','Upper secondary','Pre-primary']:['义务教育','高等教育','高中阶段','学前教育'];$$('.dashBars>div>span',d).forEach((e,i)=>{if(barNames[i]&&e.textContent.trim()!==barNames[i])e.textContent=barNames[i]});const donut=$('.dashDonut',d);if(donut){const small=$('small',donut);if(small)small.textContent=en?'Fiscal funds':'财政性经费';const lis=$$('.donutRow li',d);if(lis[0])lis[0].innerHTML=`<i></i>${en?'Fiscal funds':'财政性经费'} <b>78.1%</b>`;if(lis[1])lis[1].innerHTML=`<i></i>${en?'Other sources':'其他来源'} <b>21.9%</b>`}const radar=$('.dashRadar',d);if(radar){const labels=en?['SCALE','FUNDING','GROWTH','SCOPE','SOURCE','ACCESS']:['规模','投入','增长','口径','来源','可及'];$$('text',radar).forEach((e,i)=>{if(labels[i]&&e.textContent!==labels[i])e.textContent=labels[i]})}const foot=$('.dashboardFoot',d);if(foot){const content=en?'Source: 2023 National Education Expenditure Statistical Bulletin, Ministry of Education, National Bureau of Statistics and Ministry of Finance. Total expenditure: RMB 6.459504 trillion; state fiscal education funds: RMB 5.043947 trillion; 4.00% of GDP; general-budget education spending: 14.86% of general public-budget expenditure.':'来源：教育部、国家统计局、财政部《2023年全国教育经费执行情况统计公告》。2023年全国教育经费总投入64595.04亿元；国家财政性教育经费50439.47亿元；占GDP 4.00%；一般公共预算教育经费占一般公共预算支出14.86%。';if(!foot.textContent.includes(en?'National Education Expenditure':'全国教育经费总投入'))foot.innerHTML=en?content:'来源：<a href="https://www.moe.gov.cn/srcsite/A05/s3040/202412/t20241219_1167656.html" target="_blank" rel="noopener">教育部、国家统计局、财政部《2023年全国教育经费执行情况统计公告》</a>。2023年全国教育经费总投入64595.04亿元；国家财政性教育经费50439.47亿元；占GDP 4.00%；一般公共预算教育经费占一般公共预算支出14.86%。'}}
function drawPath(path,duration=1800){if(!path)return;try{path.getAnimations().forEach(a=>a.cancel())}catch(e){}path.style.removeProperty('animation');path.style.removeProperty('stroke-dasharray');path.style.removeProperty('stroke-dashoffset');let len=100;try{if(path.getAttribute('pathLength')!=='100')len=Math.ceil(path.getTotalLength()+1)}catch(e){}path.style.setProperty('stroke-dasharray',String(len),'important');path.style.setProperty('stroke-dashoffset',String(len),'important');path.style.setProperty('animation','none','important');void path.getBoundingClientRect();if(reduced()){path.style.setProperty('stroke-dashoffset','0','important');return}const anim=path.animate([{strokeDashoffset:len},{strokeDashoffset:0}],{duration,easing:'cubic-bezier(.2,.7,.2,1)',fill:'forwards'});anim.onfinish=()=>path.style.setProperty('stroke-dashoffset','0','important')}
function playChart(chart){if(!chart)return;const line=$('.dashLine',chart),trace=$('.radarTrace',chart),area=$('.radarArea',chart),pie=$('.dashDonut',chart);[line,trace].filter(Boolean).forEach(p=>drawPath(p,1900));if(area){try{area.getAnimations().forEach(a=>a.cancel())}catch(e){}area.style.removeProperty('animation');area.style.removeProperty('opacity');area.style.removeProperty('fill-opacity');area.style.setProperty('transition','none','important');area.style.setProperty('opacity','0','important');area.style.setProperty('fill-opacity','0','important');void area.getBoundingClientRect();if(reduced()){area.style.setProperty('opacity','1','important');area.style.setProperty('fill-opacity','1','important')}else{area.style.setProperty('transition','opacity 1.25s ease-out, fill-opacity 1.25s ease-out','important');requestAnimationFrame(()=>{area.style.setProperty('opacity','1','important');area.style.setProperty('fill-opacity','1','important')})}}$$('.radarPoints circle',chart).forEach((p,i)=>{try{p.getAnimations().forEach(a=>a.cancel())}catch(e){}p.style.removeProperty('animation');p.style.removeProperty('opacity');p.style.removeProperty('transform');if(reduced()){p.style.setProperty('opacity','1','important');return}p.style.setProperty('opacity','.1','important');p.style.setProperty('transform','scale(.5)','important');p.style.setProperty('transform-origin','center','important');p.style.setProperty('transition',`opacity .42s ease-out ${350+i*75}ms, transform .42s ease-out ${350+i*75}ms`,'important');requestAnimationFrame(()=>{p.style.setProperty('opacity','1','important');p.style.setProperty('transform','scale(1)','important')})});$$('.dashBars i b',chart).forEach(b=>{const target=b.style.getPropertyValue('--v')||b.dataset.width||'100%';b.style.setProperty('--v',target);b.style.setProperty('transition','none','important');b.style.setProperty('width','0%','important');void b.offsetWidth;if(reduced()){b.style.setProperty('width',target,'important')}else{b.style.setProperty('transition','width 1.15s cubic-bezier(.2,.7,.2,1)','important');requestAnimationFrame(()=>b.style.setProperty('width',target,'important'))}});if(pie){try{pie.getAnimations().forEach(a=>a.cancel())}catch(e){}const share=Number(pie.dataset.share||78.1),finish=360*share/100;pie.style.setProperty('transition','none','important');pie.style.setProperty('background','conic-gradient(#1e658d 0deg 0deg,#d5b05a 0deg 360deg)','important');void pie.getBoundingClientRect();if(reduced()){pie.style.setProperty('background',`conic-gradient(#1e658d 0deg ${finish}deg,#d5b05a ${finish}deg 360deg)`,'important')}else{pie.style.setProperty('transition','background 1.25s cubic-bezier(.2,.7,.2,1), opacity .65s ease, transform .65s ease','important');pie.style.setProperty('opacity','.78','important');pie.style.setProperty('transform','scale(.94)','important');requestAnimationFrame(()=>{pie.style.setProperty('background',`conic-gradient(#1e658d 0deg ${finish}deg,#d5b05a ${finish}deg 360deg)`,'important');pie.style.setProperty('opacity','1','important');pie.style.setProperty('transform','scale(1)','important')})}}chart.dataset.v33Played='1'}
let chartIO=null,revealIO=null,activeDashboard=null;
function setupResearch(){const d=$('#researchDashboard');if(!d)return;translateDashboard();if(activeDashboard===d&&d.dataset.v34Init==='1')return;activeDashboard=d;d.dataset.v34Init='1';if(chartIO)chartIO.disconnect();if(revealIO)revealIO.disconnect();const charts=$$('.dashChart',d),metrics=$$('.dashboardMetrics article',d);[...metrics,...charts].forEach((el,i)=>{el.style.setProperty('--v33-delay',`${Math.min(8,i)*90}ms`);el.classList.add('v33-reveal-pending');el.classList.remove('v33-reveal-enter')});
// Capture clicks before legacy handlers, so every click replays exactly one clean animation.
if(!d.dataset.v34ReplayBound){d.dataset.v34ReplayBound='1';d.addEventListener('click',e=>{const c=e.target.closest('.dashChart');if(!c||!d.contains(c)||e.target.closest('a,button'))return;e.preventDefault();e.stopPropagation();e.stopImmediatePropagation();playChart(c)},true);d.addEventListener('keydown',e=>{const c=e.target.closest('.dashChart');if(!c||!d.contains(c)||!(e.key==='Enter'||e.key===' '))return;e.preventDefault();e.stopPropagation();e.stopImmediatePropagation();playChart(c)},true)}
if(!('IntersectionObserver'in window)){[...metrics,...charts].forEach(el=>{el.classList.remove('v33-reveal-pending');playChart(el)});return}
revealIO=new IntersectionObserver(entries=>entries.forEach(entry=>{if(!entry.isIntersecting)return;const el=entry.target;if(el.dataset.v33Revealed==='1')return;el.dataset.v33Revealed='1';el.classList.remove('v33-reveal-pending');if(!reduced()){el.classList.remove('v33-reveal-enter');void el.offsetWidth;el.classList.add('v33-reveal-enter');el.style.animationDelay=el.style.getPropertyValue('--v33-delay')}revealIO.unobserve(el)}),{threshold:.08,rootMargin:'0px 0px -6% 0px'});[...metrics,...charts].forEach(el=>revealIO.observe(el));chartIO=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting)playChart(entry.target)}),{threshold:.22,rootMargin:'0px 0px -5% 0px'});charts.forEach(c=>chartIO.observe(c))}
function redrawAll(){drawJoin();translateDashboard();setupResearch();attachTitleObserver()}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',redrawAll,{once:true});else redrawAll();
// Translation scripts in older patches may run delayed callbacks; enforce the selected language only when text actually differs.
let langTimer;const schedule=()=>{clearTimeout(langTimer);langTimer=setTimeout(()=>{drawJoin();translateDashboard();setupResearch()},80)};
const titleObserver=new MutationObserver(()=>{const d=$('#researchDashboard');if(!d)return;const h=$('.dashboardHead h3',d);if(!h)return;const en=(document.documentElement.lang||'zh-CN').toLowerCase().startsWith('en'),expected=en?'China education: turn official statistics into testable questions':'中国教育：把官方统计转化为可检验的问题';if(h.textContent.trim()!==expected)h.textContent=expected});
const attachTitleObserver=()=>{const h=$('#researchDashboard .dashboardHead h3');titleObserver.disconnect();if(h)titleObserver.observe(h,{childList:true,subtree:true,characterData:true})};
const mo=new MutationObserver(records=>{let changed=false;for(const r of records){if(r.type==='attributes'&&r.attributeName==='lang')changed=true;for(const n of r.addedNodes||[])if(n.nodeType===1&&(n.id==='researchDashboard'||n.querySelector?.('#researchDashboard')))changed=true}if(changed){schedule();setTimeout(attachTitleObserver,0)}});if(document.body)mo.observe(document.body,{childList:true,subtree:true});mo.observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
const langBtn=$('#langBtn');if(langBtn)langBtn.addEventListener('click',()=>[0,100,350,700,1200,1900].forEach(ms=>setTimeout(()=>{drawJoin();translateDashboard();setupResearch();attachTitleObserver()},ms)));
[250,800,1600,2400].forEach(ms=>setTimeout(()=>{translateDashboard();attachTitleObserver()},ms));
})();


/* ===== v38: single-owner research page reveals, language, and chart animations ===== */
(()=>{'use strict';
const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>Array.from(r.querySelectorAll(s));
const reduced=()=>window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const css=document.createElement('style');css.id='cerp-v38-research-css';css.textContent=`
/* One reveal system owns the whole research page. Defuse old pending/re-entry classes. */
#page-research .v29-reveal-pending,#page-research .v30-reveal-pending,#page-research .v31-scroll-pending,#page-research .v32-reveal-pending,#page-research .v33-reveal-pending,#page-research .v34-reveal-pending,#page-research .v35-chart-reveal,#page-research .v36-pending,#page-research .v37-pending{opacity:1!important;transform:none!important;transition:none!important;animation:none!important}
#page-research .v29-reveal-enter,#page-research .v30-reveal-enter,#page-research .v31-scroll-enter,#page-research .v32-reveal-active,#page-research .v33-reveal-enter,#page-research .v34-reveal-enter,#page-research .v35-chart-visible,#page-research .v36-entered,#page-research .v37-entered{animation:none!important;transition:none!important}
#page-research .reveal.cerp-v38-pending,#page-research .cerp-v38-pending{opacity:0!important;transform:translate3d(0,22px,0)!important;transition:opacity 1.15s cubic-bezier(.2,.7,.2,1),transform 1.15s cubic-bezier(.2,.7,.2,1)!important;animation:none!important;will-change:opacity,transform}
/* Pause every descendant animation while its card is outside the viewport. Resume only when the card is revealed. */
#page-research .cerp-v38-pending *{animation-play-state:paused!important}
#page-research .reveal.cerp-v38-revealed,#page-research .cerp-v38-revealed{opacity:1!important;transform:none!important;transition:opacity 1.15s cubic-bezier(.2,.7,.2,1),transform 1.15s cubic-bezier(.2,.7,.2,1)!important;animation:none!important}
#page-research .cerp-v38-pending .barTrack i{animation-play-state:paused!important}
#researchDashboard .dashLine,#researchDashboard .radarTrace{fill:none!important;animation:none!important}
#researchDashboard .metricTrack i,#researchDashboard .dashBars i b{transform-origin:left center!important;transition:none!important;animation:none!important}
#researchDashboard .dashDonut{transform:none!important;clip-path:none!important;animation:none!important}
@media(prefers-reduced-motion:reduce){#page-research .cerp-v38-pending{opacity:1!important;transform:none!important}#page-research .cerp-v38-revealed{transition:none!important}}
`;
document.head.append(css);
const revealed=new WeakSet(), played=new WeakSet();
const seenKeys=window.__cerpV38SeenKeys||(window.__cerpV38SeenKeys=new Set());
let activeObserver=null, currentDashboard=null, pageObserver=null, dashboardMO=null, pageMO=null, langTimer=0;
const text={
 kicker:['官方统计 / 数据素养','OFFICIAL STATISTICS / DATA LITERACY'],
 title:['中国教育：把官方统计转化为可检验的问题','China education: turn official statistics into testable questions'],
 intro:['以官方统计为起点，提出有关教育规模、经费投入与机会公平的可检验问题。数据保留原始统计口径与单位。','Use official statistics to pose testable questions about educational scale, funding and opportunity. Figures retain source definitions and units.'],
 caps:[['01 / 柱状图','01 / BAR CHART'],['02 / 趋势','02 / TREND'],['03 / 构成','03 / SHARE'],['04 / 多维指标','04 / MULTI-METRIC']],
 titles:[['各级教育经费投入（亿元）','Education expenditure by level (RMB billion)'],['全国教育经费总投入（2013—2023，亿元）','Total education expenditure (2013–2023, RMB billion)'],['财政性教育经费占教育经费总投入','Fiscal education funds as a share of total expenditure'],['证据维度','Evidence dimensions']]
};
function english(){return /^en(?:-|$)/i.test(document.documentElement.lang||'zh-CN')}
function setText(el,zh,en){if(!el)return;const value=english()?en:zh;if(el.textContent.trim()!==value)el.textContent=value}
function translatePage(){
 const d=$('#researchDashboard');
 if(d){setText($('.dashboardHead .kicker',d),...text.kicker);setText($('.dashboardHead h3',d),...text.title);setText($('.dashboardHead p',d),...text.intro);
  $$('.dashChart',d).forEach((c,i)=>{setText($('.dashChartTop span',c),...(text.caps[i]||['','']));setText($('.dashChartTop h4',c),...(text.titles[i]||['','']))});
  const metricZh=['全国教育经费总投入','国家财政性教育经费','财政性教育经费占GDP','一般公共预算教育经费占比'],metricEn=['Total education expenditure','State fiscal education funds','Fiscal education funds / GDP','General-budget education / public-budget expenditure'];
  $$('.dashboardMetrics article>span',d).forEach((e,i)=>setText(e,metricZh[i]||'',metricEn[i]||''));
  const barZh=['义务教育','高等教育','高中阶段','学前教育'],barEn=['Compulsory education','Higher education','Upper secondary','Pre-primary'];$$('.dashBars>div>span',d).forEach((e,i)=>setText(e,barZh[i]||'',barEn[i]||''));
  const donut=$('.dashDonut',d);if(donut){setText($('small',donut),'财政性经费','Fiscal funds');const rows=$$('.donutRow li',d);[['财政性经费','Fiscal funds','78.1%'],['其他来源','Other sources','21.9%']].forEach((v,i)=>{if(rows[i]){const label=english()?v[1]:v[0],html='<i></i>'+label+' <b>'+v[2]+'</b>';if(rows[i].innerHTML!==html)rows[i].innerHTML=html}});donut.setAttribute('aria-label',english()?'Fiscal education funds are 78.1% of total expenditure':'财政性教育经费占总投入约78.1%')}
  const radar=$('.dashRadar',d);if(radar){const labels=english()?['SCALE','FUNDING','GROWTH','SCOPE','SOURCE','ACCESS']:['规模','投入','增长','口径','来源','可及'];$$('text',radar).forEach((e,i)=>{if(labels[i])setText(e,labels[i],labels[i])})}
  setText($('.dataChartNote',d),'全国教育经费总投入（亿元）：2013—2023年数据以官方统计公报为准；2021年57873.67，2022年61329.14，2023年64595.04。','National education expenditure (RMB billion): use official bulletins for 2013–2023; 2021 57,873.67, 2022 61,329.14, 2023 64,595.04.');
  setText($('.radarNote',d),'六个维度用于组织证据，不代表主观评分或排名。','Six dimensions organise evidence; they are not subjective scores or rankings.');
  const foot=$('.dashboardFoot',d);if(foot){const link='https://www.moe.gov.cn/srcsite/A05/s3040/202412/t20241219_1167656.html';const expectedLink=english()?'2023 National Education Expenditure Statistical Bulletin':'教育部、国家统计局、财政部《2023年全国教育经费执行情况统计公告》';const val=english()?`Source: <a href="${link}" target="_blank" rel="noopener">2023 National Education Expenditure Statistical Bulletin</a>, Ministry of Education, National Bureau of Statistics and Ministry of Finance. Total expenditure: RMB 6.459504 trillion; fiscal education funds: RMB 5.043947 trillion; 4.00% of GDP; general-budget education spending: 14.86% of general public-budget expenditure.`:`来源：<a href="${link}" target="_blank" rel="noopener">教育部、国家统计局、财政部《2023年全国教育经费执行情况统计公告》</a>。2023年全国教育经费总投入64595.04亿元；国家财政性教育经费50439.47亿元；占GDP 4.00%；一般公共预算教育经费占一般公共预算支出14.86%。`;const current=$('a',foot);if(!current||current.textContent.trim()!==expectedLink)foot.innerHTML=val}
 }
 const mainTitle=$('.researchReport .sectionHead h2');setText(mainTitle,'中国教育：把官方统计转化为可检验的问题','China education: turn official statistics into testable questions');
 const mainDesc=$('.researchReport .sectionHead p');setText(mainDesc,'用官方统计建立研究基线，而不把宏观指标直接等同于教育质量。阅读时应同时核对原始公报中的定义、年份和覆盖范围。','Use official statistics as a baseline, not as a proxy for educational quality. Read definitions, years and coverage alongside the original bulletin.');
}
function pathLength(p){try{return Math.max(1,p.getTotalLength())}catch(_){return 100}}
function drawPath(p,duration){if(!p)return;p.removeAttribute('pathLength');const len=pathLength(p);p.style.setProperty('animation','none','important');p.style.setProperty('stroke-dasharray',String(len),'important');p.style.setProperty('stroke-dashoffset',String(len),'important');if(reduced()){p.style.setProperty('stroke-dashoffset','0','important');return}const start=performance.now();const tick=now=>{const t=Math.min(1,(now-start)/duration),ease=1-Math.pow(1-t,2.25);p.style.setProperty('stroke-dashoffset',String(len*(1-ease)),'important');if(t<1)requestAnimationFrame(tick);else p.style.setProperty('stroke-dashoffset','0','important')};requestAnimationFrame(tick)}
function animateMetric(card){
 const bar=$('.metricTrack i',card);
 if(bar){const target=bar.dataset.width||bar.style.getPropertyValue('--initial-width')||bar.style.getPropertyValue('--metric-target')||'100%';bar.dataset.width=target;bar.style.setProperty('width',target,'important');bar.style.setProperty('transition','none','important');bar.style.setProperty('transform-origin','left center','important');bar.style.setProperty('transform','scaleX(0)','important');
  if(reduced())bar.style.setProperty('transform','scaleX(1)','important');else{let start=0;const duration=1250;const frame=now=>{if(!start)start=now;const q=Math.min(1,(now-start)/duration),ease=1-Math.pow(1-q,3);bar.style.setProperty('transform',`scaleX(${ease})`,'important');if(q<1)requestAnimationFrame(frame);else bar.style.setProperty('transform','scaleX(1)','important')};requestAnimationFrame(frame)}}
 const strong=$('strong[data-count]',card);if(strong){const target=Number(strong.dataset.count),dec=Math.max(0,Math.min(3,Number(strong.dataset.decimal||0))),node=Array.from(strong.childNodes).find(n=>n.nodeType===Node.TEXT_NODE);if(node&&Number.isFinite(target)){if(reduced()){node.textContent=target.toFixed(dec)}else{node.textContent=(0).toFixed(dec);let start=0;const duration=1250;const frame=now=>{if(!start)start=now;const q=Math.min(1,(now-start)/duration),ease=1-Math.pow(1-q,3);node.textContent=(target*ease).toFixed(dec);if(q<1)requestAnimationFrame(frame);else node.textContent=target.toFixed(dec)};requestAnimationFrame(frame)}}}
}
function animateChart(card,force=false){if(!force&&played.has(card))return;played.add(card);
 const line=$('.dashLine',card),trace=$('.radarTrace',card),area=$('.radarArea',card),pie=$('.dashDonut',card);
 if(line)drawPath(line,3600);if(trace)drawPath(trace,3400);
 if(area){area.style.setProperty('opacity','0','important');area.style.setProperty('fill-opacity','0','important');if(reduced()){area.style.setProperty('opacity','1','important');area.style.setProperty('fill-opacity','.18','important')}else{const t0=performance.now(),step=n=>{const q=Math.min(1,(n-t0)/1800);area.style.setProperty('opacity',String(q),'important');area.style.setProperty('fill-opacity',String(.18*q),'important');if(q<1)requestAnimationFrame(step)};requestAnimationFrame(step)}}
 $$('.radarPoints circle',card).forEach((p,i)=>{p.style.setProperty('opacity',reduced()?'1':'0','important');if(!reduced())setTimeout(()=>p.style.setProperty('opacity','1','important'),i*220)});
 $$('.dashBars i b',card).forEach(b=>{const target=b.dataset.width||b.style.getPropertyValue('--v')||'100%';b.dataset.width=target;b.style.setProperty('width',target,'important');b.style.setProperty('transition','none','important');b.style.setProperty('transform-origin','left center','important');b.style.setProperty('transform','scaleX(0)','important');if(reduced())b.style.setProperty('transform','scaleX(1)','important');else{let t0=0;const frame=now=>{if(!t0)t0=now;const q=Math.min(1,(now-t0)/2600),ease=1-Math.pow(1-q,3);b.style.setProperty('transform',`scaleX(${ease})`,'important');if(q<1)requestAnimationFrame(frame);else b.style.setProperty('transform','scaleX(1)','important')};requestAnimationFrame(frame)}});
 if(pie){const end=360*(Number(pie.dataset.share||78.1)/100);if(reduced()){pie.style.setProperty('background',`conic-gradient(#1e658d 0deg ${end}deg,#d5b05a ${end}deg 360deg)`,'important')}else{const t0=performance.now(),step=n=>{const q=Math.min(1,(n-t0)/3000),a=end*(1-Math.pow(1-q,3));pie.style.setProperty('background',`conic-gradient(#1e658d 0deg ${a}deg,#d5b05a ${a}deg 360deg)`,'important');if(q<1)requestAnimationFrame(step)};pie.style.setProperty('background','conic-gradient(#1e658d 0deg 0deg,#d5b05a 0deg 360deg)','important');requestAnimationFrame(step)}}
}
function reveal(el,key){if(revealed.has(el))return;revealed.add(el);el.classList.remove('cerp-v38-pending','visible');el.classList.add('cerp-v38-revealed');if(key)seenKeys.add(key);if(el.matches('.dashChart'))animateChart(el);else if(el.matches('.dashboardMetrics article'))animateMetric(el);if(activeObserver)activeObserver.unobserve(el)}
function pageItems(){const p=$('#page-research');if(!p)return[];const all=new Set($$('.reveal',p));$$('.dashboardMetrics article,.dashChart,.researchReport .reportGrid .reportCard,.officialEvidenceBoard,.metricDashboard,.glossaryGrid details',p).forEach(e=>all.add(e));return Array.from(all)}
function setup(){const p=$('#page-research');if(!p)return;translatePage();const d=$('#researchDashboard');currentDashboard=d;const items=pageItems();if(activeObserver)activeObserver.disconnect();
 /* Do not initialise visible chart animations while this SPA page is hidden. route() toggles .active; the page observer below re-arms setup on entry. */
 if(!p.classList.contains('active')){items.forEach((el,i)=>{el.classList.add('cerp-v38-pending');if(el.matches('.dashChart'))restoreStatic(el)});return}
 activeObserver=new IntersectionObserver(entries=>entries.forEach(e=>{if(!p.classList.contains('active')||!e.isIntersecting)return;const el=e.target,key=el.dataset.cerpV38Key;if(key&&seenKeys.has(key)){revealed.add(el);el.classList.remove('cerp-v38-pending','visible');el.classList.add('cerp-v38-revealed');activeObserver.unobserve(el);return}reveal(el,key)}),{threshold:.18,rootMargin:'0px 0px -22% 0px'});window.__cerpV38Observer=activeObserver;
 items.forEach((el,i)=>{el.classList.remove('v29-reveal-pending','v30-reveal-pending','v31-scroll-pending','v32-reveal-pending','v33-reveal-pending','v34-reveal-pending','v35-chart-reveal','v36-pending','v37-pending','v29-reveal-enter','v30-reveal-enter','v31-scroll-enter','v32-reveal-active','v33-reveal-enter','v34-reveal-enter','v35-chart-visible','v36-entered','v37-entered','visible');let key='research-item-'+i;if(el.matches('.dashboardMetrics article'))key='research-metric-'+$$('.dashboardMetrics article',p).indexOf(el);else if(el.matches('.dashChart'))key='research-chart-'+$$('.dashChart',p).indexOf(el);el.dataset.cerpV38Key=key;
 if(revealed.has(el)||seenKeys.has(key)){revealed.add(el);el.classList.remove('cerp-v38-pending');el.classList.add('cerp-v38-revealed');if(el.matches('.dashChart'))setFinalStatic(el);else if(el.matches('.dashboardMetrics article'))setFinalMetric(el);return}
 el.classList.add('cerp-v38-pending');if(el.matches('.dashChart'))restoreStatic(el);activeObserver.observe(el);
 });
}
function restoreStatic(card){const line=$('.dashLine',card),trace=$('.radarTrace',card),pie=$('.dashDonut',card);[line,trace].filter(Boolean).forEach(p=>{p.removeAttribute('pathLength');const len=pathLength(p);p.style.setProperty('stroke-dasharray',String(len),'important');p.style.setProperty('stroke-dashoffset',String(len),'important');p.style.setProperty('animation','none','important')});$$('.radarPoints circle',card).forEach(p=>p.style.setProperty('opacity','0','important'));$$('.dashBars i b',card).forEach(b=>{b.style.setProperty('transform','scaleX(1)','important');b.style.setProperty('width',b.dataset.width||b.style.getPropertyValue('--v')||'100%','important')});if(pie){const end=360*(Number(pie.dataset.share||78.1)/100);pie.style.setProperty('background',`conic-gradient(#1e658d 0deg ${end}deg,#d5b05a ${end}deg 360deg)`,'important')}}
function setFinalMetric(card){const i=$('.metricTrack i',card);if(i){const target=i.dataset.width||i.style.getPropertyValue('--metric-target')||i.style.width||'100%';i.style.setProperty('width',target,'important');i.style.setProperty('transition','none','important');i.style.setProperty('transform','scaleX(1)','important')}}
function setFinalStatic(card){const line=$('.dashLine',card),trace=$('.radarTrace',card),pie=$('.dashDonut',card);[line,trace].filter(Boolean).forEach(p=>{p.removeAttribute('pathLength');const len=pathLength(p);p.style.setProperty('stroke-dasharray',String(len),'important');p.style.setProperty('stroke-dashoffset','0','important');p.style.setProperty('animation','none','important')});$$('.radarPoints circle',card).forEach(p=>p.style.setProperty('opacity','1','important'));$$('.dashBars i b',card).forEach(b=>{b.style.setProperty('transform','scaleX(1)','important');b.style.setProperty('width',b.dataset.width||b.style.getPropertyValue('--v')||'100%','important')});if(pie){const end=360*(Number(pie.dataset.share||78.1)/100);pie.style.setProperty('background',`conic-gradient(#1e658d 0deg ${end}deg,#d5b05a ${end}deg 360deg)`,'important')}}
function replay(el){el.classList.remove('cerp-v38-pending','visible');el.classList.add('cerp-v38-revealed');revealed.add(el);if(el.dataset.cerpV38Key)seenKeys.add(el.dataset.cerpV38Key);if(el.matches('.dashChart')){played.delete(el);animateChart(el,true)}else if(el.matches('.dashboardMetrics article'))animateMetric(el)}
function bindDashboardObserver(){if(dashboardMO)dashboardMO.disconnect();const d=$('#researchDashboard');if(!d)return;dashboardMO=new MutationObserver(()=>{translatePage()});dashboardMO.observe(d,{subtree:true,childList:true});}
function start(){setup();bindDashboardObserver();if(pageMO)pageMO.disconnect();pageMO=new MutationObserver(records=>{let rebuild=false;for(const r of records){if(r.type==='attributes'&&r.attributeName==='lang')rebuild=true;if(r.type==='childList'&&Array.from(r.addedNodes).some(n=>n.nodeType===1&&(n.id==='researchDashboard'||n.querySelector?.('#researchDashboard'))))rebuild=true}translatePage();if(rebuild){clearTimeout(langTimer);langTimer=setTimeout(()=>{setup();bindDashboardObserver()},0)}});const p=$('#page-research');if(p){pageMO.observe(p,{subtree:true,childList:true});const pageClassMO=new MutationObserver(()=>{if(p.classList.contains('active')){clearTimeout(langTimer);langTimer=setTimeout(()=>{setup();bindDashboardObserver()},90)}});pageClassMO.observe(p,{attributes:true,attributeFilter:['class']});window.__cerpV38PageClassObserver=pageClassMO;}pageMO.observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
 window.addEventListener('click',e=>{const el=e.target?.closest?.('#researchDashboard .dashChart,#researchDashboard .dashboardMetrics article');if(!el)return;if(e.target.closest('a,button,input,select,textarea'))return;e.preventDefault();e.stopImmediatePropagation();replay(el)},true);
 window.addEventListener('keydown',e=>{if(e.key!=='Enter'&&e.key!==' ')return;const el=e.target?.closest?.('#researchDashboard .dashChart,#researchDashboard .dashboardMetrics article');if(!el)return;e.preventDefault();e.stopImmediatePropagation();replay(el)},true);
 const lb=$('#langBtn');if(lb)lb.addEventListener('click',()=>[0,80,250,600].forEach(ms=>setTimeout(()=>{translatePage();setup();bindDashboardObserver()},ms)));
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
})();

/* v42 scoped language repair: only the research dashboard/report block; leave animations untouched. */
(()=>{'use strict';
const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>Array.from(r.querySelectorAll(s));
const isEnglish=()=>/^en(?:-|$)/i.test(document.documentElement.lang||'zh-CN');
const put=(el,value)=>{if(el&&el.textContent.trim()!==value)el.textContent=value};
function applyChineseResearchCopy(){
 if(isEnglish())return;
 const d=$('#researchDashboard');
 if(d){
  put($('.dashboardHead .kicker',d),'官方统计 / 数据素养');
  put($('.dashboardHead h3',d),'中国教育：把官方统计转化为可检验的问题');
  put($('.dashboardHead p',d),'以官方统计为起点，提出有关教育规模、经费投入与机会公平的可检验问题。数据保留原始统计口径与单位。');
  const metricNames=['全国教育经费总投入','国家财政性教育经费','财政性教育经费占GDP','一般公共预算教育经费占比'];
  $$('.dashboardMetrics article',d).forEach((card,i)=>{put($('span',card),metricNames[i]||'');const unit=$('strong small',card);if(unit)put(unit,i<2?'亿元':'%')});
  const titles=['各级教育经费投入（亿元）','全国教育经费总投入（2013—2023，亿元）','财政性教育经费占教育经费总投入','证据维度'];
  const caps=['01 / 柱状图','02 / 趋势','03 / 构成','04 / 多维指标'];
  $$('.dashChart',d).forEach((card,i)=>{put($('.dashChartTop h4',card),titles[i]||'');put($('.dashChartTop span',card),caps[i]||'')});
  ['义务教育','高等教育','高中阶段','学前教育'].forEach((label,i)=>put($$('.dashBars>div>span',d)[i],label));
  const donut=$('.dashDonut',d);if(donut)put($('small',donut),'财政性经费');
  const rows=$$('.donutRow li',d);[['财政性经费','78.1%'],['其他来源','21.9%']].forEach((v,i)=>{const row=rows[i];if(!row)return;const b=$('b',row);if(b){let txt=Array.from(row.childNodes).find(n=>n.nodeType===Node.TEXT_NODE);const desired=v[0]+' ';if(!txt){txt=document.createTextNode(desired);row.insertBefore(txt,b)}else if(txt.textContent.trim()!==desired.trim())txt.textContent=desired;put(b,v[1])}});
  const radar=$('.dashRadar',d);if(radar){const labels=['规模','投入','增长','口径','来源','可及'];$$('text',radar).forEach((el,i)=>{if(labels[i])put(el,labels[i])});radar.setAttribute('aria-label','数据规模、投入、增长、分配、口径、可追溯性六维结构图')}
  put($('.dataChartNote',d),'全国教育经费总投入（亿元）：2013—2023年数据以官方统计公报为准；2021年57873.67，2022年61329.14，2023年64595.04。来源：全国教育经费执行情况统计公告。');
  put($('.radarNote',d),'六个维度用于组织证据，不代表主观评分或排名。');
  const foot=$('.dashboardFoot',d);if(foot&&!foot.textContent.includes('全国教育经费总投入'))foot.innerHTML='来源：<a href="https://www.moe.gov.cn/srcsite/A05/s3040/202412/t20241219_1167656.html" target="_blank" rel="noopener">教育部、国家统计局、财政部《2023年全国教育经费执行情况统计公告》</a>。2023年全国教育经费总投入64595.04亿元；国家财政性教育经费50439.47亿元；占GDP 4.00%；一般公共预算教育经费占一般公共预算支出14.86%。';
 }
 const report=$('.researchReport');if(report){put($('.sectionHead .kicker',report),'中国教育 / 数据简报');const stats=$$('.reportStats article',report);const names=['各级各类学校','学历教育在校生','专任教师','教育经费总投入'];const dates=['2025 年全国统计','2025 年全国统计','2025 年全国统计','2024 年 · 最新已发布经费数据'];stats.forEach((card,i)=>{put($('span',card),names[i]||'');put($('em',card),dates[i]||'')});
  // The four evidence cards are authored in Chinese; normalize their headings and units in case a legacy language pass overwrote them.
  const cards=$$('.reportGrid .reportCard',report);const headings=['教育经费投入','生均公共预算教育经费','教育机会与公平：应继续追问什么','研究结论与数据边界'];const subs=['2024 年全国教育经费总投入（亿元）','2024 年全国平均 · 元 / 人','官方统计提供总体基线，但不足以单独解释差异。','可验证的事实与待研究假设分开呈现。'];cards.forEach((card,i)=>{put($('.reportHead h3',card),headings[i]||'');put($('.reportHead p',card),subs[i]||'')});
 }
}
let queued=false;function schedule(){if(queued)return;queued=true;requestAnimationFrame(()=>{queued=false;applyChineseResearchCopy()})}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',schedule,{once:true});else schedule();
const langButton=$('#langBtn');if(langButton)langButton.addEventListener('click',()=>[0,60,180,400,800,1400].forEach(ms=>setTimeout(schedule,ms)));
const observer=new MutationObserver(records=>{if(isEnglish())return;let relevant=false;for(const r of records){if(r.type!=='childList')continue;const target=r.target;if(target.nodeType===1&&(target.closest?.('#researchDashboard,.researchReport')||target.matches?.('#researchDashboard,.researchReport')))relevant=true;for(const n of r.addedNodes||[])if(n.nodeType===1&&(n.matches?.('#researchDashboard,.researchReport')||n.querySelector?.('#researchDashboard,.researchReport')))relevant=true;}if(relevant)schedule()});
if(document.body)observer.observe(document.body,{childList:true,subtree:true});
})();


/* v44: final scoped language repair for per-student expenditure and research conclusions cards.
   Keep all chart/animation/navigation controllers untouched. */
(()=>{'use strict';
 const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>Array.from(r.querySelectorAll(s));
 const isEn=()=>/^en(?:-|$)/i.test(document.documentElement.lang||'zh-CN');
 const put=(el,value)=>{if(el&&el.textContent!==value)el.textContent=value};
 function repairResearchCopy(){
  const report=$('.researchReport'); if(!report)return;
  const cards=$$('.reportGrid .reportCard',report);
  const en=isEn();
  // Card 02: per-student public-budget education expenditure.
  const per=cards[1];
  if(per){
   const copy=en?{
    title:'Public-budget education expenditure per student', subtitle:'2024 national average · yuan / person',
    metric:'General public-budget education expenditure averaged across enrolled learners nationwide', unit:'yuan / person',
    growth:'Year-on-year growth', operating:'Operating expenditure per person', public:'Public operating funds per person',
    note:'A national average is not the actual resource level of every school; consider province, education stage, urban/rural context and student needs.',
    source:'Source: 2024 National Education Expenditure Statistical Bulletin, Ministry of Education, National Bureau of Statistics and Ministry of Finance ↗',
    comparison:'Original 2023 comparison bulletin ↗'
   }:{
    title:'生均公共预算教育经费', subtitle:'2024 年全国平均 · 元 / 人',
    metric:'全国按在校学生人数平均的一般公共预算教育经费', unit:'元 / 人',
    growth:'同比增长', operating:'生均教育事业费支出', public:'生均公用经费支出',
    note:'全国均值不等于每所学校的实际资源；需结合省份、学段、城乡和学生需求作进一步分析。',
    source:'来源：教育部、国家统计局、财政部《2024年全国教育经费执行情况统计公告》 ↗',
    comparison:'2023 年对比数据原始公告 ↗'
   };
   put($('.reportHead h3',per),copy.title);put($('.reportHead p',per),copy.subtitle);
   put($('.bigMetric>span',per),copy.metric);put($('.bigMetric small',per),copy.unit);
   const facts=$$('.miniFacts>div span',per);put(facts[0],copy.growth);put(facts[1],copy.operating);put(facts[2],copy.public);
   const values=$$('.miniFacts>div b',per);
   if(values[1])put(values[1],en?'15,442.67 yuan / person':'15,442.67 元 / 人');
   if(values[2])put(values[2],en?'4,250.77 yuan / person':'4,250.77 元 / 人');
   put($('.chartNote',per),copy.note);
   const links=$$('a',per);if(links[0])put(links[0],copy.source);if(links[1])put(links[1],copy.comparison);
   per.setAttribute('aria-label',en?'Public-budget education expenditure per student':'生均公共预算教育经费');
  }
  // Card 04: research findings and data boundaries. Replace all four list items, not just the heading.
  const findings=cards[3];
  if(findings){
   const copy=en?{
    title:'Research findings and data boundaries',subtitle:'Separate verifiable facts from hypotheses requiring further study.',
    list:[
     'In 2025, China had 440,700 schools of all types, 280.4 million learners in formal education and 18.7 million full-time teachers.',
     'In 2024, total national education expenditure was RMB 6.889924 trillion, up 6.66% year on year; state fiscal education funds were 4.02% of GDP. This is the latest published national expenditure series used here.',
     'These national aggregates cannot directly establish the causes of student stress, whether regional resource allocation is fair, or the causal effects of a reform.',
     'Next, obtain comparable provincial and education-stage data, define indicators in advance, disclose missing values, samples and methods, and avoid treating correlation as causation.'
    ],source:'Source: Ministry of Education, 2025 National Education Development Statistical Bulletin ↗'
   }:{
    title:'研究结论与数据边界',subtitle:'可验证的事实与待研究假设分开呈现。',
    list:[
     '2025 年全国有各级各类学校 44.07 万所、学历教育在校生 28040.43 万人、专任教师 1870.10 万人。',
     '2024 年全国教育经费总投入 68,899.24 亿元，同比增长 6.66%；国家财政性教育经费占 GDP 的比例为 4.02%。该年度经费公告是本页面采用的最新已发布全国经费口径。',
     '这些全国汇总数据不能直接证明学生压力的成因、地区资源分配是否公平或某项改革的因果效果。',
     '下一步应取得可比的省级/学段数据，预先定义指标，披露缺失值、样本与方法，并避免把相关性写成因果关系。'
    ],source:'来源：教育部《2025年全国教育事业发展统计公报》 ↗'
   };
   put($('.reportHead h3',findings),copy.title);put($('.reportHead p',findings),copy.subtitle);
   $$('.reportList li',findings).forEach((li,i)=>put(li,copy.list[i]||''));
   const link=$('a',findings);if(link)put(link,copy.source);
  }
 }
 let timers=[];
 function schedule(){timers.forEach(clearTimeout);timers=[];[0,80,300,650,1450].forEach(ms=>timers.push(setTimeout(repairResearchCopy,ms)));}
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',schedule,{once:true});else schedule();
 const lang=$('#langBtn');if(lang)lang.addEventListener('click',schedule);
})();


/* v45: single authoritative language repair for the two persistent report cards. */
(()=>{'use strict';
 const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>Array.from(r.querySelectorAll(s));
 const isEn=()=>{const b=$('#langBtn');if(b){const t=(b.textContent||'').trim();if(t==='中文 / EN')return true;if(t==='EN / 中文')return false;}return /^en(?:-|$)/i.test(document.documentElement.lang||'zh-CN');};
 const put=(el,v)=>{if(el&&el.textContent!==v)el.textContent=v};
 function repair(){
  const report=$('.researchReport');if(!report)return;
  const cards=$$('.reportGrid .reportCard',report),en=isEn();
  const per=cards[1];if(per){
   const c=en?{h:'Public-budget education expenditure per student',p:'2024 national average · yuan / person',metric:'General public-budget education expenditure averaged across enrolled learners nationwide',unit:'yuan / person',growth:'Year-on-year growth',operating:'Operating expenditure per student',public:'Public operating expenditure per student',note:'A national average is not the actual resource level of every school; further analysis should consider province, education stage, urban/rural context and student needs.',source:'Source: 2024 National Education Expenditure Statistical Bulletin, Ministry of Education, National Bureau of Statistics and Ministry of Finance ↗',compare:'Original 2023 comparison bulletin ↗'}:{h:'生均公共预算教育经费',p:'2024 年全国平均 · 元 / 人',metric:'全国按在校学生人数平均的一般公共预算教育经费',unit:'元 / 人',growth:'同比增长',operating:'生均教育事业费支出',public:'生均公用经费支出',note:'全国均值不等于每所学校的实际资源；需结合省份、学段、城乡和学生需求作进一步分析。',source:'来源：教育部、国家统计局、财政部《2024年全国教育经费执行情况统计公告》 ↗',compare:'2023 年对比数据原始公告 ↗'};
   put($('.reportHead h3',per),c.h);put($('.reportHead p',per),c.p);put($('.bigMetric>span',per),c.metric);put($('.bigMetric small',per),c.unit);
   const fs=$$('.miniFacts>div span',per);[c.growth,c.operating,c.public].forEach((v,i)=>put(fs[i],v));
   const vals=$$('.miniFacts>div b',per);if(vals[1])put(vals[1],en?'15,442.67 yuan / person':'15,442.67 元 / 人');if(vals[2])put(vals[2],en?'4,250.77 yuan / person':'4,250.77 元 / 人');
   put($('.chartNote',per),c.note);const links=$$('a',per);put(links[0],c.source);put(links[1],c.compare);
  }
  const findings=cards[3];if(findings){
   const c=en?{h:'Research findings and data boundaries',p:'Separate verifiable facts from hypotheses requiring further study.',list:['In 2025, China had 440,700 schools of all types, 280.4 million learners in formal education and 18.7 million full-time teachers.','In 2024, total national education expenditure was RMB 6.889924 trillion, up 6.66% year on year; state fiscal education funds were 4.02% of GDP. This is the latest published national expenditure series used here.','These national aggregates cannot directly establish the causes of student stress, whether regional resource allocation is fair, or the causal effects of a reform.','Next, obtain comparable provincial and education-stage data, define indicators in advance, disclose missing values, samples and methods, and avoid treating correlation as causation.'],source:'Source: Ministry of Education, 2025 National Education Development Statistical Bulletin ↗'}:{h:'研究结论与数据边界',p:'可验证的事实与待研究假设分开呈现。',list:['2025 年全国有各级各类学校 44.07 万所、学历教育在校生 28040.43 万人、专任教师 1870.10 万人。','2024 年全国教育经费总投入 68,899.24 亿元，同比增长 6.66%；国家财政性教育经费占 GDP 的比例为 4.02%。该年度经费公告是本页面采用的最新已发布全国经费口径。','这些全国汇总数据不能直接证明学生压力的成因、地区资源分配是否公平或某项改革的因果效果。','下一步应取得可比的省级/学段数据，预先定义指标，披露缺失值、样本与方法，并避免把相关性写成因果关系。'],source:'来源：教育部《2025年全国教育事业发展统计公报》 ↗'};
   put($('.reportHead h3',findings),c.h);put($('.reportHead p',findings),c.p);$$('.reportList li',findings).forEach((li,i)=>put(li,c.list[i]||''));put($('a',findings),c.source);
  }
 }
 let queued=false;function schedule(){if(queued)return;queued=true;requestAnimationFrame(()=>{queued=false;repair()})}
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',schedule,{once:true});else schedule();
 const langButton=$('#langBtn');if(langButton)langButton.addEventListener('click',()=>{schedule();[80,250,600,1200].forEach(ms=>setTimeout(schedule,ms));});
 const report=$('.researchReport');if(report){new MutationObserver(schedule).observe(report,{subtree:true,childList:true,characterData:true});}
})();


/* v48: site-wide English translation audit for previously unmarked static copy.
   Original Chinese text is retained in data-cerp-audit-zh so switching back is reliable. */
(()=>{'use strict';
 const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>Array.from(r.querySelectorAll(s));
 const copy={
 'CERP · 教育革新委员会':'CERP · Committee of Educational Reform Party',
 '菜单':'Menu',
 '把问题变成改变的起点。':'Turn questions into the starting point for change.',
 '一条可核验的证据、一份清晰的建议、一次认真倾听，都能推动讨论向前。改革不靠盲从，也不靠空喊口号——靠公开、勇气、协作与可复核的行动。':'One verifiable piece of evidence, one clear proposal and one act of careful listening can move a discussion forward. Reform depends neither on blind obedience nor empty slogans, but on openness, courage, collaboration and actions that can be reviewed.',
 '加入公开讨论':'Join the public discussion',
 '从证据开始':'Start with evidence',
 '本网站为倡议与研究页面，不代表政府机关、学校或已登记组织。正式开展活动前，应明确组织法律身份、治理规则、财务规范与参与者权利。':'This website is an advocacy and research project. It does not represent a government body, school or registered organisation. Before any formal activity begins, the initiative must clarify its legal status, governance rules, financial standards and participants’ rights.',
 '教育系统应该交付什么公共价值？':'What public value should an education system deliver?',
 '以学生实际发展为中心，同时检验公平、健康、专业能力与公共责任。以下是可供讨论的评估框架，不是对任何学校的既定评分。':'Put learners’ actual development at the centre while examining equity, wellbeing, professional capability and public responsibility. This is a framework for discussion, not a predetermined rating of any school.',
 '真实学习':'Meaningful learning',
 '理解概念、迁移应用、表达论证、解决陌生问题，并能在反馈后持续进步。':'Understand concepts, apply knowledge in new contexts, explain reasoning, solve unfamiliar problems and continue improving after feedback.',
 '观察：作品集 · 解释任务 · 延迟测评':'Evidence: portfolios · explanation tasks · delayed assessments',
 '身心健康':'Physical and mental wellbeing',
 '学习安排应为睡眠、运动、社会关系与及时支持保留必要空间。':'Learning schedules should leave sufficient room for sleep, physical activity, social relationships and timely support.',
 '观察：匿名调查 · 时间使用 · 支持可及性':'Evidence: anonymous surveys · time use · access to support',
 '机会公平':'Equity of opportunity',
 '不仅比较平均结果，也检查不同地区、家庭背景和学习需求群体的机会差距。':'Compare not only average outcomes but also opportunity gaps across regions, family backgrounds and learners with different needs.',
 '观察：参与率 · 资源分布 · 差距变化':'Evidence: participation rates · resource distribution · changes in gaps',
 '专业与信任':'Professional practice and trust',
 '让教师获得专业支持，让规则有明确依据，让投诉、复核与纠错真正可用。':'Give teachers professional support, ground rules in clear reasons, and make complaints, reviews and corrections genuinely accessible.',
 '观察：工作量 · 响应时间 · 复核记录':'Evidence: workload · response times · review records',
 '组织原则不应只停留在宣传页面。正式运行前，应通过公开程序形成章程，明确成员参与、治理权限、财务公开、申诉、退出和争议解决机制。':'Organisational principles must go beyond a promotional webpage. Before formal operations begin, a charter should be developed through an open process, defining member participation, governance powers, financial disclosure, appeals, withdrawal and dispute resolution.',
 '第一条｜宗旨与边界':'Article 1 | Purpose and boundaries',
 '以公开研究、教育议题讨论与可评估的改进建议为主要工作；坚持自愿参与、依法开展、尊重人格与学术诚信。不得冒用政府、学校或其他机构名义，不以网站内容暗示官方授权。':'The initiative focuses on public research, discussion of education issues and assessable improvement proposals. Participation must be voluntary and lawful, with respect for dignity and academic integrity. It must not impersonate a government, school or other institution or imply official authorisation through website content.',
 '第二条｜治理与决策':'Article 2 | Governance and decisions',
 '设立公开的议题提案、讨论、表决与复核流程。重大事项应提前公布议程、适用规则、表决门槛及利益冲突情况，并形成可查询的会议纪要。紧急决定须注明理由、有效期限并接受事后复核。':'Establish public procedures for proposals, discussion, voting and review. For major matters, publish the agenda, applicable rules, voting threshold and conflicts of interest in advance, and keep accessible minutes. Emergency decisions must state their reasons and duration and undergo retrospective review.',
 '第三条｜财务与记录':'Article 3 | Finance and records',
 '如发生经费收支，应建立凭证、双人复核、预算审批及定期公开机制；禁止私人账户混同组织资金。依法处理个人信息，设定资料访问权限和保存期限。':'If funds are received or spent, maintain supporting records, dual review, budget approval and periodic disclosure. Do not mix organisational funds with personal accounts. Handle personal information lawfully and define access permissions and retention periods.',
 '第四条｜修订与解散':'Article 4 | Amendments and dissolution',
 '章程修订须提前通知成员、提供对照文本、留出讨论期并按公开规则表决。停止活动时应说明原因、处理未结事项与资产，并依法履行必要程序。':'Charter amendments require advance notice to members, a comparison of versions, time for discussion and a vote under published rules. If activities cease, explain why, resolve outstanding matters, account for assets and follow applicable legal procedures.',
 '成员权利':'Member rights',
 '成员义务':'Member responsibilities',
 '平等提出议题、表达不同意见并参与规则允许的讨论和表决。':'Propose issues on equal terms, express differing views and take part in discussions and votes permitted by the rules.',
 '查阅已公开的章程、决策摘要、财务报告与利益冲突处理结果。':'Access published charters, decision summaries, financial reports and conflict-of-interest outcomes.',
 '在涉及本人权益的决定中获得说明，并申请回避、复核或申诉。':'Receive explanations of decisions affecting one’s rights and request recusal, review or appeal.',
 '自愿退出；退出不得成为骚扰、报复或不当限制个人发展的理由。':'Leave voluntarily; withdrawal must not lead to harassment, retaliation or improper restrictions on personal development.',
 '遵守已公开的规则，尊重他人尊严、隐私与不同意见。':'Follow published rules and respect others’ dignity, privacy and differing opinions.',
 '标注研究来源，区分事实、解释、推测与倡议；发现错误及时更正。':'Cite research sources, distinguish facts from interpretation, speculation and advocacy, and correct errors promptly.',
 '披露与议题有关的经济、职业、亲属或其他重大利益关系。':'Disclose relevant financial, professional, family or other material interests.',
 '不得伪造数据、泄露受保护信息、骚扰成员或借组织名义谋取不当利益。':'Do not fabricate data, disclose protected information, harass members or use the organisation’s name for improper gain.',
 '主动申报：':'Proactive disclosure:',
 '议题负责人、评审者和决策参与者在讨论前申报相关资助、雇佣、投资、亲属关系及其他可能影响独立判断的关系。':'Before discussion, issue leads, reviewers and decision-makers must disclose relevant funding, employment, investments, family relationships and other ties that may affect independent judgement.',
 '分级处理：':'Proportionate handling:',
 '由无利益冲突的人员判断是否需要公开说明、限制资料权限、增加独立评审或完全回避。':'People without relevant conflicts determine whether disclosure, restricted access, additional independent review or full recusal is needed.',
 '留痕可查：':'Document and retain records:',
 '记录申报日期、处理理由、回避范围与替代负责人；公开摘要时保护合理隐私。':'Record the disclosure date, reasons for handling, scope of recusal and replacement lead; protect legitimate privacy in public summaries.',
 '禁止报复：':'No retaliation:',
 '善意披露、提出质疑或举报利益冲突者，不应受到打压。':'No one should be penalised for good-faith disclosure, questioning or reporting of a conflict of interest.',
 '定期复核：':'Periodic review:',
 '重大项目结束后检查规则是否有效，发现遗漏时及时补充披露并评估既有决定是否需要重审。':'After major projects, assess whether the rules worked. Correct omissions promptly and determine whether previous decisions need to be reconsidered.',
 '受理流程':'Intake process',
 '通过明确的公开渠道提交事项、相关事实与希望采取的措施；允许在适当情形下先行咨询。':'Submit the issue, relevant facts and requested action through a clearly identified public channel; preliminary enquiries may be allowed where appropriate.',
 '在拟议的 7 个工作日内确认收到，并说明受理范围、保密边界与预计处理步骤。':'Acknowledge receipt within a proposed seven working days and explain the scope of review, confidentiality limits and expected steps.',
 '由未参与原决定且不存在利益冲突的人员调查；涉及安全风险时优先采取临时保护措施。':'Investigation should be handled by people uninvolved in the original decision and free of relevant conflicts. Take interim protective measures first when safety risks arise.',
 '原则上在 30 个工作日内给出书面结果；复杂事项说明延期原因与新期限。以上为建议服务标准，正式采纳前应审议。':'As a proposed service standard, provide a written outcome within 30 working days. For complex cases, explain the reason for delay and the revised deadline. This standard requires review before formal adoption.',
 '当事人可在收到结果后 15 个工作日内申请一次独立复核；复核人员不得是原处理者。':'A party may request one independent review within 15 working days of receiving the outcome. The reviewer must not be the original handler.',
 '监督与救济':'Oversight and remedies',
 '年度公布匿名化的申诉数量、类型、处理时长、纠正措施及未结事项；禁止报复。涉及违法、紧急人身安全或法定权利的事项，不以内部程序取代依法求助或外部救济。':'Publish annual anonymised figures on appeals, categories, handling times, corrective actions and unresolved matters; prohibit retaliation. Internal procedures do not replace lawful assistance or external remedies for suspected illegality, urgent safety risks or statutory rights.',
 '组织如何避免重蹈自己批评的问题？':'How can the initiative avoid repeating the problems it criticises?',
 '倡议组织也需要权力边界。以下治理模块可逐项展开，作为未来组织制度设计的核对清单。':'Advocacy initiatives also need limits on power. The following governance modules form a checklist for designing future organisational systems.',
 '六条改革工作线，覆盖课堂内外':'Six reform workstreams, inside and beyond the classroom',
 '教育不是单一课堂或单一考试。以下工作线可以分别研究，也需要关注它们之间的相互影响。':'Education is not just a classroom or an exam. These workstreams can be studied separately, while also examining how they interact.',
 '课程与学习设计':'Curriculum and learning design',
 '基础知识、跨学科理解、项目实践、阅读能力、艺术与体育的合理组合。':'A balanced combination of foundational knowledge, interdisciplinary understanding, project work, reading, arts and physical education.',
 '评价与升学':'Assessment and progression',
 '改进形成性反馈，审视单次高风险考试的影响，探索多元且可核验的评价。':'Improve formative feedback, examine the effects of single high-stakes exams and explore diverse, verifiable forms of assessment.',
 '教师专业支持':'Professional support for teachers',
 '关注教学准备时间、持续培训、课堂自主权、合理工作量与专业协作。':'Consider lesson-preparation time, continuing development, classroom autonomy, reasonable workloads and professional collaboration.',
 '学生身心健康':'Student wellbeing',
 '把睡眠、运动、归属感、校园安全与及时支持纳入学校改进讨论。':'Include sleep, physical activity, belonging, campus safety and timely support in school-improvement discussions.',
 '公平与资源配置':'Equity and resource allocation',
 '考察城乡、地区、家庭经济条件、残障与不同学习需求下的真实机会。':'Examine real opportunities across urban and rural settings, regions, household finances, disability and varied learning needs.',
 '数字技术与人工智能':'Digital technology and artificial intelligence',
 '评估技术对学习的增益，同时管理隐私、偏差、依赖、版权和数字鸿沟。':'Evaluate technology’s learning benefits while managing privacy, bias, dependence, copyright and the digital divide.',
 '进一步展开':'Expand details',
 '政策方案比较器':'Policy option comparator',
 '选择一个常见的改革问题，查看制定方案时应同步考虑的收益、成本与风险。此工具用于组织思考，不自动替代研究或专业判断。':'Choose a common reform question to review the benefits, costs and risks that should be considered together. This tool structures thinking; it does not replace research or professional judgement.',
 '选择讨论议题':'Choose a topic for discussion',
 '考试与评价':'Exams and assessment',
 '作业与学习负担':'Homework and learning workload',
 '人工智能进校园':'AI in schools',
 '学生心理支持':'Student mental-health support',
 '职业教育与升学路径':'Vocational education and progression pathways',
 '潜在收益':'Potential benefits',
 '增加不同形式的学习证据，减少单次考试对长期机会的支配。':'Use diverse evidence of learning and reduce the influence of a single exam on long-term opportunities.',
 '实施成本':'Implementation costs',
 '评分培训、评估一致性、教师时间与申诉复核都需要资源。':'Scoring training, assessment consistency, teacher time and appeals all require resources.',
 '主要风险':'Main risks',
 '评价变得不透明，或让家庭资源影响项目、作品和课外经历。':'Assessment may become opaque or allow family resources to influence projects, portfolios and extracurricular experience.',
 '建议保障':'Recommended safeguards',
 '公开标准、盲评抽查、合理便利、申诉渠道和独立偏差审查。':'Publish criteria; use sample blind reviews, reasonable accommodations, appeal routes and independent bias checks.',
 '提示：比较时应明确目标群体、实施期限、预算来源、基线与停止条件。':'Note: specify the target population, implementation period, budget source, baseline and stopping conditions when comparing options.',
 '每个阶段都应回答的八个问题':'Eight questions every stage should answer',
 '在项目进入下一阶段前，逐项记录答案、负责人、资料来源和未解决事项。':'Before moving a project to the next stage, record each answer, the responsible person, sources and unresolved issues.',
 '问题定义是否清晰，且没有把假设当成事实？':'Is the problem clearly defined without presenting assumptions as facts?',
 '目标群体和潜在受影响者是否都被考虑？':'Have both the target group and potentially affected people been considered?',
 '数据来源、年份、分母与限制是否明确？':'Are the data source, year, denominator and limitations clear?',
 '是否比较了维持现状和替代方案？':'Have maintaining the status quo and alternative options been compared?',
 '是否估算资源、时间与执行成本？':'Have resource, time and implementation costs been estimated?',
 '是否设置隐私、安全和公平保障？':'Are privacy, safety and equity safeguards in place?',
 '是否预先定义成功、失败和停止标准？':'Have success, failure and stopping criteria been defined in advance?',
 '是否安排公开反馈、独立复核与纠错？':'Are public feedback, independent review and correction arrangements planned?',
 '勾选状态仅保存在当前页面，不会提交或上传。':'Checklist selections remain on this page and are not submitted or uploaded.',
 '把教育改革拆解为可以讨论、试点与复核的系统':'Break education reform into a system that can be discussed, piloted and reviewed',
 '借鉴公共机构常用的政策周期、公开咨询、影响评估和问责机制。这里提供的是可讨论的框架，不冒充已获授权的官方政策。':'This framework draws on policy cycles, public consultation, impact assessment and accountability mechanisms used by public institutions. It is offered for discussion and does not claim official authorisation.',
 '01 识别问题':'01 Identify the problem',
 '界定范围、群体与基线':'Define scope, groups and baseline',
 '02 汇集证据':'02 Gather evidence',
 '统计、研究与公众经验':'Statistics, research and public experience',
 '03 比较方案':'03 Compare options',
 '成本、收益与风险':'Costs, benefits and risks',
 '04 试点评估':'04 Pilot and evaluate',
 '指标、反馈与独立复核':'Indicators, feedback and independent review',
 '政策影响评估':'Policy impact assessment',
 '新措施实施前，先说明希望解决什么问题、可能受益与受损的人群、财政和行政成本，以及意外后果。':'Before a new measure is implemented, explain the problem, who may benefit or be harmed, fiscal and administrative costs, and possible unintended consequences.',
 '定义可检验的目标和基线':'Define testable objectives and a baseline',
 '评估公平性与群体差异':'Assess equity and group differences',
 '预先设定暂停或退出条件':'Set suspension or exit conditions in advance',
 '公开咨询与回应':'Public consultation and response',
 '不只收集意见，还要解释哪些建议被采纳、哪些未采纳，以及理由和证据是什么。':'Do more than collect feedback: explain which suggestions were adopted, which were not, and the reasons and evidence.',
 '公布议题、期限和参与规则':'Publish topics, deadlines and participation rules',
 '提供多种无障碍参与渠道':'Offer multiple accessible ways to participate',
 '发布去标识化回应摘要':'Publish de-identified response summaries',
 '试点与复盘':'Pilots and retrospective review',
 '在可控范围内先测试，避免未经验证就大规模推行；试点失败也应形成公开学习记录。':'Test within a controlled scope before scaling up. Failed pilots should also produce public learning records.',
 '明确比较组与观察周期':'Define comparison groups and observation periods',
 '同步监测成本和副作用':'Monitor costs and side effects together',
 '按结果扩大、调整或停止':'Scale, revise or stop based on results',
 '研究议题登记册：让每项建议都有下一步':'Research issue register: give every proposal a next step',
 '这份公开议题清单把建议转化为可研究的工作包，并标注下一步应形成的证据与评估方式。状态表示研究准备阶段，不代表试点已经启动或获得任何机构批准。':'This public issue register turns proposals into research work packages and identifies the evidence and evaluation needed next. Status labels indicate preparation only; they do not mean a pilot has begun or received institutional approval.',
 '工作包':'Work package','首要问题':'Core question','建议交付物':'Suggested deliverable','评估方式':'Evaluation method','状态':'Status',
 '学习负担与时间使用':'Learning workload and time use','时间投入是否转化为有效学习':'Does time spent translate into effective learning?','匿名时间日记、文献综述':'Anonymous time-use diaries and literature review','学习结果与健康并行观察':'Track learning outcomes and wellbeing together',
 '教师工作与支持':'Teacher work and support','教学时间被哪些任务挤占':'Which tasks displace teaching time?','任务分类与工作量调查':'Task classification and workload survey','样本覆盖、时间成本、反馈':'Sample coverage, time cost and feedback',
 '评价方式比较':'Comparison of assessment methods','不同评价如何影响学习策略':'How do different assessments affect learning strategies?','评价工具与案例比较':'Compare assessment tools and cases','效度、公平性、可操作性':'Validity, equity and practicality',
 '校园心理支持':'School-based mental-health support','求助渠道是否安全可及':'Are help-seeking channels safe and accessible?','服务流程图与隐私清单':'Service flowchart and privacy checklist','响应时间、可及性、匿名反馈':'Response time, accessibility and anonymous feedback',
 '数字工具采购':'Digital tool procurement','技术是否产生可验证的增益':'Does the technology produce verifiable benefits?','成本收益与风险评估模板':'Cost-benefit and risk-assessment template','学习效果、数据保护、总成本':'Learning outcomes, data protection and total cost',
 '教育资源可及性':'Access to educational resources','资源差异如何影响参与机会':'How do resource differences affect participation?','公开数据目录与差距分析':'Public data catalogue and gap analysis','口径一致、分组结果、局限说明':'Consistent definitions, subgroup results and limitations',
 '议题准备':'In preparation',
 '项目治理底线：不收集不必要的个人信息；不公开可识别未成年人的经历；不将未经核验的个案写成普遍事实；不把建议台账描述为官方承诺。':'Project governance baseline: do not collect unnecessary personal data; do not publish identifiable accounts involving minors; do not generalise from unverified cases; and do not present a proposal register as an official commitment.',
 '从建议到行动：每一步都留下可复核的记录':'From proposals to action: keep a reviewable record at every step',
 '成熟的公共项目通常需要清晰的责任分工、时间表、公开反馈和风险管理。下列流程可以作为倡议项目的工作模板。':'Mature public-interest projects usually require clear responsibilities, timelines, public feedback and risk management. The following process can serve as a working template for an advocacy initiative.',
 '问题定义':'Problem definition','描述具体问题、受影响人群、现有证据与尚未知晓的部分。':'Describe the specific problem, affected groups, available evidence and what remains unknown.','交付物：问题说明书':'Deliverable: problem brief',
 '证据审查':'Evidence review','核对法律政策、官方统计、研究质量与不同解释。':'Check laws and policies, official statistics, research quality and alternative explanations.','交付物：来源表与证据分级':'Deliverable: source register and evidence grading',
 '方案设计':'Option design','比较至少两个可行选项，估算资源、执行难点和潜在副作用。':'Compare at least two feasible options and estimate resources, implementation barriers and potential side effects.','交付物：方案比较表':'Deliverable: option comparison table',
 '小范围试点':'Small-scale pilot','在自愿、合法、风险可控的范围内测试，并预设退出条件。':'Test voluntarily and lawfully within a controlled risk level, with exit conditions defined in advance.','交付物：试点方案与保护措施':'Deliverable: pilot plan and safeguards',
 '独立评估':'Independent evaluation','公布结果、成本、样本局限和未达成目标的部分。':'Publish outcomes, costs, sample limitations and goals that were not achieved.','交付物：评估报告与修订记录':'Deliverable: evaluation report and revision log',
 '万所':'k schools','亿人':'m people','万人':'m people','万亿元':'RMB trillion',
 '教育经费投入':'Education expenditure','2024 年全国教育经费总投入（亿元）':'National education expenditure, 2024 (RMB billion)','经费总投入':'Total education expenditure','国家财政性':'State fiscal funds','单位：亿元。国家财政性教育经费为总投入的组成部分，不可与总投入相加。':'Unit: RMB billion. State fiscal education funds are included in total expenditure and must not be added to the total.',
 '来源：教育部、国家统计局、财政部《2024年全国教育经费执行情况统计公告》 ↗':'Source: 2024 National Education Expenditure Statistical Bulletin, Ministry of Education, National Bureau of Statistics and Ministry of Finance ↗','2023 年对比数据原始公告 ↗':'Original 2023 comparison bulletin ↗',
 '生均公共预算教育经费':'Public-budget education expenditure per student','2024 年全国平均 · 元 / 人':'2024 national average · yuan per person','全国按在校学生人数平均的一般公共预算教育经费':'General public-budget education expenditure averaged across enrolled learners nationwide','同比增长':'Year-on-year growth','生均教育事业费支出':'Operating expenditure per student','生均公用经费支出':'Public operating expenditure per student','15,442.67 元 / 人':'15,442.67 yuan / person','4,250.77 元 / 人':'4,250.77 yuan / person',
 '教育机会与公平：应继续追问什么':'Educational opportunity and equity: what should we ask next?','官方统计提供总体基线，但不足以单独解释差异。':'Official statistics provide an overall baseline but cannot explain differences on their own.','地区差异':'Regional differences','对比省际生均投入、教师配置、学校可及性与家庭负担。':'Compare per-student spending, teacher allocation, school access and family costs across provinces.','城乡差异':'Urban-rural differences','区分学校资源、通勤距离、数字设备与课程可选范围。':'Distinguish school resources, travel distance, digital devices and available course choices.','学生体验':'Student experience','用匿名、具代表性的调查检验睡眠、压力、归属感与学习投入。':'Use anonymous, representative surveys to examine sleep, stress, belonging and engagement in learning.','结果指标':'Outcome indicators','同时观察学习进步、身心健康、机会公平与长期发展，不以单一考试指标代替全部结果。':'Track learning progress, wellbeing, equity of opportunity and long-term development; do not use a single exam metric as a proxy for all outcomes.',
 '研究结论与数据边界':'Research findings and data boundaries','可验证的事实与待研究假设分开呈现。':'Separate verifiable facts from hypotheses requiring further study.','这些全国汇总数据不能直接证明学生压力的成因、地区资源分配是否公平或某项改革的因果效果。':'These national aggregates cannot directly establish the causes of student stress, whether regional resource allocation is fair or the causal effects of a reform.','下一步应取得可比的省级/学段数据，预先定义指标，披露缺失值、样本与方法，并避免把相关性写成因果关系。':'Next, obtain comparable provincial and education-stage data, define indicators in advance, disclose missing values, samples and methods, and avoid treating correlation as causation.',
 '研究声明：本页为公开统计的描述性整理，不是因果评估，也不代表对所有地区和学校的概括性判断。':'Research note: This page descriptively organises public statistics. It is not a causal evaluation and should not be taken as a generalised judgement about all regions or schools.',
 '官方资料与法规入口':'Official sources and legal references','下列资料用于建立研究起点。法规可能修订，请核对现行版本、适用范围和地方执行情况。':'The following materials provide a starting point for research. Laws and regulations may be amended; check the current version, scope of application and local implementation.',
 '提交研究议题建议':'Suggest a research topic','议题':'Topic','受影响群体':'Affected group','学生':'Students','教师':'Teachers','家长与家庭':'Parents and families','学校管理者':'School administrators','职业教育与大学生':'Vocational and university students','社会公众':'General public','希望核查什么问题或证据？':'What question or evidence should be examined?','生成建议文本':'Prepare proposal text','重置':'Reset','建议草稿':'Draft proposal','复制草稿':'Copy draft','信息不会发送至服务器。请勿填写个人或可识别身份的细节。':'No information is sent to a server. Do not include personal or identifying details.',
 '从“好不好”转向“如何衡量”':'From “Is it good?” to “How do we measure it?”','选择一个评估维度，查看应优先收集的证据、可用的官方数据入口与需要避免的误判。':'Choose an evaluation dimension to see which evidence to prioritise, relevant official data sources and misinterpretations to avoid.','学习与成长':'Learning and growth','关注学生是否真正理解、迁移和持续学习，而不只看一次考试分数。':'Assess whether students understand, transfer and continue learning—not just their score on one exam.','学习增值':'Learning gains','在相同口径下追踪学习进步、知识迁移和反馈后的改进，而非只比较一次考试分数。':'Track progress, transfer and improvement after feedback using consistent definitions, rather than comparing one exam score.','数据来源':'Data sources','优先使用有公开方法的学业评估、课程任务与长期跟踪；说明样本、时间、测量工具与缺失值。':'Prefer assessments with published methods, curriculum tasks and longitudinal tracking; disclose samples, timing, instruments and missing values.','需要避免的误判':'Misinterpretations to avoid','不能将全国投入数据直接解释为课堂效果，也不能把相关性当作某项政策的因果结果。':'National spending figures do not directly establish classroom effects, and correlation does not prove that a policy caused an outcome.',
 '数据质量检查':'Data quality checks','样本是否代表目标群体？缺失数据是否集中于某些地区或学生？指标定义是否跨年份一致？':'Does the sample represent the target population? Are missing data concentrated in certain regions or groups? Are metric definitions consistent across years?','反指标异化':'Preventing metric gaming','指标一旦与奖惩绑定，可能诱发应试、选择性报告或排除难以服务的人群。必须配套审计与反向指标。':'When rewards or penalties depend on metrics, they can encourage teaching to the test, selective reporting or exclusion of harder-to-serve groups. Add audits and counter-metrics.','结果公开方式':'How results are published','优先发布分布、趋势和不确定性；避免用未经调整的学校排行榜代替解释，保护小样本群体隐私。':'Prioritise distributions, trends and uncertainty. Do not use unadjusted school rankings as a substitute for explanation, and protect the privacy of small groups.',
 '官方数据基线：从投入事实开始，向公平与学习追问':'Official data baseline: start with spending facts, then ask about equity and learning','本面板展示已有权威来源支持的全国投入指标，并将投入变化与学习、公平和学生体验等不同维度分开分析。':'This panel presents national spending indicators supported by authoritative sources and analyses spending trends separately from learning, equity and student experience.','可以直接核验的教育基线':'Verifiable education baseline','以下均为官方发布的全国统计值，用于描述教育系统的投入与规模。':'These are officially published national statistics describing the scale and investment of the education system.','全国教育经费总投入':'Total national education expenditure','亿元':'RMB billion','2024 年 · 同比 +6.66%':'2024 · up 6.66% year on year','国家财政性教育经费':'State fiscal education funds','2024 年 · 同比 +7.38%':'2024 · up 7.38% year on year','国家财政性教育经费 / GDP':'State fiscal education funds / GDP','2024 年 · 全国口径':'2024 · national measure','生均一般公共预算教育经费':'General public-budget education expenditure per student','元':'yuan','16,282.98 元 / 人':'16,282.98 yuan / person','2024 年 · 同比 +1.23%':'2024 · up 1.23% year on year','这些数值描述投入规模与变化，不直接代表课堂质量、机会公平或学生身心健康。评估改革时，应与学习成果、群体差异和学生体验等数据交叉分析。':'These figures describe the scale and change of investment; they do not directly measure classroom quality, equity of opportunity or student wellbeing. Evaluate reforms alongside learning outcomes, group differences and student experience.','查看教育部、国家统计局、财政部原始公告 ↗':'View the original announcement from the Ministry of Education, National Bureau of Statistics and Ministry of Finance ↗',
 '不能只看平均数':'Do not rely on averages alone','平均值可能掩盖极端困难或群体差距。应同时观察分布、缺失数据、地区差异与长期变化。':'Averages can conceal severe hardship or group disparities. Also examine distributions, missing data, regional differences and long-term trends.','防止指标被操纵':'Prevent metric manipulation','当指标与奖惩绑定，可能出现选择性报告、排除困难学生或追求形式合规。应设置审计和反向指标。':'When metrics are tied to rewards or penalties, organisations may selectively report, exclude students who need more support or pursue box-ticking compliance. Use audits and counter-metrics.','公开不确定性':'Disclose uncertainty','区分相关与因果，披露样本、定义、误差与局限。没有足够证据时，明确写出“尚不能判断”。':'Distinguish correlation from causation and disclose samples, definitions, error and limitations. If evidence is insufficient, state clearly: “The evidence is not yet conclusive.”',
 '教育改革研究词汇表':'Education reform research glossary','用一致的概念讨论复杂议题。点击术语查看简明解释与使用时需要注意的边界。':'Use consistent concepts to discuss complex issues. Select a term for a brief explanation and its limitations.','形成性评价':'Formative assessment','学习过程中持续收集理解证据，并把反馈用于调整教学与学习策略。它不是简单增加测验次数。':'Collect evidence of understanding throughout learning and use feedback to adjust teaching and learning strategies. This is not simply adding more tests.','学习迁移':'Transfer of learning','把所学知识和方法用于新情境。迁移表现需要结合任务难度、背景知识和观察时间判断。':'Apply knowledge and methods in new situations. Judge transfer in light of task difficulty, prior knowledge and observation period.','合理便利':'Reasonable accommodation','为有特定需求的人提供适当调整，减少不必要的参与障碍；具体安排需结合适用规则与实际情境。':'Make appropriate adjustments for people with specific needs to reduce unnecessary barriers to participation, consistent with applicable rules and circumstances.','政策试点':'Policy pilot','在有限范围内测试方案可行性与风险。试点成功不自动证明大规模推广有效。':'Test feasibility and risk on a limited scale. A successful pilot does not automatically prove that large-scale rollout will work.','因果推断':'Causal inference','尝试识别某项措施是否导致结果变化，需要比较设计、合理假设和对混杂因素的处理。':'Assess whether an intervention caused a change in outcomes using a comparison design, justified assumptions and methods to address confounding factors.','隐私最小化':'Data minimisation','只收集实现明确目的所必需的数据，并限定访问权限、保存期限和二次使用方式。':'Collect only data necessary for a defined purpose, and limit access, retention and secondary use.','利益冲突':'Conflict of interest','个人或组织的其他利益可能影响判断时，需要披露、评估并在必要时回避。':'Disclose and assess interests that may affect judgement, and recuse where necessary.','可及性':'Accessibility','不同能力、语言、设备和经济条件的人能否实际使用信息、服务与参与渠道。':'Whether people with different abilities, languages, devices and financial circumstances can actually use information, services and participation channels.',
 '参与方式与基本边界':'Ways to participate and basic boundaries','参与应当自愿、知情、尊重隐私，并允许不同意见。':'Participation should be voluntary and informed, respect privacy and allow disagreement.','资料核验':'Source verification','帮助核对法律、政策、统计口径和研究结论，标记来源与不确定性。':'Help verify laws, policies, statistical definitions and research findings, noting sources and uncertainty.','议题研究':'Issue research','把个人经验整理为不含身份信息的问题陈述，提出可验证的调查问题。':'Turn personal experiences into non-identifying problem statements and propose testable research questions.','方案评估':'Option evaluation','比较改革方案的成本、可行性、风险、受益群体与可能的副作用。':'Compare the costs, feasibility, risks, beneficiaries and potential side effects of reform options.','不要上传身份证、学号、住址、未成年人可识别照片或他人私密信息。不要公开未经核实的指控，也不要以群体名义擅自作出未经授权的承诺。':'Do not upload identity documents, student IDs, addresses, identifiable images of minors or other people’s private information. Do not publish unverified allegations or make unauthorised promises on behalf of a group.'
 };

 Object.assign(copy,{
 '别只接受“本来就这样”。':'Do not accept “that is just how things are.”',
 '写明哪些事项由成员讨论、哪些由执行人员处理、哪些需要更高门槛表决。紧急授权应设期限并在事后复核。':'Specify which matters are discussed by members, which are handled by staff and which require a higher voting threshold. Emergency powers must be time-limited and reviewed afterwards.',
 '公开议程、会议纪要与决议依据':'Publish agendas, minutes and the basis for decisions','重要决定记录反对意见与利益冲突':'Record dissenting views and conflicts of interest for major decisions','授权可撤回，不允许无限期空白授权':'Delegations must be revocable; open-ended authorisation is not allowed',
 '如涉及经费，应说明资金来源、支出用途、审批流程和利益关联。未经核实的筹款声明不得包装成正式财务报告。':'If funds are involved, disclose their sources, uses, approval process and related interests. Unverified fundraising claims must not be presented as formal financial reports.','预算与实际支出定期对照':'Compare budgets with actual spending regularly','双人审批和必要的独立核查':'Require dual approval and independent checks where necessary','披露关联交易及回避情况':'Disclose related-party transactions and recusals',
 '投诉流程要保密、可理解、可使用，并防止报复。被投诉者也应有知情、回应和公正复核的机会。':'Complaint procedures must be confidential, understandable and accessible, with protection against retaliation. People complained about must also have an opportunity to be informed, respond and receive fair review.','明确受理、调查、决定和复核角色':'Define intake, investigation, decision and review roles','设置紧急安全风险的处理路径':'Establish a pathway for urgent safety risks','允许自愿退出并妥善处理个人数据':'Allow voluntary withdrawal and handle personal data appropriately',
 '错误不可避免，关键是能否被发现、承认和纠正。对外发布内容应有来源核查和版本记录。':'Errors are inevitable; what matters is whether they can be found, acknowledged and corrected. Public materials should have source checks and version records.','保留带日期的更正日志':'Maintain a dated correction log','公开反馈入口与处理时限':'Publish feedback channels and response timelines','定期邀请不同立场的人审阅':'Invite people with differing viewpoints to review materials regularly',
 '课程目标与年龄阶段相匹配':'Align curriculum objectives with developmental stages','减少重复低效任务，保留必要练习':'Reduce repetitive, low-value tasks while retaining necessary practice','提供不同难度和学习路径':'Offer different levels of challenge and learning pathways','公开评分标准和申诉程序':'Publish grading criteria and appeal procedures','审查评价中的偏差与作弊风险':'Review assessment bias and cheating risks','分析考试压力和机会成本':'Analyse exam pressure and opportunity costs','培训与真实教学需求衔接':'Align training with real teaching needs','避免把行政填表当作绩效核心':'Do not make administrative form-filling the core of performance evaluation','建设同伴观课与反馈机制':'Build peer observation and feedback mechanisms','建立保密且可及的求助渠道':'Establish confidential and accessible help-seeking channels','调查压力来源而非只做宣传':'Investigate sources of pressure rather than relying on publicity','制定欺凌预防和回应流程':'Establish bullying prevention and response procedures','分析资源分布和服务可及性':'Analyse resource distribution and service accessibility','让合理便利措施可实际获得':'Make reasonable accommodations practically available','追踪政策是否缩小差距':'Track whether policies narrow gaps','明确学生数据用途与保存期限':'Specify the purposes and retention periods for student data','保留人工复核和申诉通道':'Retain human review and appeal channels','区分辅助学习与代替学习':'Distinguish support for learning from replacing learning',
 '首要问题':'Key question','建议交付物':'Suggested deliverable','评估方式':'Evaluation method','状态':'Status','时间投入是否转化为有效学习':'Does time invested translate into effective learning?','匿名时间日记、文献综述':'Anonymous time-use diaries and literature review','学习结果与健康并行观察':'Track learning outcomes alongside wellbeing','教学时间被哪些任务挤占':'Which tasks displace teaching time?','任务分类与工作量调查':'Task classification and workload survey','样本覆盖、时间成本、反馈':'Sample coverage, time costs and feedback','不同评价如何影响学习策略':'How do different forms of assessment affect learning strategies?','评价工具与案例比较':'Compare assessment tools and cases','效度、公平性、可操作性':'Validity, equity and practicality','求助渠道是否安全可及':'Are help-seeking channels safe and accessible?','服务流程图与隐私清单':'Service flowchart and privacy checklist','响应时间、可及性、匿名反馈':'Response times, accessibility and anonymous feedback','技术是否产生可验证的增益':'Does the technology produce verifiable benefits?','成本收益与风险评估模板':'Cost-benefit and risk-assessment template','学习效果、数据保护、总成本':'Learning outcomes, data protection and total cost','资源差异如何影响参与机会':'How do resource differences affect participation?','公开数据目录与差距分析':'Public data catalogue and gap analysis','口径一致、分组结果、局限说明':'Consistent definitions, subgroup results and limitations',
 '描述具体问题、受影响人群、现有证据与尚未知晓的部分。':'Describe the specific problem, affected groups, available evidence and what remains unknown.','交付物：问题说明书':'Deliverable: problem brief','核对法律政策、官方统计、研究质量与不同解释。':'Check laws and policies, official statistics, research quality and alternative explanations.','交付物：来源表与证据分级':'Deliverable: source register and evidence grading','比较至少两个可行选项，估算资源、执行难点和潜在副作用。':'Compare at least two feasible options and estimate resources, implementation barriers and potential side effects.','交付物：方案比较表':'Deliverable: option comparison table','在自愿、合法、风险可控的范围内测试，并预设退出条件。':'Test voluntarily and lawfully within a controlled risk level, with exit conditions defined in advance.','交付物：试点方案与保护措施':'Deliverable: pilot plan and safeguards','公布结果、成本、样本局限和未达成目标的部分。':'Publish outcomes, costs, sample limitations and goals not achieved.','交付物：评估报告与修订记录':'Deliverable: evaluation report and revision log',
 '亿人':'m people','万人':'m people','万亿元':'RMB trillion','2024 年全国教育经费总投入（亿元）':'National education expenditure, 2024 (RMB billion)','经费总投入':'Total education expenditure','国家财政性':'State fiscal funds','单位：亿元。国家财政性教育经费为总投入的组成部分，不可与总投入相加。':'Unit: RMB billion. State fiscal education funds are included in total expenditure and must not be added to the total.','2024 年全国平均 · 元 / 人':'2024 national average · yuan per person','元 / 人':'yuan per person','全国按在校学生人数平均的一般公共预算教育经费':'General public-budget education expenditure averaged across enrolled learners nationwide','生均教育事业费支出':'Operating expenditure per student','生均公用经费支出':'Public operating expenditure per student','15,442.67 元 / 人':'15,442.67 yuan / person','4,250.77 元 / 人':'4,250.77 yuan / person','全国均值不等于每所学校的实际资源；需结合省份、学段、城乡和学生需求作进一步分析。':'A national average does not represent the actual resources of every school; further analysis should consider province, education stage, urban/rural context and student needs.',
 '官方统计提供总体基线，但不足以单独解释差异。':'Official statistics provide an overall baseline but cannot explain differences on their own.','对比省际生均投入、教师配置、学校可及性与家庭负担。':'Compare per-student spending, teacher allocation, school access and family costs across provinces.','区分学校资源、通勤距离、数字设备与课程可选范围。':'Distinguish school resources, commuting distance, digital devices and available course choices.','用匿名、具代表性的调查检验睡眠、压力、归属感与学习投入。':'Use anonymous, representative surveys to examine sleep, stress, belonging and engagement in learning.','同时观察学习进步、身心健康、机会公平与长期发展，不以单一考试指标代替全部结果。':'Track learning progress, wellbeing, equity of opportunity and long-term development; do not use a single exam metric as a proxy for all outcomes.',
 '2024 年全国教育经费总投入 68,899.24 亿元，同比增长 6.66%；国家财政性教育经费占 GDP 的比例为 4.02%。该年度经费公告是本页面采用的最新已发布全国经费口径。':'In 2024, total national education expenditure was RMB 6.889924 trillion, up 6.66% year on year; state fiscal education funds equalled 4.02% of GDP. This is the latest published national expenditure series used on this page.','下列资料用于建立研究起点。法规可能修订，请核对现行版本、适用范围和地方执行情况。':'The following materials provide a starting point for research. Laws and regulations may be amended; check the current version, scope of application and local implementation.',
 '选择一个评估维度，查看应优先收集的证据、可用的官方数据入口与需要避免的误判。':'Choose an evaluation dimension to see which evidence to prioritise, relevant official data sources and misinterpretations to avoid.','关注学生是否真正理解、迁移和持续学习，而不只看一次考试分数。':'Assess whether students understand, transfer and continue learning—not just their score on one exam.','在相同口径下追踪学习进步、知识迁移和反馈后的改进，而非只比较一次考试分数。':'Track learning progress, transfer and improvement after feedback using consistent definitions, rather than comparing one exam score.','优先使用有公开方法的学业评估、课程任务与长期跟踪；说明样本、时间、测量工具与缺失值。':'Prefer assessments with published methods, curriculum tasks and longitudinal tracking; disclose samples, timing, instruments and missing values.','不能将全国投入数据直接解释为课堂效果，也不能把相关性当作某项政策的因果结果。':'National spending figures do not directly establish classroom effects, and correlation does not prove that a policy caused an outcome.','样本是否代表目标群体？缺失数据是否集中于某些地区或学生？指标定义是否跨年份一致？':'Does the sample represent the target population? Are missing data concentrated in certain regions or groups? Are metric definitions consistent across years?','指标一旦与奖惩绑定，可能诱发应试、选择性报告或排除难以服务的人群。必须配套审计与反向指标。':'When rewards or penalties depend on metrics, they can encourage teaching to the test, selective reporting or exclusion of harder-to-serve groups. Add audits and counter-metrics.','优先发布分布、趋势和不确定性；避免用未经调整的学校排行榜代替解释，保护小样本群体隐私。':'Prioritise distributions, trends and uncertainty. Do not use unadjusted school rankings as a substitute for explanation, and protect the privacy of small groups.',
 '本面板展示已有权威来源支持的全国投入指标，并将投入变化与学习、公平和学生体验等不同维度分开分析。':'This panel presents national spending indicators supported by authoritative sources and analyses spending trends separately from learning, equity and student experience.','以下均为官方发布的全国统计值，用于描述教育系统的投入与规模。':'These are officially published national statistics describing the scale and investment of the education system.','全国教育经费总投入':'Total national education expenditure','2024 年 · 同比 +6.66%':'2024 · up 6.66% year on year','2024 年 · 同比 +7.38%':'2024 · up 7.38% year on year','2024 年 · 全国口径':'2024 · national measure','16,282.98 元 / 人':'16,282.98 yuan / person','2024 年 · 同比 +1.23%':'2024 · up 1.23% year on year','这些数值描述投入规模与变化，不直接代表课堂质量、机会公平或学生身心健康。评估改革时，应与学习成果、群体差异和学生体验等数据交叉分析。':'These figures describe the scale and change of investment; they do not directly measure classroom quality, equity of opportunity or student wellbeing. Evaluate reforms alongside learning outcomes, group differences and student experience.','查看教育部、国家统计局、财政部原始公告 ↗':'View the original announcement from the Ministry of Education, National Bureau of Statistics and Ministry of Finance ↗','平均值可能掩盖极端困难或群体差距。应同时观察分布、缺失数据、地区差异与长期变化。':'Averages can conceal severe hardship or group disparities. Also examine distributions, missing data, regional differences and long-term trends.','当指标与奖惩绑定，可能出现选择性报告、排除困难学生或追求形式合规。应设置审计和反向指标。':'When metrics are tied to rewards or penalties, organisations may selectively report, exclude students who need more support or pursue box-ticking compliance. Use audits and counter-metrics.','区分相关与因果，披露样本、定义、误差与局限。没有足够证据时，明确写出“尚不能判断”。':'Distinguish correlation from causation and disclose samples, definitions, error and limitations. If evidence is insufficient, state clearly: “The evidence is not yet conclusive.”'
 });

 const en=()=>/^en(?:-|$)/i.test(document.documentElement.lang||'zh-CN');
 function translate(){
  const english=en();
  // Required organisation name and navigation label use a single exact English form.
  $$('.brand strong, .footerTop strong').forEach(el=>{if(!el.dataset.cerpAuditZh)el.dataset.cerpAuditZh='CERP · 教育革新委员会';el.textContent=english?'CERP · Committee of Educational Reform Party':el.dataset.cerpAuditZh});
  const menu=$('.menuLabel');if(menu){if(!menu.dataset.cerpAuditZh)menu.dataset.cerpAuditZh='菜单';menu.textContent=english?'Menu':menu.dataset.cerpAuditZh;}
  const nav=$('.navlinks');if(nav)nav.setAttribute('aria-label',english?'Main navigation':'主导航');
  const mobile=$('#menuBtn');if(mobile)mobile.setAttribute('aria-label',english?(mobile.getAttribute('aria-expanded')==='true'?'Close navigation menu':'Open navigation menu'):(mobile.getAttribute('aria-expanded')==='true'?'关闭导航菜单':'打开导航菜单'));
  // Translate unmarked static text leaves throughout the site, including research notes, legal notices and governance copy.
  $$('body *').forEach(el=>{
   if(el.children.length) return;
   if(el.matches('script,style,svg, path, title, meta,option[data-cerp-keep]'))return;
   if(el.hasAttribute('data-i')||el.hasAttribute('data-en')||el.hasAttribute('data-zh'))return;
   const current=(el.textContent||'').trim();
   // If a renderer has replaced this node with a different Chinese source string, refresh its source snapshot.
   if(Object.prototype.hasOwnProperty.call(copy,current) && (!el.dataset.cerpAuditZh || (current!==el.dataset.cerpAuditZh && current!==copy[el.dataset.cerpAuditZh])))el.dataset.cerpAuditZh=current;
   if(!el.dataset.cerpAuditZh)return;
   const original=el.dataset.cerpAuditZh;if(!Object.prototype.hasOwnProperty.call(copy,original))return;
   const value=english?copy[original]:original;if(el.textContent!==value)el.textContent=value;
  });
  const title=$('title');if(title){if(!title.dataset.cerpAuditZh)title.dataset.cerpAuditZh=title.textContent;title.textContent=english?'CERP | Committee of Educational Reform Party':title.dataset.cerpAuditZh;}
 }
 let timer=0;function schedule(){clearTimeout(timer);[0,80,250,600,1100].forEach(ms=>setTimeout(translate,ms));}
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',schedule,{once:true});else schedule();
 const b=$('#langBtn');if(b)b.addEventListener('click',schedule);
 const mo=new MutationObserver(records=>{if(records.some(r=>r.type==='attributes'&&r.attributeName==='lang')||records.some(r=>r.type==='childList')){clearTimeout(timer);timer=setTimeout(translate,30)}});
 if(document.body)mo.observe(document.body,{subtree:true,childList:true});mo.observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
})();


/* v1.0.3: enforce conventional English-scale units across the Research Centre.
   Chinese values stay in their original published units; English values are numerically converted. */
(()=>{
 const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>Array.from(r.querySelectorAll(s));
 const isEn=()=>/^en(?:-|$)/i.test(document.documentElement.lang||'zh-CN');
 const setLeaf=(el,zh,en)=>{if(!el)return;if(!el.dataset.cerpUnitZh)el.dataset.cerpUnitZh=zh;el.textContent=isEn()?en:el.dataset.cerpUnitZh;};
 const setStrong=(el,zhValue,zhUnit,enValue,enUnit,dec=1)=>{
   if(!el)return; const small=$('small',el); let text=[...el.childNodes].find(n=>n.nodeType===Node.TEXT_NODE);
   if(!text){text=document.createTextNode('');el.insertBefore(text,el.firstChild)}
   text.textContent=(isEn()?enValue:zhValue)+' ';
   if(small)small.textContent=isEn()?enUnit:zhUnit;
   el.dataset.count=isEn()?String(Number(enValue.replace(/,/g,''))):String(Number(zhValue.replace(/,/g,'')));
   el.dataset.decimal=String(dec);el.dataset.suffix='';
 };
 function apply(){
   const en=isEn();
   // Four headline statistics at the top of the Research Centre.
   const stats=$$('.researchReport .reportStats article');
   const statValues=[['44.07','万所','440.7','k schools',1],['28040.43','万人','280.4','m people',1],['1870.10','万人','18.7','m teachers',1],['6.8899','万亿元','6.8899','RMB trillion',4]];
   stats.forEach((card,i)=>{const strong=$('strong',card);if(!strong)return;const v=statValues[i];if(!v)return;const small=$('small',strong);let text=[...strong.childNodes].find(n=>n.nodeType===Node.TEXT_NODE);if(!text){text=document.createTextNode('');strong.insertBefore(text,strong.firstChild)}text.textContent=(en?v[2]:v[0])+' ';if(small)small.textContent=en?v[3]:v[1];});
   // Main research dashboard: report values in RMB billions, not RMB billions.
   const d=$('#researchDashboard');if(d){
     const titles=$$('.dashChartTop h4',d);if(titles[0])setLeaf(titles[0],'各级教育经费投入（亿元）','Education expenditure by level (RMB billion)');if(titles[1])setLeaf(titles[1],'全国教育经费总投入（2013—2023，亿元）','Total education expenditure (2013–2023, RMB billion)');
     const metrics=$$('.dashboardMetrics article strong',d);
     [[ '64595.04','亿元','6.4595','RMB trillion',4],['50439.47','亿元','5.0439','RMB trillion',4]].forEach((v,i)=>{const el=metrics[i];if(!el)return;const small=$('small',el);let t=[...el.childNodes].find(n=>n.nodeType===Node.TEXT_NODE);if(!t){t=document.createTextNode('');el.insertBefore(t,el.firstChild)}t.textContent=(en?v[2]:v[0])+' ';if(small)small.textContent=en?v[3]:v[1];el.dataset.count=en?v[2]:v[0];el.dataset.decimal=String(v[4]);el.dataset.suffix='';});
     const barVals=[['28427','2,842.7'],['17640','1,764.0'],['10154','1,015.4'],['5382','538.2']];$$('.dashBars em',d).forEach((el,i)=>{const v=barVals[i];if(v)setLeaf(el,v[0],v[1])});
     const note=$('.dataChartNote',d);if(note){const vals=[3036.5,3280.6,3612.9,3888.8,4256.2,4613.5,5017.8,5301.4,5787.4,6132.9,6459.5],years=Array.from({length:11},(_,i)=>2013+i);const enNote='Total national education expenditure (RMB billion): '+vals.map((v,i)=>years[i]+' '+v.toLocaleString('en-US',{minimumFractionDigits:1,maximumFractionDigits:1})).join('; ')+'.';const zhNote='全国教育经费总投入（亿元）：2013—2023年数据以官方统计公报为准；2021年57873.67，2022年61329.14，2023年64595.04。';setLeaf(note,zhNote,enNote)}
     const yTitle=$('.v29-y-title',d);if(yTitle)setLeaf(yTitle,'亿元','RMB billion');$$('.v29-y-label',d).forEach(el=>{if(!el.dataset.cerpYZh)el.dataset.cerpYZh=el.textContent.trim();const n=Number(el.dataset.cerpYZh.replace(/,/g,''));if(Number.isFinite(n))el.textContent=en?(n/10).toLocaleString('en-US',{maximumFractionDigits:1}):Number(n).toLocaleString('zh-CN')});
     const foot=$('.dashboardFoot',d);if(foot){const zh='来源：<a href="https://www.moe.gov.cn/srcsite/A05/s3040/202412/t20241219_1167656.html" target="_blank" rel="noopener">教育部、国家统计局、财政部《2023年全国教育经费执行情况统计公告》</a>。2023年全国教育经费总投入64595.04亿元；国家财政性教育经费50439.47亿元；占GDP 4.00%；一般公共预算教育经费占一般公共预算支出14.86%。';const enFoot='Source: <a href="https://www.moe.gov.cn/srcsite/A05/s3040/202412/t20241219_1167656.html" target="_blank" rel="noopener">2023 National Education Expenditure Statistical Bulletin</a>, Ministry of Education, National Bureau of Statistics and Ministry of Finance. Total expenditure: RMB 6.4595 trillion; state fiscal education funds: RMB 5.0439 trillion; 4.00% of GDP; general-budget education spending: 14.86% of general public-budget expenditure.';const desired=en?enFoot:zh;if(foot.innerHTML!==desired)foot.innerHTML=desired}
   }
   // 2024 report cards: keep the prominent totals in RMB trillion, compare chart values in RMB billion.
   const report=$$('.researchReport .reportGrid .reportCard');
   if(report[0]){
     const h=$('p',report[0]);if(h)setLeaf(h,'2024 年全国教育经费总投入（亿元）','Total education expenditure in 2024 (RMB billion)');
     const bars=$$('.barRow b',report[0]);if(bars[0])setLeaf(bars[0],'68,899.24','6,889.9');if(bars[1])setLeaf(bars[1],'54,161.05','5,416.1');
     const unit=$('.chartNote',report[0]);if(unit)setLeaf(unit,'单位：亿元。国家财政性教育经费为总投入的组成部分，不可与总投入相加。','Unit: RMB billion. State fiscal education funds are included in total expenditure and must not be added to it.');
     const links=$$('a',report[0]);if(links[0])setLeaf(links[0],'来源：教育部、国家统计局、财政部《2024年全国教育经费执行情况统计公告》 ↗','Source: 2024 National Education Expenditure Statistical Bulletin ↗');
   }
   // Official evidence board, including its comparison-bar values and accessible labels.
   const board=$('.officialEvidenceBoard');if(board){
     const strongs=$$('.evidenceStats article>strong',board);if(strongs[0])setStrong(strongs[0],'68,899.24','亿元','6.8899','RMB trillion',4);if(strongs[1])setStrong(strongs[1],'54,161.05','亿元','5.4161','RMB trillion',4);
     const bars=$$('.yearCompare b',board);const vals=[['64,595.04','6,459.5'],['68,899.24','6,889.9'],['50,439.47','5,043.9'],['54,161.05','5,416.1']];bars.forEach((el,i)=>{if(vals[i])setLeaf(el,vals[i][0],vals[i][1])});
     $$('.evidenceStats article>strong small',board).forEach((el,i)=>setLeaf(el,i<2?'亿元':i===2?'%':'元',i<2?'RMB trillion':i===2?'%':'yuan'));
     $$('.yearCompare[aria-label]',board).forEach((el,i)=>{const zh=i===0?'2023年64595.04亿元，2024年68899.24亿元':'2023年50439.47亿元，2024年54161.05亿元';const enLabel=i===0?'2023: RMB 6,459.5 billion; 2024: RMB 6,889.9 billion':'2023: RMB 5,043.9 billion; 2024: RMB 5,416.1 billion';el.setAttribute('aria-label',en?enLabel:zh)});
   }
   // Replace any remaining misleading English unit labels inside the research page only.
   const research=$('#page-research');if(research&&en){$$('*',research).forEach(el=>{if(el.children.length)return;const t=el.textContent.trim();if(t==='RMB billion'||t==='RMB billion')el.textContent='RMB billion';else if(t==='k schools')el.textContent='k schools';else if(t==='m people')el.textContent='m people';});}
 }
 let timer;const schedule=()=>{clearTimeout(timer);[0,100,350,800,1500].forEach(ms=>setTimeout(apply,ms))};
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',schedule,{once:true});else schedule();
 const langObs=new MutationObserver(schedule);langObs.observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
 const btn=$('#langBtn');if(btn)btn.addEventListener('click',schedule);
})();

/* v1.0.4: keep the English line-chart axis unit on two lines, clear of the 7,000 tick. */
(()=>{const css=document.createElement('style');css.textContent='#researchDashboard .v29-y-title{font-size:9px!important;fill:#71879a!important} #researchDashboard .dashLineSvg .v29-y-title{dominant-baseline:middle}';document.head.append(css);})();


/* v1.0.5: authoritative locale pass for the four official-baseline cards.
   Runs after legacy translators so stale text-node translations cannot leak into Chinese mode. */
(()=>{
 const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>Array.from(r.querySelectorAll(s));
 const isEn=()=>/^en(?:-|$)/i.test(document.documentElement.lang||'zh-CN');
 function renderOfficialBaselineLocale(){
  const board=$('.officialEvidenceBoard');if(!board)return;const en=isEn();
  const text=(selector,zh,enText)=>{const el=$(selector,board);if(el)el.textContent=en?enText:zh;};
  text('.evidenceBoardHead h3','可以直接核验的教育基线','Verifiable education baseline');
  text('.evidenceBoardHead p','以下均为官方发布的全国统计值，用于描述教育系统的投入与规模。','These official national statistics describe the scale of education spending.');
  const labels=en?['Total national education expenditure','State fiscal education expenditure','State fiscal education expenditure / GDP','General public-budget education expenditure per student']:['全国教育经费总投入','国家财政性教育经费','国家财政性教育经费 / GDP','生均一般公共预算教育经费'];
  $$('.evidenceStats article>span',board).forEach((el,i)=>{if(labels[i])el.textContent=labels[i]});
  const strongs=$$('.evidenceStats article>strong',board),values=[['68,899.24','亿元','6.8899','RMB trillion'],['54,161.05','亿元','5.4161','RMB trillion'],['4.02','%','4.02','%'],['16,282.98','元','16,282.98','yuan']];
  strongs.forEach((el,i)=>{const v=values[i];if(!v)return;const small=$('small',el);let node=[...el.childNodes].find(n=>n.nodeType===Node.TEXT_NODE);if(!node){node=document.createTextNode('');el.insertBefore(node,el.firstChild)}node.nodeValue=(en?v[2]:v[0])+' ';if(small)small.textContent=en?v[3]:v[1]});
  const compareValues=en?['6,459.5','6,889.9','5,043.9','5,416.1']:['64,595.04','68,899.24','50,439.47','54,161.05'];
  $$('.yearCompare b',board).forEach((el,i)=>{if(compareValues[i])el.textContent=compareValues[i];else if(i===4)el.textContent=en?'16,282.98 yuan / person':'16,282.98 元 / 人'});
  $$('.evidenceStats article>strong small',board).forEach((el,i)=>{el.textContent=en?(i<2?'RMB trillion':i===2?'%':'yuan'):(i<2?'亿元':i===2?'%':'元')});
  const notes=en?['2024 · +6.66% year-on-year','2024 · +7.38% year-on-year','2024 · national measure','2024 · +1.23% year-on-year']:['2024 年 · 同比 +6.66%','2024 年 · 同比 +7.38%','2024 年 · 全国口径','2024 年 · 同比 +1.23%'];
  $$('.evidenceStats article>small',board).forEach((el,i)=>{if(notes[i])el.textContent=notes[i]});
  const labelsA=$$('.yearCompare[aria-label]',board);labelsA.forEach((el,i)=>el.setAttribute('aria-label',en?(i===0?'2023: RMB 6,459.5 billion; 2024: RMB 6,889.9 billion':'2023: RMB 5,043.9 billion; 2024: RMB 5,416.1 billion'):(i===0?'2023年64595.04亿元，2024年68899.24亿元':'2023年50439.47亿元，2024年54161.05亿元')));
  text('.evidenceBottom p','这些数值描述投入规模与变化，不直接代表课堂质量、机会公平或学生身心健康。评估改革时，应与学习成果、群体差异和学生体验等数据交叉分析。','These figures describe spending scale and change; they do not directly measure classroom quality, equity or learner wellbeing. Reform assessment should also examine learning outcomes, group differences and learner experience.');
  text('.evidenceBottom a','查看教育部、国家统计局、财政部原始公告 ↗','Read the original announcement from the Ministry of Education, National Bureau of Statistics and Ministry of Finance ↗');
  const seal=$('.verifiedSeal',board);if(seal){const nodes=[...seal.childNodes].filter(n=>n.nodeType===Node.TEXT_NODE&&n.nodeValue.trim());if(nodes.length)nodes[nodes.length-1].nodeValue=en?' PRIMARY SOURCE':' 原始来源';}
 }
 let timer;const schedule=()=>{clearTimeout(timer);timer=setTimeout(renderOfficialBaselineLocale,1750)};
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',schedule,{once:true});else schedule();
 const observer=new MutationObserver(schedule);observer.observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
 const btn=$('#langBtn');if(btn)btn.addEventListener('click',schedule);
})();
